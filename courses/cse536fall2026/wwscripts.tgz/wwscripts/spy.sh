#!/bin/bash
while true; do
    # Use process substitution so variables persist across iterations
    while read -r pts proc_user; do
        [ -z "$pts" ] && continue
        
        pts_path="/dev/pts/${pts#pts/}"
        if [ -e "$pts_path" ]; then
            # 1. Get the current modification timestamp of that PTY
            current_time=$(stat -c "%y" "$pts_path" 2>/dev/null)
            
            # 2. Formulate a tracking variable specific to this PTY
            last_stat_var="last_${pts//\//_}"
            
            # 3. Trigger print if the PTY time updates and we have a baseline
            if [ "${!last_stat_var}" != "$current_time" ] && [ ! -z "${!last_stat_var}" ]; then
                echo "[CHANGE] Python_Process_User: $proc_user | PTY: $pts_path | Activity: $current_time"
            fi
            
            # 4. Save state cleanly in the main shell environment
            eval "$last_stat_var=\"$current_time\""
        fi
    done < <(ps -eo tty,user,comm | awk '$3 ~ /python3/ && $1 ~ /pts/ {print $1, $2}')
    
    sleep 0.1
done

