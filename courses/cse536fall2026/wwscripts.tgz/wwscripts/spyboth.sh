#!/bin/bash
while true; do
    while read -r pts proc_user state pid; do
        [ -z "$pts" ] && continue
        
        pts_path="/dev/pts/${pts#pts/}"
        var_suffix="${pts//\//_}"
        
        # 1. Fetch exact total CPU time (user + system ticks) directly from /proc
        # Field 14 is utime, Field 15 is stime in /proc/[pid]/stat
        if [ -f "/proc/$pid/stat" ]; then
            read -r -a stat_array < "/proc/$pid/stat" 2>/dev/null
            cputimes=$((stat_array[13] + stat_array[14]))
        else
            cputimes=0
        fi

        last_state_var="last_state_$var_suffix"
        last_ticks_var="last_ticks_$var_suffix"
        
        # 2. Establish baselines on the first time we discover this process
        if [ -z "${!last_state_var}" ]; then
            eval "$last_state_var=\"$state\""
            eval "$last_ticks_var=\"$cputimes\""
            continue
        fi
        
        # 3. HIGH-PRECISION INFERENCE LOGIC:
        # If it was in Sleep (S) but its internal clock ticks moved, it left pipe wait/sleep
        if [ "${!last_state_var}" = "S" ] && [ "${!last_ticks_var}" -ne "$cputimes" ]; then
            echo "[WOKE UP] Python_User: $proc_user | PTY: $pts_path | PID: $pid | Left Pipe Wait/Sleep (Ticks: $cputimes)"
        fi
        
        # If it transitions from Running (R) back to Sleeping (S)
        if [ "${!last_state_var}" = "R" ] && [ "$state" = "S" ]; then
            echo "[BLOCKED] Python_User: $proc_user | PTY: $pts_path | PID: $pid | Entered Pipe Wait/Sleep state"
        fi
        
        # 4. Save state for the next 0.1s tick
        eval "$last_state_var=\"$state\""
        eval "$last_ticks_var=\"$cputimes\""
        
    done < <(ps -eo tty,user,state,pid,comm | awk '$5 ~ /python3/ && $1 ~ /pts/ {print $1, $2, $3, $4}')
    
    sleep 0.1
done

