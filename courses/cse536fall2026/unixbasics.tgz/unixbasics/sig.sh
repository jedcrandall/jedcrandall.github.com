#!/bin/bash

# 1. Define the handler function
handle() {
    echo -e "\nSignal SIGUSR1 received!"
}

# 2. Register the handler to specific signals
trap handle SIGUSR1

echo "Processing... Press Ctrl+C to interrupt."
while true; do
    sleep 1
done

