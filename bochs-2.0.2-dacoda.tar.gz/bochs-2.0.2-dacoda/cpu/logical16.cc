/////////////////////////////////////////////////////////////////////////
// $Id: logical16.cc,v 1.18 2002/10/25 18:26:28 sshwarts Exp $
/////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2001  MandrakeSoft S.A.
//
//    MandrakeSoft S.A.
//    43, rue d'Aboukir
//    75002 Paris - France
//    http://www.linux-mandrake.com/
//    http://www.mandrakesoft.com/
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA






#define NEED_CPU_REG_SHORTCUTS 1
#include "bochs.h"
#define LOG_THIS BX_CPU_THIS_PTR




  void
BX_CPU_C::XOR_EwGw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16, result_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op2_16 = BX_READ_16BIT_REG(i->nnn());
  op2_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmXor16(result_16, op1_16, op2_16, flags32);
    setEFlagsOSZAPC(flags32);
#else
    result_16 = op1_16 ^ op2_16;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XOR_EwGw");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
    BX_WRITE_16BIT_REG(i->rm(), result_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmXor16(result_16, op1_16, op2_16, flags32);
    setEFlagsOSZAPC(flags32);
#else
    result_16 = op1_16 ^ op2_16;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XOR_EwGw");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
    Write_RMW_virtual_word(result_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_16(op1_16, op2_16, result_16, BX_INSTR_XOR16);
#endif
}


  void
BX_CPU_C::XOR_GwEw(bxInstruction_c *i)
{
  Bit16u op1_16, op2_16, result_16;
  unsigned nnn = i->nnn();
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op1_16 = BX_READ_16BIT_REG(nnn);
  op1_integrity = BX_READ_16BIT_INTEGRITY(nnn);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(nnn);
  }
#endif

  if (i->modC0()) {
    op2_16 = BX_READ_16BIT_REG(i->rm());
    op2_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
    }

  result_16 = op1_16 ^ op2_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XOR_GwEw");
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);

  BX_WRITE_16BIT_REG(nnn, result_16);
  BX_WRITE_16BIT_REG_INTEGRITY(nnn, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(nnn, LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

  SET_FLAGS_OSZAPC_16(op1_16, op2_16, result_16, BX_INSTR_XOR16);
}


  void
BX_CPU_C::XOR_AXIw(bxInstruction_c *i)
{
  Bit16u op1_16, op2_16, sum_16;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op1_16 = AX;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(0);
  }
#endif
  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  }
#endif

  sum_16 = op1_16 ^ op2_16;
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XOR_AXIw");
	else
		LogicalExpr = NULL;
  }
#endif

  AX = sum_16;
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(0, LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

  SET_FLAGS_OSZAPC_16(op1_16, op2_16, sum_16, BX_INSTR_XOR16);
}

  void
BX_CPU_C::XOR_EwIw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16, result_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    result_16 = op1_16 ^ op2_16;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XOR_EwIw");
	else
		LogicalExpr = NULL;
  }
#endif
    BX_WRITE_16BIT_REG(i->rm(), result_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    result_16 = op1_16 ^ op2_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XOR_EwIw");
	else
		LogicalExpr = NULL;
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
    Write_RMW_virtual_word(result_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_16(op1_16, op2_16, result_16, BX_INSTR_XOR16);
}


  void
BX_CPU_C::OR_EwIw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16, result_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;


  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  	//Op2Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    result_16 = op1_16 | op2_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "OR_EwIw");
	else
		LogicalExpr = NULL;
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
    BX_WRITE_16BIT_REG(i->rm(), result_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    result_16 = op1_16 | op2_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "OR_EwIw");
	else
		LogicalExpr = NULL;
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
    Write_RMW_virtual_word(result_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_16(op1_16, op2_16, result_16, BX_INSTR_OR16);
}


  void
BX_CPU_C::NOT_Ew(bxInstruction_c *i)
{
  Bit16u op1_16, result_16;
  Bit8u result_integrity;
  Bit8u op1_integrity;
  Expression *Op1Expr, *NotExpr;

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    result_16 = ~op1_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	NotExpr = (Expression *) new Operation(Op1Expr, NULL, "NOT_Ew");
  }
#endif
    BX_WRITE_16BIT_REG(i->rm(), result_16);
    result_integrity = op1_integrity;
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), NotExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    result_16 = ~op1_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	NotExpr = (Expression *) new Operation(Op1Expr, NULL, "NOT_Ew");
  }
#endif
    result_integrity = op1_integrity;
    Write_RMW_virtual_word(result_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), NotExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
  }
#endif
    }
}


  void
BX_CPU_C::OR_EwGw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16, result_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op2_16 = BX_READ_16BIT_REG(i->nnn());
  op2_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    result_16 = op1_16 | op2_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "OR_EwGw");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
    BX_WRITE_16BIT_REG(i->rm(), result_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    result_16 = op1_16 | op2_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "OR_EwGw");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
    Write_RMW_virtual_word(result_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_16(op1_16, op2_16, result_16, BX_INSTR_OR16);
}


  void
BX_CPU_C::OR_GwEw(bxInstruction_c *i)
{
  Bit16u op1_16, op2_16, result_16;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op1_16 = BX_READ_16BIT_REG(i->nnn());
  op1_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op2_16 = BX_READ_16BIT_REG(i->rm());
    op2_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmOr16(result_16, op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  result_16 = op1_16 | op2_16;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "OR_GwEw");
	else
		LogicalExpr = NULL;
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);

  BX_WRITE_16BIT_REG(i->nnn(), result_16);
  BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->nnn(), LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_16(op1_16, op2_16, result_16, BX_INSTR_OR16);
#endif
}


  void
BX_CPU_C::OR_AXIw(bxInstruction_c *i)
{
  Bit16u op1_16, op2_16, sum_16;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op1_16 = AX;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(0);
  }
#endif
  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  }
#endif

  sum_16 = op1_16 | op2_16;
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "OR_AXIw");
	else
		LogicalExpr = NULL;
  }
#endif

  AX = sum_16;
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(0, LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

  SET_FLAGS_OSZAPC_16(op1_16, op2_16, sum_16, BX_INSTR_OR16);
}



  void
BX_CPU_C::AND_EwGw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16, result_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op2_16 = BX_READ_16BIT_REG(i->nnn());
  op2_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmAnd16(result_16, op1_16, op2_16, flags32);
    setEFlagsOSZAPC(flags32);
#else
    result_16 = op1_16 & op2_16;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "AND_EwGw");
  }
#endif

    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);

    BX_WRITE_16BIT_REG(i->rm(), result_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmAnd16(result_16, op1_16, op2_16, flags32);
    setEFlagsOSZAPC(flags32);
#else
    result_16 = op1_16 & op2_16;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "AND_EwGw");
  }
#endif

    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);

    Write_RMW_virtual_word(result_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_16(op1_16, op2_16, result_16, BX_INSTR_AND16);
#endif
}


  void
BX_CPU_C::AND_GwEw(bxInstruction_c *i)
{
  Bit16u op1_16, op2_16, result_16;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op1_16 = BX_READ_16BIT_REG(i->nnn());
  op1_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op2_16 = BX_READ_16BIT_REG(i->rm());
    op2_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmAnd16(result_16, op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  result_16 = op1_16 & op2_16;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "AND_GwEw");
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);

  BX_WRITE_16BIT_REG(i->nnn(), result_16);
  BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->nnn(), LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_16(op1_16, op2_16, result_16, BX_INSTR_AND16);
#endif
}


  void
BX_CPU_C::AND_AXIw(bxInstruction_c *i)
{
  Bit16u op1_16, op2_16, result_16;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op1_16 = AX;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(0);
  }
#endif
  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmAnd16(result_16, op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  result_16 = op1_16 & op2_16;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "AND_AXIw");
	else
		LogicalExpr = NULL;
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);

  AX = result_16;
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(0, LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_16(op1_16, op2_16, result_16, BX_INSTR_AND16);
#endif
}

  void
BX_CPU_C::AND_EwIw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16, result_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmAnd16(result_16, op1_16, op2_16, flags32);
    setEFlagsOSZAPC(flags32);
#else
    result_16 = op1_16 & op2_16;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "AND_EwIw");
	else
		LogicalExpr = NULL;
  }
#endif

   result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);

    BX_WRITE_16BIT_REG(i->rm(), result_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmAnd16(result_16, op1_16, op2_16, flags32);
    setEFlagsOSZAPC(flags32);
#else
    result_16 = op1_16 & op2_16;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "AND_EwIw");
	else
		LogicalExpr = NULL;
  }
#endif

    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);

    Write_RMW_virtual_word(result_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), LogicalExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_16(op1_16, op2_16, result_16, BX_INSTR_AND16);
#endif
}


  void
BX_CPU_C::TEST_EwGw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16;
  Bit8u op1_integrity;
  Expression *Op1Expr, *Op2Expr;

  op2_16 = BX_READ_16BIT_REG(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmTest16(op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit16u result_16;
  result_16 = op1_16 & op2_16;

  SET_FLAGS_OSZAPC_16_WITHEXPR(op1_16, op2_16, result_16, BX_INSTR_TEST16, Op1Expr, Op2Expr);
#endif
}



  void
BX_CPU_C::TEST_AXIw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16;
  Expression *Op1Expr, *Op2Expr;

  op1_16 = AX;
  op2_16 = i->Iw();
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(0);
	Op2Expr = NULL;
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmTest16(op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit16u result_16;
  result_16 = op1_16 & op2_16;

  SET_FLAGS_OSZAPC_16_WITHEXPR(op1_16, op2_16, result_16, BX_INSTR_TEST16, Op1Expr, Op2Expr);
#endif
}


  void
BX_CPU_C::TEST_EwIw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr;

  op2_16 = i->Iw();
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = NULL;
  }
#endif
  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmTest16(op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit16u result_16;
  result_16 = op1_16 & op2_16;

  SET_FLAGS_OSZAPC_16_WITHEXPR(op1_16, op2_16, result_16, BX_INSTR_TEST16, Op1Expr, Op2Expr);
#endif
}
