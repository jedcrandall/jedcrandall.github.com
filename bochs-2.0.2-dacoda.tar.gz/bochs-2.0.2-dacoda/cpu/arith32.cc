/////////////////////////////////////////////////////////////////////////
// $Id: arith32.cc,v 1.30 2002/10/25 18:26:27 sshwarts Exp $
/////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2001  MandrakeSoft S.A.
//
//    MandrakeSoft S.A.
//    43, rue d'Aboukir
//    75002 Paris - France
//    http://www.linux-mandrake.com/
//    http://www.mandrakesoft.com/
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA





#define NEED_CPU_REG_SHORTCUTS 1
#include "bochs.h"
#define LOG_THIS BX_CPU_THIS_PTR


#if BX_SUPPORT_X86_64==0
// Make life easier for merging cpu64 and cpu code.
#define RAX EAX
#define RDX EDX
#endif


  void
BX_CPU_C::INC_ERX(bxInstruction_c *i)
{
  Expression *RegExpr;
#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmInc32(BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].dword.erx, flags32);
  setEFlagsOSZAP(flags32);
#else
  Bit32u erx;

  erx = ++ BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].dword.erx;
#endif

#if BX_SUPPORT_X86_64
  BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].dword.hrx = 0;
#endif

#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	RegExpr = (Expression *) MakeNewQuadReg(i->opcodeReg());
	RegExpr = (Expression *) new Operation(RegExpr, NULL, "INC_ERX");
	WriteSymbolicQuadRegister(i->opcodeReg(), RegExpr);
  }
#endif


#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAP_32(0, 0, erx, BX_INSTR_INC32);
#endif
}

  void
BX_CPU_C::DEC_ERX(bxInstruction_c *i)
{
  Expression *RegExpr;
#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmDec32(BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].dword.erx, flags32);
  setEFlagsOSZAP(flags32);
#else
  Bit32u erx;

  erx = -- BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].dword.erx;
#endif

#if BX_SUPPORT_X86_64
  BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].dword.hrx = 0;
#endif

#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	RegExpr = (Expression *) MakeNewQuadReg(i->opcodeReg());
	RegExpr = (Expression *) new Operation(RegExpr, NULL, "DEC_ERX");
	WriteSymbolicQuadRegister(i->opcodeReg(), RegExpr);
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAP_32(0, 0, erx, BX_INSTR_DEC32);
#endif
}




  void
BX_CPU_C::ADD_EdGd(bxInstruction_c *i)
/*** Done ***/
{
  Bit32u op2_32, op1_32, sum_32;
  Bit8u result_integrity = 0xFF;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op2_32 = BX_READ_32BIT_REG(i->nnn());
  op2_integrity = BX_READ_32BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewQuadReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op1_32 = BX_READ_32BIT_REG(i->rm());
    op1_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    sum_32 = op1_32 + op2_32;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_EdGd");
  }
#endif

    BX_WRITE_32BIT_REGZ(i->rm(), sum_32);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    BX_WRITE_32BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->rm(), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

    }
  else {
    read_RMW_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
    //if (op1_integrity != 0xFF)
    //{
    //	printf("Eck! : %x %08x from %08x\n", op1_integrity, op1_32, RMAddr(i));
	//BX_PANIC(("ECK"));
	//if (BX_CPU_THIS_PTR sregs[BX_SEG_REG_CS].selector.rpl == 0)
	//	op1_integrity = 0xFF;
    //}
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    sum_32 = op1_32 + op2_32;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_EdGd");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    Write_RMW_virtual_dword(sum_32, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicQuadMem(i->seg(), RMAddr(i), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

    }

  SET_FLAGS_OSZAPC_32(op1_32, op2_32, sum_32, BX_INSTR_ADD32);
}


  void
BX_CPU_C::ADD_GdEEd(bxInstruction_c *i)
{
  Bit32u op1_32, op2_32, sum_32;
  unsigned nnn = i->nnn();
  Bit8u op2_integrity;
  Bit8u op1_integrity;
  Bit8u result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;


  op1_32 = BX_READ_32BIT_REG(nnn);
  op1_integrity = BX_READ_32BIT_INTEGRITY(/*i->rm()*/ nnn);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(nnn);
  }
#endif

  read_virtual_dword(i->seg(), RMAddr(i), &op2_32, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmAdd32(sum_32, op1_32, op2_32, flags32);
  setEFlagsOSZAPC(flags32);
#else
  sum_32 = op1_32 + op2_32;
#endif

  /***if (sum_32 == 0x400c4f10)
  {
  	printf("op1 == %08x@%d, op2 == %08x@%d\n", op1_32, op1_integrity, op2_32, op2_integrity);
  }***/
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_GdEEd");
  }
#endif

  BX_WRITE_32BIT_REGZ(nnn, sum_32);
  result_integrity = /*0xFF;*/ low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
  BX_WRITE_32BIT_REG_INTEGRITY(nnn, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(nnn, SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif


#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_32(op1_32, op2_32, sum_32, BX_INSTR_ADD32);
#endif
}

  void
BX_CPU_C::ADD_GdEGd(bxInstruction_c *i)
{
  Bit32u op1_32, op2_32, sum_32;
  unsigned nnn = i->nnn();
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op1_32 = BX_READ_32BIT_REG(nnn);
  op1_integrity = BX_READ_32BIT_INTEGRITY(nnn);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(nnn);
  }
#endif
  op2_32 = BX_READ_32BIT_REG(i->rm());
  op2_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmAdd32(sum_32, op1_32, op2_32, flags32);
  setEFlagsOSZAPC(flags32);
#else
  sum_32 = op1_32 + op2_32;
#endif

#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_GdEGd");
  }
#endif


  BX_WRITE_32BIT_REGZ(nnn, sum_32);
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
  BX_WRITE_32BIT_REG_INTEGRITY(nnn, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(nnn, SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_32(op1_32, op2_32, sum_32, BX_INSTR_ADD32);
#endif
}


  void
BX_CPU_C::ADD_EAXId(bxInstruction_c *i)
{
  Bit32u op1_32, op2_32, sum_32;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op1_32 = EAX;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(0);
  }
#endif
  op2_32 = i->Id();
  op2_integrity = 0xFF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadConstant(i->Id(), Op2Expr);
  }
#endif


  sum_32 = op1_32 + op2_32;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_EAXId");
	else
		SumExpr = NULL;
  }
#endif


  RAX = sum_32;
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(0, SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif


  SET_FLAGS_OSZAPC_32(op1_32, op2_32, sum_32, BX_INSTR_ADD32);
}

  void
BX_CPU_C::ADC_EdGd(bxInstruction_c *i)
{
  bx_bool temp_CF;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  temp_CF = getB_CF();

  Bit32u op2_32, op1_32, sum_32;

  op2_32 = BX_READ_32BIT_REG(i->nnn());
  op2_integrity = BX_READ_32BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewQuadReg(i->nnn());
  }
#endif


  if (i->modC0()) {
    op1_32 = BX_READ_32BIT_REG(i->rm());
    op1_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif

    sum_32 = op1_32 + op2_32 + temp_CF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_EdGd");
  }
#endif

    BX_WRITE_32BIT_REGZ(i->rm(), sum_32);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    BX_WRITE_32BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->rm(), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

    }
  else {
    read_RMW_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    sum_32 = op1_32 + op2_32 + temp_CF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_EdGd");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    Write_RMW_virtual_dword(sum_32, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicQuadMem(i->seg(), RMAddr(i), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_32_CF(op1_32, op2_32, sum_32, BX_INSTR_ADC32,
                         temp_CF);
}


  void
BX_CPU_C::ADC_GdEd(bxInstruction_c *i)
{
  bx_bool temp_CF;
  Bit8u op2_integrity, op1_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  temp_CF = getB_CF();

  Bit32u op1_32, op2_32, sum_32;

  op1_32 = BX_READ_32BIT_REG(i->nnn());
  op1_integrity = BX_READ_32BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op2_32 = BX_READ_32BIT_REG(i->rm());
    op2_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_dword(i->seg(), RMAddr(i), &op2_32, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
}

  sum_32 = op1_32 + op2_32 + temp_CF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_GdEd");
  }
#endif

  BX_WRITE_32BIT_REGZ(i->nnn(), sum_32);
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
  BX_WRITE_32BIT_REG_INTEGRITY(i->nnn(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->nnn(), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif


  SET_FLAGS_OSZAPC_32_CF(op1_32, op2_32, sum_32, BX_INSTR_ADC32,
                         temp_CF);
}


  void
BX_CPU_C::ADC_EAXId(bxInstruction_c *i)
{
  bx_bool temp_CF;

  temp_CF = getB_CF();

  Bit32u op1_32, op2_32, sum_32;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op1_32 = EAX;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(0);
  }
#endif

  op2_32 = i->Id();
  op2_integrity = 0xFF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadConstant(i->Id(), Op2Expr);
  }
#endif


  sum_32 = op1_32 + op2_32 + temp_CF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_EAXId");
	else
		SumExpr = NULL;
  }
#endif


  RAX = sum_32;
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(0, SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif


  SET_FLAGS_OSZAPC_32_CF(op1_32, op2_32, sum_32, BX_INSTR_ADC32,
                         temp_CF);
}




  void
BX_CPU_C::SBB_EdGd(bxInstruction_c *i)
{
  bx_bool temp_CF;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  temp_CF = getB_CF();

  Bit32u op2_32, op1_32, diff_32;

  op2_32 = BX_READ_32BIT_REG(i->nnn());
  op2_integrity = BX_READ_32BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewQuadReg(i->nnn());
  }
#endif


  if (i->modC0()) {
    op1_32 = BX_READ_32BIT_REG(i->rm());
    op1_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->nnn());
  }
#endif

    diff_32 = op1_32 - (op2_32 + temp_CF);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_EdGd");
  }
#endif

    BX_WRITE_32BIT_REGZ(i->rm(), diff_32);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    BX_WRITE_32BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->rm(), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    diff_32 = op1_32 - (op2_32 + temp_CF);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_EdGd");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    Write_RMW_virtual_dword(diff_32, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicQuadMem(i->seg(), RMAddr(i), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_32_CF(op1_32, op2_32, diff_32, BX_INSTR_SBB32,
                         temp_CF);
}


  void
BX_CPU_C::SBB_GdEd(bxInstruction_c *i)
{
  bx_bool temp_CF;
  Bit8u op2_integrity, op1_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  temp_CF = getB_CF();

  Bit32u op1_32, op2_32, diff_32;

  op1_32 = BX_READ_32BIT_REG(i->nnn());
  op1_integrity = BX_READ_32BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->nnn());
  }
#endif


  if (i->modC0()) {
    op2_32 = BX_READ_32BIT_REG(i->rm());
    op2_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_dword(i->seg(), RMAddr(i), &op2_32, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
    }

  diff_32 = op1_32 - (op2_32 + temp_CF);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_GdEd");
  }
#endif

  BX_WRITE_32BIT_REGZ(i->nnn(), diff_32);
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
  BX_WRITE_32BIT_REG_INTEGRITY(i->nnn(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->nnn(), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

  SET_FLAGS_OSZAPC_32_CF(op1_32, op2_32, diff_32, BX_INSTR_SBB32,
                         temp_CF);
}


  void
BX_CPU_C::SBB_EAXId(bxInstruction_c *i)
{
  bx_bool temp_CF;

  temp_CF = getB_CF();

  Bit32u op1_32, op2_32, diff_32;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  op1_32 = EAX;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(0);
  }
#endif
  op2_32 = i->Id();
  op2_integrity = 0xFF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadConstant(i->Id(), Op2Expr);
  }
#endif


  diff_32 = op1_32 - (op2_32 + temp_CF);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_EAXId");
	else
		DiffExpr = NULL;
  }
#endif

  RAX = diff_32;
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(0, DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

  SET_FLAGS_OSZAPC_32_CF(op1_32, op2_32, diff_32, BX_INSTR_SBB32,
                         temp_CF);
}



  void
BX_CPU_C::SBB_EdId(bxInstruction_c *i)
{
  bx_bool temp_CF;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  temp_CF = getB_CF();

  Bit32u op2_32, op1_32, diff_32;

  op2_32 = i->Id();
  op2_integrity = 0xFF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadConstant(i->Id(), Op2Expr);
  }
#endif

  if (i->modC0()) {
    op1_32 = BX_READ_32BIT_REG(i->rm());
    op1_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    diff_32 = op1_32 - (op2_32 + temp_CF);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_EdId");
	else
		DiffExpr = NULL;
  }
#endif

    BX_WRITE_32BIT_REGZ(i->rm(), diff_32);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    BX_WRITE_32BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->rm(), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
}
  else {
    read_RMW_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    diff_32 = op1_32 - (op2_32 + temp_CF);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_EdId");
	else
		DiffExpr = NULL;
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    Write_RMW_virtual_dword(diff_32, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicQuadMem(i->seg(), RMAddr(i), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_32_CF(op1_32, op2_32, diff_32, BX_INSTR_SBB32,
                         temp_CF);
}


  void
BX_CPU_C::SUB_EdGd(bxInstruction_c *i)
{
  Bit32u op2_32, op1_32, diff_32;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;


  op2_32 = BX_READ_32BIT_REG(i->nnn());
  op2_integrity = BX_READ_32BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewQuadReg(i->nnn());
	if (EffectivelyNull(Op2Expr))
	{
		MakeNewQuadConstant(op2_32, Op2Expr);
	}
  }
#endif


  if (i->modC0()) {
    op1_32 = BX_READ_32BIT_REG(i->rm());
    op1_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    diff_32 = op1_32 - op2_32;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_EdGd");
  }
#endif
    BX_WRITE_32BIT_REGZ(i->rm(), diff_32);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    BX_WRITE_32BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->rm(), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    diff_32 = op1_32 - op2_32;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_EdGd");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    Write_RMW_virtual_dword(diff_32, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicQuadMem(i->seg(), RMAddr(i), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_32(op1_32, op2_32, diff_32, BX_INSTR_SUB32);
}


  void
BX_CPU_C::SUB_GdEd(bxInstruction_c *i)
{
  Bit32u op1_32, op2_32, diff_32;
  unsigned nnn = i->nnn();
  Bit8u op2_integrity, op1_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  op1_32 = BX_READ_32BIT_REG(nnn);
  op1_integrity = BX_READ_32BIT_INTEGRITY(nnn);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(nnn);
  }
#endif

  if (i->modC0()) {
    op2_32 = BX_READ_32BIT_REG(i->rm());
    op2_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_dword(i->seg(), RMAddr(i), &op2_32, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
       }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmSub32(diff_32, op1_32, op2_32, flags32);
  setEFlagsOSZAPC(flags32);
#else
  diff_32 = op1_32 - op2_32;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_GdEd");
  }
#endif

  BX_WRITE_32BIT_REGZ(nnn, diff_32);
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
  BX_WRITE_32BIT_REG_INTEGRITY(nnn, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(nnn, DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_32(op1_32, op2_32, diff_32, BX_INSTR_SUB32);
#endif
}

  void
BX_CPU_C::SUB_EAXId(bxInstruction_c *i)
{
  Bit32u op1_32, op2_32, diff_32;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  op1_32 = EAX;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(0);
  }
#endif
  op2_32 = i->Id();
  op2_integrity = 0xFF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadConstant(i->Id(), Op2Expr);
  }
#endif

  diff_32 = op1_32 - op2_32;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_EAXId");
	else
		DiffExpr = NULL;
  }
#endif

  RAX = diff_32;
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(0, DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

  SET_FLAGS_OSZAPC_32(op1_32, op2_32, diff_32, BX_INSTR_SUB32);
}


  void
BX_CPU_C::CMP_EdGd(bxInstruction_c *i)
{
  Bit32u op2_32, op1_32;
  Bit8u op1_integrity;
  Expression *Op1Expr, *Op2Expr;

  op2_32 = BX_READ_32BIT_REG(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewQuadReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op1_32 = BX_READ_32BIT_REG(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmCmp32(op1_32, op2_32, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit32u diff_32;
  diff_32 = op1_32 - op2_32;

  SET_FLAGS_OSZAPC_32_WITHEXPR(op1_32, op2_32, diff_32, BX_INSTR_CMP32, Op1Expr, Op2Expr);
#endif

}


  void
BX_CPU_C::CMP_GdEd(bxInstruction_c *i)
{
  Bit32u op1_32, op2_32;
  Bit8u op2_integrity;
  Expression *Op1Expr, *Op2Expr;

  op1_32 = BX_READ_32BIT_REG(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op2_32 = BX_READ_32BIT_REG(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_dword(i->seg(), RMAddr(i), &op2_32, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmCmp32(op1_32, op2_32, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit32u diff_32;
  diff_32 = op1_32 - op2_32;

  SET_FLAGS_OSZAPC_32_WITHEXPR(op1_32, op2_32, diff_32, BX_INSTR_CMP32, Op1Expr, Op2Expr);
#endif
}


  void
BX_CPU_C::CMP_EAXId(bxInstruction_c *i)
{
  Bit32u op1_32, op2_32;
  Expression *Op1Expr, *Op2Expr;

  op1_32 = EAX;
  op2_32 = i->Id();
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(0);
	Op2Expr = NULL;
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmCmp32(op1_32, op2_32, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit32u diff_32;
  diff_32 = op1_32 - op2_32;

  SET_FLAGS_OSZAPC_32_WITHEXPR(op1_32, op2_32, diff_32, BX_INSTR_CMP32, Op1Expr, Op2Expr);
#endif
}


  void
BX_CPU_C::CWDE(bxInstruction_c *i)
{
  /* CBW: no flags are effected */
  Bit32u temp;

  temp = (Bit16s) AX;
  RAX = temp;
}

  void
BX_CPU_C::CDQ(bxInstruction_c *i)
{
  /* CDQ: no flags are affected */

  if (EAX & 0x80000000) {
    RDX = 0xFFFFFFFF;
    }
  else {
    RDX = 0x00000000;
    }
}

// Some info on the opcodes at {0F,A6} and {0F,A7}
// On 386 steps A0-B0:
//   {OF,A6} = XBTS
//   {OF,A7} = IBTS
// On 486 steps A0-B0:
//   {OF,A6} = CMPXCHG 8
//   {OF,A7} = CMPXCHG 16|32
//
// On 486 >= B steps, and further processors, the
// CMPXCHG instructions were moved to opcodes:
//   {OF,B0} = CMPXCHG 8
//   {OF,B1} = CMPXCHG 16|32

  void
BX_CPU_C::CMPXCHG_XBTS(bxInstruction_c *i)
{
  BX_INFO(("CMPXCHG_XBTS:"));
  UndefinedOpcode(i);
}

  void
BX_CPU_C::CMPXCHG_IBTS(bxInstruction_c *i)
{
  BX_INFO(("CMPXCHG_IBTS:"));
  UndefinedOpcode(i);
}


  void
BX_CPU_C::XADD_EdGd(bxInstruction_c *i)
{
#if (BX_CPU_LEVEL >= 4) || (BX_CPU_LEVEL_HACKED >= 4)

  Bit32u op2_32, op1_32, sum_32;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;


  /* XADD dst(r/m), src(r)
   * temp <-- src + dst         | sum = op2 + op1
   * src  <-- dst               | op2 = op1
   * dst  <-- tmp               | op1 = sum
   */

  op2_32 = BX_READ_32BIT_REG(i->nnn());
  op2_integrity = BX_READ_32BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewQuadReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op1_32 = BX_READ_32BIT_REG(i->rm());
    op1_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    sum_32 = op1_32 + op2_32;
    // and write destination into source
    // Note: if both op1 & op2 are registers, the last one written
    //       should be the sum, as op1 & op2 may be the same register.
    //       For example:  XADD AL, AL
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XADD_EdGd");
  }
#endif

    BX_WRITE_32BIT_REGZ(i->nnn(), op1_32);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->nnn(), Op1Expr);
  }
#endif
    BX_WRITE_32BIT_REGZ(i->rm(), sum_32);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    BX_WRITE_32BIT_REG_INTEGRITY(i->rm(), result_integrity);
    BX_WRITE_32BIT_REG_INTEGRITY(i->nnn(), op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->rm(), SumExpr);
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    sum_32 = op1_32 + op2_32;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XADD_EdGd");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    Write_RMW_virtual_dword(sum_32, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicQuadMem(i->seg(), RMAddr(i), SumExpr);
  }
#endif
    /* and write destination into source */
    BX_WRITE_32BIT_REGZ(i->nnn(), op1_32);
    BX_WRITE_32BIT_REG_INTEGRITY(i->nnn(), op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->nnn(), Op1Expr);
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_32(op1_32, op2_32, sum_32, BX_INSTR_XADD32);
#else
  BX_INFO (("XADD_EdGd not supported for cpulevel <= 3"));
  UndefinedOpcode(i);
#endif
}



  void
BX_CPU_C::ADD_EEdId(bxInstruction_c *i)
{
  Bit32u op2_32, op1_32, sum_32;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op2_32 = i->Id();
  op2_integrity = 0xFF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadConstant(i->Id(), Op2Expr);
  }
#endif


  read_RMW_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmAdd32(sum_32, op1_32, op2_32, flags32);
  setEFlagsOSZAPC(flags32);
#else
  sum_32 = op1_32 + op2_32;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_EEdId");
	else
		SumExpr = NULL;
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
  Write_RMW_virtual_dword(sum_32, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicQuadMem(i->seg(), RMAddr(i), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif


#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_32(op1_32, op2_32, sum_32, BX_INSTR_ADD32);
#endif
}

  void
BX_CPU_C::ADD_EGdId(bxInstruction_c *i)
{
  Bit32u op2_32, op1_32, sum_32;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op2_32 = i->Id();
  op2_integrity = 0xFF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadConstant(i->Id(), Op2Expr);
  }
#endif
  op1_32 = BX_READ_32BIT_REG(i->rm());
  op1_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmAdd32(sum_32, op1_32, op2_32, flags32);
  setEFlagsOSZAPC(flags32);
#else
  sum_32 = op1_32 + op2_32;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_EGdId");
	else
		SumExpr = NULL;
  }
#endif

  BX_WRITE_32BIT_REGZ(i->rm(), sum_32);
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
  BX_WRITE_32BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->rm(), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_32(op1_32, op2_32, sum_32, BX_INSTR_ADD32);
#endif
}

  void
BX_CPU_C::ADC_EdId(bxInstruction_c *i)
{
  bx_bool temp_CF;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  temp_CF = getB_CF();

  Bit32u op2_32, op1_32, sum_32;

  op2_32 = i->Id();
  op2_integrity = 0xFF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadConstant(i->Id(), Op2Expr);
  }
#endif

  if (i->modC0()) {
    op1_32 = BX_READ_32BIT_REG(i->rm());
    op1_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    sum_32 = op1_32 + op2_32 + temp_CF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_EdId");
	else
		SumExpr = NULL;
  }
#endif
    BX_WRITE_32BIT_REGZ(i->rm(), sum_32);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    BX_WRITE_32BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->rm(), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    sum_32 = op1_32 + op2_32 + temp_CF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_EdId");
	else
		SumExpr = NULL;
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    Write_RMW_virtual_dword(sum_32, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicQuadMem(i->seg(), RMAddr(i), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_32_CF(op1_32, op2_32, sum_32, BX_INSTR_ADC32,
                         temp_CF);
}


  void
BX_CPU_C::SUB_EdId(bxInstruction_c *i)
{
  Bit32u op2_32, op1_32, diff_32;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  op2_32 = i->Id();
  op2_integrity = 0xFF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadConstant(i->Id(), Op2Expr);
  }
#endif

  if (i->modC0()) {
    op1_32 = BX_READ_32BIT_REG(i->rm());
    op1_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    diff_32 = op1_32 - op2_32;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_EdId");
	else
		DiffExpr = NULL;
  }
#endif
    BX_WRITE_32BIT_REGZ(i->rm(), diff_32);
/*    if (!op1_integrity)
    	{
	printf("Goofiness: %08x %d %08x r: %d PC: %08x\n", op1_32, op2_32, diff_32, i->rm(), EIP);
	printf("Tomfoolery came from %08x\n", BX_CPU_THIS_PTR gen_reg_debug_info[i->rm()]);
	//BX_PANIC(("TOMFOOLERY!"));
	}	*/
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    //if (!result_integrity) result_integrity = 0x22;
    BX_WRITE_32BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->rm(), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    diff_32 = op1_32 - op2_32;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_EdId");
	else
		DiffExpr = NULL;
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
    Write_RMW_virtual_dword(diff_32, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicQuadMem(i->seg(), RMAddr(i), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_32(op1_32, op2_32, diff_32, BX_INSTR_SUB32);
}

  void
BX_CPU_C::CMP_EdId(bxInstruction_c *i)
{
  Bit32u op2_32, op1_32;
  Bit8u op1_integrity;
  Expression *Op1Expr, *Op2Expr;

  op2_32 = i->Id();
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = NULL;
  }
#endif

  if (i->modC0()) {
    op1_32 = BX_READ_32BIT_REG(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmCmp32(op1_32, op2_32, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit32u diff_32;
  diff_32 = op1_32 - op2_32;

  SET_FLAGS_OSZAPC_32_WITHEXPR(op1_32, op2_32, diff_32, BX_INSTR_CMP32, Op1Expr, Op2Expr);
#endif
}




  void
BX_CPU_C::NEG_Ed(bxInstruction_c *i)
{
  Bit32u op1_32, diff_32;
  Bit8u result_integrity;
  Bit8u op1_integrity;
  Expression *Op1Expr, *NegExpr;

  if (i->modC0()) {
    op1_32 = BX_READ_32BIT_REG(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    diff_32 = 0 - op1_32;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	NegExpr = (Expression *) new Operation(Op1Expr, NULL, "NEG_Ed");
  }
#endif
    BX_WRITE_32BIT_REGZ(i->rm(), diff_32);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->rm(), NegExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    diff_32 = 0 - op1_32;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	NegExpr = (Expression *) new Operation(Op1Expr, NULL, "NEG_Ed");
  }
#endif
    result_integrity = op1_integrity;
    Write_RMW_virtual_dword(diff_32, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicQuadMem(i->seg(), RMAddr(i), NegExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_32(op1_32, 0, diff_32, BX_INSTR_NEG32);
}


  void
BX_CPU_C::INC_Ed(bxInstruction_c *i)
{
  Bit32u op1_32;
  Bit8u result_integrity;
  Bit8u op1_integrity;
  Expression *Op1Expr, *IncExpr;

  if (i->modC0()) {
    op1_32 = BX_READ_32BIT_REG(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    op1_32++;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	IncExpr = (Expression *) new Operation(Op1Expr, NULL, "INC_Ed");
  }
#endif
    BX_WRITE_32BIT_REGZ(i->rm(), op1_32);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->rm(), IncExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    op1_32++;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	IncExpr = (Expression *) new Operation(Op1Expr, NULL, "INC_Ed");
  }
#endif
    result_integrity = op1_integrity;
    Write_RMW_virtual_dword(op1_32, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicQuadMem(i->seg(), RMAddr(i), IncExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
  }
#endif
    }

  SET_FLAGS_OSZAP_32(0, 0, op1_32, BX_INSTR_INC32);
}


  void
BX_CPU_C::DEC_Ed(bxInstruction_c *i)
{
  Bit32u op1_32;
  Bit8u result_integrity;
  Bit8u op1_integrity;
  Expression *Op1Expr, *DecExpr;

  if (i->modC0()) {
    op1_32 = BX_READ_32BIT_REG(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    op1_32--;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DecExpr = (Expression *) new Operation(Op1Expr, NULL, "DEC_Ed");
  }
#endif
    BX_WRITE_32BIT_REGZ(i->rm(), op1_32);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->rm(), DecExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    op1_32--;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DecExpr = (Expression *) new Operation(Op1Expr, NULL, "DEC_Ed");
  }
#endif
    result_integrity = op1_integrity;
    Write_RMW_virtual_dword(op1_32, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicQuadMem(i->seg(), RMAddr(i), DecExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
  }
#endif
    }

  SET_FLAGS_OSZAP_32(0, 0, op1_32, BX_INSTR_DEC32);
}


  void
BX_CPU_C::CMPXCHG_EdGd(bxInstruction_c *i)
{
#if (BX_CPU_LEVEL >= 4) || (BX_CPU_LEVEL_HACKED >= 4)

  Bit32u op2_32, op1_32, diff_32;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr;

  if (i->modC0()) {
    op1_32 = BX_READ_32BIT_REG(i->rm());
    op1_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewQuadReg(i->rm());
  }
#endif
    }
  else {
    read_RMW_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    }

#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewQuadReg(0);
  }
#endif

  diff_32 = EAX - op1_32;

  //SET_FLAGS_OSZAPC_32(EAX, op1_32, diff_32, BX_INSTR_CMP32);
  SET_FLAGS_OSZAPC_32_WITHEXPR(EAX, op1_32, diff_32, BX_INSTR_CMP32, Op1Expr, Op2Expr);

  if (diff_32 == 0) {  // if accumulator == dest
    // ZF = 1
    set_ZF(1);
    // dest <-- src
    op2_32 = BX_READ_32BIT_REG(i->nnn());
    op2_integrity = BX_READ_32BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewQuadReg(i->nnn());
  }
#endif

    if (i->modC0()) {
      BX_WRITE_32BIT_REGZ(i->rm(), op2_32);
      BX_WRITE_32BIT_REG_INTEGRITY(i->rm(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(i->rm(), Op2Expr);
  }
#endif
      }
    else {
      Write_RMW_virtual_dword(op2_32, op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicQuadMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
      }
    }
  else {
    // ZF = 0
    set_ZF(0);
    // accumulator <-- dest
    RAX = op1_32;
    //LVAL_EAX_INTEGRITY = op1_integrity;
    BX_WRITE_32BIT_REG_INTEGRITY(0, op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(0, Op1Expr);
  }
#endif
    }
#else
  BX_PANIC(("CMPXCHG_EdGd:"));
#endif
}

  void
BX_CPU_C::CMPXCHG8B(bxInstruction_c *i)
{
#if (BX_CPU_LEVEL >= 5) || (BX_CPU_LEVEL_HACKED >= 5)

  Bit32u op1_64_lo, op1_64_hi, diff;
  Bit8u result_integrity, op1_integrity_lo, op1_integrity_hi, op2_integrity_lo, op2_integrity_hi;
  Expression *Op1Expr_lo, *Op1Expr_hi, *Op2Expr_lo, *Op2Expr_hi;

  if (i->modC0()) {
    BX_INFO(("CMPXCHG8B: dest is reg: #UD"));
    UndefinedOpcode(i);
    }

  read_virtual_dword(i->seg(), RMAddr(i), &op1_64_lo, &op1_integrity_lo);
  read_RMW_virtual_dword(i->seg(), RMAddr(i) + 4, &op1_64_hi, &op1_integrity_hi);
    //result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_DOUBLE, INTEG_DOUBLE);
/**
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewQuadMem(i->seg(), RMAddr(i), Op1Expr_lo);
  	MakeNewQuadMem(i->seg() + 4, RMAddr(i), Op1Expr_hi);
  }
#endif

#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr_lo = (Expression *) MakeNewQuadReg(0);
  	Op2Expr_hi = (Expression *) MakeNewQuadReg(2);
  }
#endif
**/

  diff = EAX - op1_64_lo;
  diff |= EDX - op1_64_hi;

//     SET_FLAGS_OSZAPC_32(EAX, op1_32, diff_32, BX_INSTR_CMP32);

  if (diff == 0) {  // if accumulator == dest
    // ZF = 1
    set_ZF(1);
    // dest <-- src
#if 0
BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr_lo = (Expression *) MakeNewQuadReg(1);
  	Op2Expr_hi = (Expression *) MakeNewQuadReg(3);
  }
#endif
    result_integrity = ECX_INTEGRITY;
    Write_RMW_virtual_dword(ECX, result_integrity);
    result_integrity = EBX_INTEGRITY;
    write_virtual_dword(i->seg(), RMAddr(i), &EBX, &result_integrity);
#if 0
BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Wrong -- WriteSymbolicQuadMem(i->seg() + 4, RMAddr(i), Op2Expr_lo);
  	WriteSymbolicQuadMem(i->seg(), RMAddr(i), Op2Expr_hi);
  }
#endif
    }
  else {
    // ZF = 0
    set_ZF(0);
    // accumulator <-- dest
    RAX = op1_64_lo;
    //LVAL_EAX_INTEGRITY = result_integrity;
    BX_WRITE_32BIT_REG_INTEGRITY(0, op1_integrity_lo);
    RDX = op1_64_hi;
    LVAL_EDX_INTEGRITY = op1_integrity_hi;
#if 0
BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicQuadRegister(0, Op1Expr_lo);
	WriteSymbolicQuadRegister(2, Op1Expr_hi);
  }
#endif
    }

#else
  BX_PANIC(("CMPXCHG8B: not implemented yet"));
  UndefinedOpcode(i);
#endif
}
