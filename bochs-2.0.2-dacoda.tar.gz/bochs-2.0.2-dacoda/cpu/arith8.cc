/////////////////////////////////////////////////////////////////////////
// $Id: arith8.cc,v 1.24 2002/10/25 18:26:27 sshwarts Exp $
/////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2001  MandrakeSoft S.A.
//
//    MandrakeSoft S.A.
//    43, rue d'Aboukir
//    75002 Paris - France
//    http://www.linux-mandrake.com/
//    http://www.mandrakesoft.com/
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA





#define NEED_CPU_REG_SHORTCUTS 1
#include "bochs.h"
#define LOG_THIS BX_CPU_THIS_PTR





  void
BX_CPU_C::ADD_EbGb(bxInstruction_c *i)
{
  Bit8u op2, op1, sum;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op2 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op2_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    sum = op1 + op2;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_EbGb");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), sum);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, SumExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    sum = op1 + op2;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_EbGb");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
    Write_RMW_virtual_byte(sum, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	write_virtual_expression(i->seg(), RMAddr(i), SumExpr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_8(op1, op2, sum, BX_INSTR_ADD8);
}



  void
BX_CPU_C::ADD_GbEb(bxInstruction_c *i)
{
  Bit8u op1, op2, sum;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op1 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op1_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op2 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op2_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    sum = op1 + op2;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_GbEb");
  }
#endif
    }
  else {
    read_virtual_byte(i->seg(), RMAddr(i), &op2, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op2Expr);
  }
#endif
    sum = op1 + op2;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_GbEb");
  }
#endif
    }

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

  BX_WRITE_8BIT_REGx(i->nnn(), i->extend8bitL(), sum);
  BX_WRITE_8BIT_REG_INTEGRITY(i->nnn(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1, SumExpr);
  }
#endif

  SET_FLAGS_OSZAPC_8(op1, op2, sum, BX_INSTR_ADD8);
}


  void
BX_CPU_C::ADD_ALIb(bxInstruction_c *i)
{
  Bit8u op1, op2, sum;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;


  op1 = AL;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(0, 0);
  }
#endif
  op2 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) new Constant(i->Ib());
  }
#endif


  sum = op1 + op2;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_ALIb");
	else
	{
		SumExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

  AL = sum;
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(0, 0, SumExpr);
  }
#endif

  SET_FLAGS_OSZAPC_8(op1, op2, sum, BX_INSTR_ADD8);
}


  void
BX_CPU_C::ADC_EbGb(bxInstruction_c *i)
{
  Bit8u op2, op1, sum;
  bx_bool temp_CF;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  temp_CF = getB_CF();

  op2 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op2_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    sum = op1 + op2 + temp_CF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_EbGb");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), sum);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, SumExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    sum = op1 + op2 + temp_CF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_EbGb");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
    Write_RMW_virtual_byte(sum, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	write_virtual_expression(i->seg(), RMAddr(i), SumExpr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_8_CF(op1, op2, sum, BX_INSTR_ADC8, temp_CF);
}


  void
BX_CPU_C::ADC_GbEb(bxInstruction_c *i)
{
  Bit8u op1, op2, sum;
  bx_bool temp_CF;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  temp_CF = getB_CF();

  op1 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op1_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op2 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op2_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif

    }
  else {
    read_virtual_byte(i->seg(), RMAddr(i), &op2, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op2Expr);
  }
#endif
    }

  sum = op1 + op2 + temp_CF;

#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_GbEb");
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

  SET_FLAGS_OSZAPC_8_CF(op1, op2, sum, BX_INSTR_ADC8,
                           temp_CF);

  BX_WRITE_8BIT_REGx(i->nnn(), i->extend8bitL(), sum);
  BX_WRITE_8BIT_REG_INTEGRITY(i->nnn(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1, SumExpr);
  }
#endif
}


  void
BX_CPU_C::ADC_ALIb(bxInstruction_c *i)
{
  Bit8u op1, op2, sum;
  bx_bool temp_CF;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  temp_CF = getB_CF();


  op1 = AL;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(0, 0);
  }
#endif
  op2 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) new Constant(i->Ib());
  }
#endif

  sum = op1 + op2 + temp_CF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_ALIb");
	else
	{
		SumExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

  AL = sum;

  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(0, 0, SumExpr);
  }
#endif

  SET_FLAGS_OSZAPC_8_CF(op1, op2, sum, BX_INSTR_ADC8,
                           temp_CF);
}


  void
BX_CPU_C::SBB_EbGb(bxInstruction_c *i)
{
  Bit8u op2_8, op1_8, diff_8;
  bx_bool temp_CF;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  temp_CF = getB_CF();


  op2_8 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op2_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op1_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    diff_8 = op1_8 - (op2_8 + temp_CF);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_EbGb");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), diff_8);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, DiffExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1_8, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    diff_8 = op1_8 - (op2_8 + temp_CF);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_EbGb");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
    Write_RMW_virtual_byte(diff_8, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(i->seg(), RMAddr(i), DiffExpr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_8_CF(op1_8, op2_8, diff_8, BX_INSTR_SBB8,
                           temp_CF);
}


  void
BX_CPU_C::SBB_GbEb(bxInstruction_c *i)
{
  Bit8u op1_8, op2_8, diff_8;
  bx_bool temp_CF;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  temp_CF = getB_CF();

  op1_8 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op1_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op2_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op2_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    }
  else {
    read_virtual_byte(i->seg(), RMAddr(i), &op2_8, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op2Expr);
  }
#endif

    }

  diff_8 = op1_8 - (op2_8 + temp_CF);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_GbEb");
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

  BX_WRITE_8BIT_REGx(i->nnn(), i->extend8bitL(), diff_8);
  BX_WRITE_8BIT_REG_INTEGRITY(i->nnn(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1, DiffExpr);
  }
#endif

  SET_FLAGS_OSZAPC_8_CF(op1_8, op2_8, diff_8, BX_INSTR_SBB8,
                           temp_CF);
}


  void
BX_CPU_C::SBB_ALIb(bxInstruction_c *i)
{
  Bit8u op1_8, op2_8, diff_8;
  bx_bool temp_CF;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  temp_CF = getB_CF();

  op1_8 = AL;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(0, 0);
  }
#endif
  op2_8 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) new Constant(i->Ib());
  }
#endif

  diff_8 = op1_8 - (op2_8 + temp_CF);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_ALIb");
	else
	{
		DiffExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

  AL = diff_8;
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(0, 0, DiffExpr);
  }
#endif

  SET_FLAGS_OSZAPC_8_CF(op1_8, op2_8, diff_8, BX_INSTR_SBB8,
                           temp_CF);
}


  void
BX_CPU_C::SBB_EbIb(bxInstruction_c *i)
{
  Bit8u op2_8, op1_8, diff_8;
  bx_bool temp_CF;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  temp_CF = getB_CF();

  op2_8 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) new Constant(i->Ib());
  }
#endif

  if (i->modC0()) {
    op1_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    diff_8 = op1_8 - (op2_8 + temp_CF);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_EbIb");
	else
	{
		DiffExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), diff_8);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, DiffExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1_8, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif

    diff_8 = op1_8 - (op2_8 + temp_CF);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_EbIb");
	else
	{
		DiffExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif
    Write_RMW_virtual_byte(diff_8, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	write_virtual_expression(i->seg(), RMAddr(i), DiffExpr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_8_CF(op1_8, op2_8, diff_8, BX_INSTR_SBB8,
                           temp_CF);
}



  void
BX_CPU_C::SUB_EbGb(bxInstruction_c *i)
{
  Bit8u op2_8, op1_8, diff_8;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  op2_8 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op2_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op1_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    diff_8 = op1_8 - op2_8;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_EbGb");
  }
#endif
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), diff_8);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, DiffExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1_8, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    diff_8 = op1_8 - op2_8;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_EbGb");
  }
#endif
    Write_RMW_virtual_byte(diff_8, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	write_virtual_expression(i->seg(), RMAddr(i), DiffExpr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_8(op1_8, op2_8, diff_8, BX_INSTR_SUB8);
}


  void
BX_CPU_C::SUB_GbEb(bxInstruction_c *i)
{
  Bit8u op1_8, op2_8, diff_8;
  Bit8u op2_integrity, op1_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  op1_8 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op1_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op2_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op2_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    }
  else {
    read_virtual_byte(i->seg(), RMAddr(i), &op2_8, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	read_virtual_expression(i->seg(), RMAddr(i), &Op2Expr);
  }
#endif
    }

  diff_8 = op1_8 - op2_8;

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_GbEb");
  }
#endif

  BX_WRITE_8BIT_REGx(i->nnn(), i->extend8bitL(), diff_8);
  BX_WRITE_8BIT_REG_INTEGRITY(i->nnn(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1, DiffExpr);
  }
#endif

  SET_FLAGS_OSZAPC_8(op1_8, op2_8, diff_8, BX_INSTR_SUB8);
}


  void
BX_CPU_C::SUB_ALIb(bxInstruction_c *i)
{
  Bit8u op1_8, op2_8, diff_8;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  op1_8 = AL;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(0, 0);
  }
#endif

  op2_8 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) new Constant(i->Ib());
  }
#endif

  diff_8 = op1_8 - op2_8;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_ALIb");
	else
	{
		DiffExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

  AL = diff_8;

  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(0, 0, DiffExpr);
  }
#endif

  SET_FLAGS_OSZAPC_8(op1_8, op2_8, diff_8, BX_INSTR_SUB8);
}



  void
BX_CPU_C::CMP_EbGb(bxInstruction_c *i)
{
  Bit8u op2_8, op1_8;
  Bit8u op1_integrity;
  Expression *Op2Expr;
  Expression *Op1Expr;
  //Expression *ZExpr;

  op2_8 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op1_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    }
  else {
    read_virtual_byte(i->seg(), RMAddr(i), &op1_8, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
	if (BX_CPU_THIS_PTR RMAddr_expression != NULL)
	{
		Expression *Etemp = NULL;
		Etemp = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op1Expr);
		Op1Expr = Etemp;
	}	
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmCmp8(op1_8, op2_8, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit8u diff_8;
  diff_8 = op1_8 - op2_8;

  SET_FLAGS_OSZAPC_8_WITHEXPR(op1_8, op2_8, diff_8, BX_INSTR_CMP8, Op1Expr, Op2Expr);
/**
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if ((Op1Expr != NULL) && (Op2Expr != NULL))
	{
		if (diff_8)
			ZExpr = (Expression *) new Pred(Op1Expr, Op2Expr, "NOTEQU");
		else
			ZExpr = (Expression *) new Pred(Op1Expr, Op2Expr, "EQU");
	}
	else if (Op1Expr != NULL)
	{
		if (diff_8)
			ZExpr = (Expression *) new Pred(Op1Expr, (Expression *) new Constant(op2_8), "NOTEQU");
		else
			ZExpr = (Expression *) new Pred(Op1Expr, (Expression *) new Constant(op2_8), "EQU");
	}
	else if (Op2Expr != NULL)
	{
		if (diff_8)
			ZExpr = (Expression *) new Pred((Expression *) new Constant(op1_8), Op2Expr, "NOTEQU");
		else
			ZExpr = (Expression *) new Pred((Expression *) new Constant(op1_8), Op2Expr, "EQU");
	}
	else
	{
		ZExpr = NULL;
	}
	//TheLabes.WriteSymbolicFlags(6, ZExpr);
	if (ZExpr != NULL) ZExpr->Print(0);
  }
#endif **/

#endif
}


  void
BX_CPU_C::CMP_GbEb(bxInstruction_c *i)
{
  Bit8u op1_8, op2_8;
  Bit8u op2_integrity;
  Expression *Op2Expr;
  Expression *Op1Expr;

  op1_8 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op2_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    }
  else {
    read_virtual_byte(i->seg(), RMAddr(i), &op2_8, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	read_virtual_expression(i->seg(), RMAddr(i), &Op2Expr);
	if (BX_CPU_THIS_PTR RMAddr_expression != NULL)
	{
		Expression *Etemp = NULL;
		Etemp = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op2Expr);
		Op2Expr = Etemp;
	}
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmCmp8(op1_8, op2_8, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit8u diff_8;
  diff_8 = op1_8 - op2_8;

  SET_FLAGS_OSZAPC_8_WITHEXPR(op1_8, op2_8, diff_8, BX_INSTR_CMP8, Op1Expr, Op2Expr);
#endif
}



  void
BX_CPU_C::CMP_ALIb(bxInstruction_c *i)
{
  Bit8u op1_8, op2_8;
  Expression *Op1Expr;
  Expression *Op2Expr;

  op1_8 = AL;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(0, 0);
  }
#endif

  op2_8 = i->Ib();
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = NULL;
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmCmp8(op1_8, op2_8, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit8u diff_8;
  diff_8 = op1_8 - op2_8;

  SET_FLAGS_OSZAPC_8_WITHEXPR(op1_8, op2_8, diff_8, BX_INSTR_CMP8, Op1Expr, Op2Expr);
#endif
}


  void
BX_CPU_C::XADD_EbGb(bxInstruction_c *i)
{
#if (BX_CPU_LEVEL >= 4) || (BX_CPU_LEVEL_HACKED >= 4)

  Bit8u op2, op1, sum;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;


  /* XADD dst(r/m8), src(r8)
   * temp <-- src + dst         | sum = op2 + op1
   * src  <-- dst               | op2 = op1
   * dst  <-- tmp               | op1 = sum
   */

  op2 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op2_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    sum = op1 + op2;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XADD_EbGb");
  }
#endif
    // and write destination into source
    // Note: if both op1 & op2 are registers, the last one written
    //       should be the sum, as op1 & op2 may be the same register.
    //       For example:  XADD AL, AL
    BX_WRITE_8BIT_REGx(i->nnn(), i->extend8bitL(), op1);
    BX_WRITE_8BIT_REG_INTEGRITY(i->nnn(), op1_integrity);
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), sum);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1, Op1Expr);
  	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, SumExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    sum = op1 + op2;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XADD_EbGb");
  }
#endif
    Write_RMW_virtual_byte(sum, result_integrity);
    /* and write destination into source */
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(i->seg(), RMAddr(i), SumExpr);
  }
#endif
    BX_WRITE_8BIT_REGx(i->nnn(), i->extend8bitL(), op1);
    BX_WRITE_8BIT_REG_INTEGRITY(i->nnn(), op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1, Op1Expr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_8(op1, op2, sum, BX_INSTR_XADD8);
#else
  BX_PANIC(("XADD_EbGb: not supported on < 80486"));
#endif
}


  void
BX_CPU_C::ADD_EbIb(bxInstruction_c *i)
{
  Bit8u op2, op1, sum;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op2 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) new Constant(i->Ib());
  }
#endif

  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    sum = op1 + op2;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_EbIb");
	else
	{
		SumExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), sum);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, SumExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    sum = op1 + op2;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_EbIb");
	else
	{
		SumExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif
    Write_RMW_virtual_byte(sum, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(i->seg(), RMAddr(i), SumExpr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_8(op1, op2, sum, BX_INSTR_ADD8);
}

  void
BX_CPU_C::ADC_EbIb(bxInstruction_c *i)
{
  Bit8u op2, op1, sum;
  bx_bool temp_CF;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  temp_CF = getB_CF();

  op2 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) new Constant(i->Ib());
  }
#endif

  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    sum = op1 + op2 + temp_CF;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_EbIb");
	else
	{
		SumExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), sum);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, SumExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    sum = op1 + op2 + temp_CF;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_EbIb");
	else
	{
		SumExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif
    Write_RMW_virtual_byte(sum, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(i->seg(), RMAddr(i), SumExpr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_8_CF(op1, op2, sum, BX_INSTR_ADC8,
                           temp_CF);
}


  void
BX_CPU_C::SUB_EbIb(bxInstruction_c *i)
{
  Bit8u op2_8, op1_8, diff_8;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  op2_8 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) new Constant(i->Ib());
  }
#endif

  if (i->modC0()) {
    op1_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    diff_8 = op1_8 - op2_8;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_EbIb");
	else
	{
		DiffExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), diff_8);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, DiffExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1_8, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    diff_8 = op1_8 - op2_8;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_EbIb");
	else
	{
		DiffExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
    Write_RMW_virtual_byte(diff_8, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(i->seg(), RMAddr(i), DiffExpr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_8(op1_8, op2_8, diff_8, BX_INSTR_SUB8);
}

  void
BX_CPU_C::CMP_EbIb(bxInstruction_c *i)
{
  Bit8u op2_8, op1_8;
  Bit8u op1_integrity;
  Expression *Op1Expr, *Op2Expr;
  
  op2_8 = i->Ib();
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = NULL;
  }
#endif

  if (i->modC0()) {
    op1_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    }
  else {
    read_virtual_byte(i->seg(), RMAddr(i), &op1_8, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);	
	if (BX_CPU_THIS_PTR RMAddr_expression != NULL)
	{
		Expression *Etemp = NULL;
		Etemp = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op1Expr);
		Op1Expr = Etemp;
	}

  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmCmp8(op1_8, op2_8, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit8u diff_8;
  diff_8 = op1_8 - op2_8;

  SET_FLAGS_OSZAPC_8_WITHEXPR(op1_8, op2_8, diff_8, BX_INSTR_CMP8, Op1Expr, Op2Expr);
#endif
}


  void
BX_CPU_C::NEG_Eb(bxInstruction_c *i)
{
  Bit8u op1_8, diff_8;
  Bit8u result_integrity;
  Bit8u op1_integrity;
  Expression *Op1Expr, *DiffExpr;

  if (i->modC0()) {
    op1_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    diff_8 = 0 - op1_8;
    result_integrity = op1_integrity;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		DiffExpr = (Expression *) new Operation(Op1Expr, NULL, "NEG_Eb");
	else
		DiffExpr = NULL;
  }
#endif
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), diff_8);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, DiffExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1_8, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    diff_8 = 0 - op1_8;
    result_integrity = op1_integrity;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		DiffExpr = (Expression *) new Operation(Op1Expr, NULL, "NEG_Eb");
	else
		DiffExpr = NULL;
  }
#endif
    Write_RMW_virtual_byte(diff_8, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(i->seg(), RMAddr(i), DiffExpr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_8(op1_8, 0, diff_8, BX_INSTR_NEG8);
}


  void
BX_CPU_C::INC_Eb(bxInstruction_c *i)
{
  Bit8u  op1;
  Bit8u result_integrity;
  Bit8u op1_integrity;
  Expression *Op1Expr, *DiffExpr;

  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    op1++;
    result_integrity = op1_integrity;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		DiffExpr = (Expression *) new Operation(Op1Expr, NULL, "INC_Eb");
	else
		DiffExpr = NULL;
  }
#endif
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), op1);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, DiffExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    op1++;
    result_integrity = op1_integrity;
    //if ((result_integrity != 0xFF) && (result_integrity != 0x00))
    	//printf("Great day in the morning %x\n", result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		DiffExpr = (Expression *) new Operation(Op1Expr, NULL, "INC_Eb");
	else
		DiffExpr = NULL;
  }
#endif
    Write_RMW_virtual_byte(op1, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(i->seg(), RMAddr(i), DiffExpr);
  }
#endif
    }

  SET_FLAGS_OSZAP_8(0, 0, op1, BX_INSTR_INC8);
}


  void
BX_CPU_C::DEC_Eb(bxInstruction_c *i)
{
  Bit8u op1_8;
  Bit8u result_integrity;
  Bit8u op1_integrity;
  Expression *Op1Expr, *DiffExpr;

  if (i->modC0()) {
    op1_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    op1_8--;
    result_integrity = op1_integrity;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		DiffExpr = (Expression *) new Operation(Op1Expr, NULL, "DEC_Eb");
	else
		DiffExpr = NULL;
  }
#endif
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), op1_8);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, DiffExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1_8, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    op1_8--;
    result_integrity = op1_integrity;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		DiffExpr = (Expression *) new Operation(Op1Expr, NULL, "DEC_Eb");
	else
		DiffExpr = NULL;
  }
#endif
    Write_RMW_virtual_byte(op1_8, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(i->seg(), RMAddr(i), DiffExpr);
  }
#endif
    }

  SET_FLAGS_OSZAP_8(0, 0, op1_8, BX_INSTR_DEC8);
}


  void
BX_CPU_C::CMPXCHG_EbGb(bxInstruction_c *i)
{
#if (BX_CPU_LEVEL >= 4) || (BX_CPU_LEVEL_HACKED >= 4)
  Bit8u op2_8, op1_8, diff_8;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr;


  if (i->modC0()) {
    op1_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if 0
BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1_8, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    }

#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(0, 0);
  }
#endif

  diff_8 = AL - op1_8;

  //op1_integrity = low_water_mark(op1_integrity, EAX_INTEGRITY, INTEG_BYTE, INTEG_BYTE);

  SET_FLAGS_OSZAPC_8_WITHEXPR(AL, op1_8, diff_8, BX_INSTR_CMP8, Op1Expr, Op2Expr);

  if (diff_8 == 0) {  // if accumulator == dest
    // ZF = 1
    set_ZF(1);
    // dest <-- src
    op2_8 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
    op2_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

    if (i->modC0()) {
      BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), op2_8);
      BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, Op2Expr);
  }
#endif
      }
    else {
      Write_RMW_virtual_byte(op2_8, op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	write_virtual_expression(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
      }
    }
  else {
    // ZF = 0
    set_ZF(0);
    // accumulator <-- dest
    AL = op1_8;
    //LVAL_EAX_INTEGRITY = op1_integrity;
    BX_WRITE_32BIT_REG_INTEGRITY(0, op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(0, 0, Op1Expr);
  }
#endif
    }

#else
  BX_PANIC(("CMPXCHG_EbGb:"));
#endif
}
