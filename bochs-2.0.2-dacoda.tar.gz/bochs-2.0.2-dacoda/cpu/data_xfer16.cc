/////////////////////////////////////////////////////////////////////////
// $Id: data_xfer16.cc,v 1.20 2002/10/25 18:26:27 sshwarts Exp $
/////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2001  MandrakeSoft S.A.
//
//    MandrakeSoft S.A.
//    43, rue d'Aboukir
//    75002 Paris - France
//    http://www.linux-mandrake.com/
//    http://www.mandrakesoft.com/
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA






#define NEED_CPU_REG_SHORTCUTS 1
#include "bochs.h"
#define LOG_THIS BX_CPU_THIS_PTR


  void
BX_CPU_C::MOV_RXIw(bxInstruction_c *i)
{
  BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].word.rx = i->Iw();
  BX_WRITE_32BIT_REG_INTEGRITY(i->opcodeReg(), IMMEDIATE_INTEGRITY);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->opcodeReg(), 0, NULL);
  	TheLabels.WriteSymbolicRegister(i->opcodeReg(), 1, NULL);
  }
#endif
}

  void
BX_CPU_C::XCHG_RXAX(bxInstruction_c *i)
{
  Bit16u temp16;
  Bit8u temp16_integrity;
  Expression *TempExpr[2];

  temp16 = AX;
  temp16_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TempExpr[0] = TheLabels.ReadSymbolicRegister(0, 0);
  	TempExpr[1] = TheLabels.ReadSymbolicRegister(0, 1);
  }
#endif
  AX = BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].word.rx;
  //LVAL_EAX_INTEGRITY = BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].reg_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].reg_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	 TheLabels.WriteSymbolicRegister(0, 0, MakeACopyOf(TheLabels.ReadSymbolicRegister(i->opcodeReg(), 0)));
  	 TheLabels.WriteSymbolicRegister(0, 1, MakeACopyOf(TheLabels.ReadSymbolicRegister(i->opcodeReg(), 1)));
  }
#endif
  BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].word.rx = temp16;
  //BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].reg_integrity = temp16_integrity;
  BX_WRITE_16BIT_REG_INTEGRITY(i->opcodeReg(), temp16_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	 TheLabels.WriteSymbolicRegister(i->opcodeReg(), 0, MakeACopyOf(TempExpr[0]));
  	 TheLabels.WriteSymbolicRegister(i->opcodeReg(), 1, MakeACopyOf(TempExpr[1]));
  }
#endif
}


  void
BX_CPU_C::MOV_EEwGw(bxInstruction_c *i)
{
  Bit16u op2_16;
  Bit8u op2_integrity;
  Expression *Op2Expr[2];

  op2_16 = BX_READ_16BIT_REG(i->nnn());
  op2_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr[0] = TheLabels.ReadSymbolicRegister(i->nnn(), 0);
  	Op2Expr[1] = TheLabels.ReadSymbolicRegister(i->nnn(), 1);
  }
#endif

  write_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(i->seg(), RMAddr(i), MakeACopyOf(Op2Expr[0]));
  	write_virtual_expression(i->seg(), RMAddr(i) + 1, MakeACopyOf(Op2Expr[1]));
  }
#endif
}

  void
BX_CPU_C::MOV_EGwGw(bxInstruction_c *i)
{
  Bit16u op2_16;
  Bit8u op2_integrity;
  Expression *Op2Expr[2];

  op2_16 = BX_READ_16BIT_REG(i->nnn());
  op2_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr[0] = TheLabels.ReadSymbolicRegister(i->nnn(), 0);
  	Op2Expr[1] = TheLabels.ReadSymbolicRegister(i->nnn(), 1);
  }
#endif

  BX_WRITE_16BIT_REG(i->rm(), op2_16);
  BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 0, MakeACopyOf(Op2Expr[0]));
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 1, MakeACopyOf(Op2Expr[1]));
  }
#endif
}


  void
BX_CPU_C::MOV_GwEGw(bxInstruction_c *i)
{
  // 2nd modRM operand Ex, is known to be a general register Gw.
  Bit16u op2_16;
  Bit8u op2_integrity;
  Expression *Op2Expr[2];

  op2_16 = BX_READ_16BIT_REG(i->rm());
  op2_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr[0] = TheLabels.ReadSymbolicRegister(i->rm(), 0);
  	Op2Expr[1] = TheLabels.ReadSymbolicRegister(i->rm(), 1);
  }
#endif
  BX_WRITE_16BIT_REG(i->nnn(), op2_16);
  BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 0, MakeACopyOf(Op2Expr[0]));
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 1, MakeACopyOf(Op2Expr[1]));
  }
#endif
}

  void
BX_CPU_C::MOV_GwEEw(bxInstruction_c *i)
{
  // 2nd modRM operand Ex, is known to be a memory operand, Ew.
  Bit16u op2_16;
  Bit8u op2_integrity;
  Expression *Op2Expr[2];

  read_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &(Op2Expr[0]));
  	read_virtual_expression(i->seg(), RMAddr(i) + 1, &(Op2Expr[1]));
	if (BX_CPU_THIS_PTR RMAddr_expression != NULL)
	{
		Op2Expr[0] = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op2Expr[0]);
		Op2Expr[1] = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op2Expr[1]);
	}
  }
#endif
  BX_WRITE_16BIT_REG(i->nnn(), op2_16);
  BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 0, MakeACopyOf(Op2Expr[0]));
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 1, MakeACopyOf(Op2Expr[1]));
  }
#endif
}

  void
BX_CPU_C::MOV_EwSw(bxInstruction_c *i)
{
  Bit16u seg_reg;
  Bit8u seg_reg_integrity;

#if BX_CPU_LEVEL < 3
  BX_PANIC(("MOV_EwSw: incomplete for CPU < 3"));
#endif

  seg_reg = BX_CPU_THIS_PTR sregs[i->nnn()].selector.value;
  seg_reg_integrity = BX_CPU_THIS_PTR sregs[i->nnn()].segreg_integrity;

  if (i->modC0()) {
    // ??? BX_WRITE_16BIT_REG(mem_addr, seg_reg);
    if ( i->os32L() ) {
      BX_WRITE_32BIT_REGZ(i->rm(), seg_reg);
      BX_WRITE_32BIT_REG_INTEGRITY(i->rm(), seg_reg_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	 TheLabels.WriteSymbolicRegister(i->rm(), 0, NULL);
  	 TheLabels.WriteSymbolicRegister(i->rm(), 1, NULL);
  	 TheLabels.WriteSymbolicRegister(i->rm(), 2, NULL);
  	 TheLabels.WriteSymbolicRegister(i->rm(), 3, NULL);
  }
#endif
      }
    else {
      BX_WRITE_16BIT_REG(i->rm(), seg_reg);
      BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), seg_reg_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	 TheLabels.WriteSymbolicRegister(i->rm(), 0, NULL);
  	 TheLabels.WriteSymbolicRegister(i->rm(), 1, NULL);
  }
#endif
      }
    }
  else {
    write_virtual_word(i->seg(), RMAddr(i), &seg_reg, &seg_reg_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(i->seg(), RMAddr(i), NULL);
  }
#endif
    }
}

  void
BX_CPU_C::MOV_SwEw(bxInstruction_c *i)
{
  Bit16u op2_16;
  Bit8u op2_integrity;

#if BX_CPU_LEVEL < 3
  BX_PANIC(("MOV_SwEw: incomplete for CPU < 3"));
#endif

  if (i->modC0()) {
    op2_16 = BX_READ_16BIT_REG(i->rm());
    op2_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
    }
  else {
    read_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
    }

  load_seg_reg(&BX_CPU_THIS_PTR sregs[i->nnn()], op2_16);
  BX_CPU_THIS_PTR sregs[i->nnn()].segreg_integrity = op2_integrity;

  if (i->nnn() == BX_SEG_REG_SS) {
    // MOV SS inhibits interrupts, debug exceptions and single-step
    // trap exceptions until the execution boundary following the
    // next instruction is reached.
    // Same code as POP_SS()
    BX_CPU_THIS_PTR inhibit_mask |=
      BX_INHIBIT_INTERRUPTS | BX_INHIBIT_DEBUG;
    BX_CPU_THIS_PTR async_event = 1;
    }
}

  void
BX_CPU_C::LEA_GwM(bxInstruction_c *i)
{
  if (i->modC0()) {
    BX_PANIC(("LEA_GvM: op2 is a register"));
    UndefinedOpcode(i);
    return;
    }

    BX_WRITE_16BIT_REG(i->nnn(), (Bit16u) RMAddr(i));
    BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), 0xFF /*BX_CPU_THIS_PTR RMAddr_integrity*/ /**/); /** should take a look at this? ***/
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 0, NULL);
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 1, NULL);
  }
#endif

}


  void
BX_CPU_C::MOV_AXOw(bxInstruction_c *i)
{
  Bit16u temp_16;
  bx_address addr;
  Bit8u temp_16_integrity;
  Expression *TempExpr[2];

  addr = i->Id();

  /* read from memory address */

  if (!BX_NULL_SEG_REG(i->seg())) {
    BX_CPU_THIS_PTR RMAddr_integrity = 0xFF;
    read_virtual_word(i->seg(), addr, &temp_16, &temp_16_integrity);
    /*if (addr != 0xFF)
    	temp_16_integrity = 0x00;*/
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), addr, &(TempExpr[0]));
  	read_virtual_expression(i->seg(), addr + 1, &(TempExpr[1]));
  }
#endif
    }
  else {
    BX_CPU_THIS_PTR RMAddr_integrity = 0xFF;
    read_virtual_word(BX_SEG_REG_DS, addr, &temp_16, &temp_16_integrity);
    /*if (addr != 0xFF)
    	temp_16_integrity = 0x00;*/
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(BX_SEG_REG_DS, addr, &(TempExpr[0]));
  	read_virtual_expression(BX_SEG_REG_DS, addr + 1, &(TempExpr[1]));
  }
#endif
    }

  /* write to register */
  AX = temp_16;
  //LVAL_EAX_INTEGRITY = temp_16_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, temp_16_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(0, 0, MakeACopyOf(TempExpr[0]));
  	TheLabels.WriteSymbolicRegister(0, 1, MakeACopyOf(TempExpr[1]));
  }
#endif
}


  void
BX_CPU_C::MOV_OwAX(bxInstruction_c *i)
{
  Bit16u temp_16;
  bx_address addr;
  Bit8u temp_16_integrity;
  Expression *TempExpr[2];

  addr = i->Id();

  /* read from register */
  temp_16 = AX;
  temp_16_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TempExpr[0] = TheLabels.ReadSymbolicRegister(0, 0);
  	TempExpr[1] = TheLabels.ReadSymbolicRegister(0, 1);
  }
#endif

  /* write to memory address */
  if (!BX_NULL_SEG_REG(i->seg())) {
    write_virtual_word(i->seg(), addr, &temp_16, &temp_16_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(i->seg(), addr, MakeACopyOf(TempExpr[0]));
  	write_virtual_expression(i->seg(), addr + 1, MakeACopyOf(TempExpr[1]));
  }
#endif
    }
  else {
    write_virtual_word(BX_SEG_REG_DS, addr, &temp_16, &temp_16_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(BX_SEG_REG_DS, addr, MakeACopyOf(TempExpr[0]));
  	write_virtual_expression(BX_SEG_REG_DS, addr + 1, MakeACopyOf(TempExpr[1]));
  }
#endif
    }
}



  void
BX_CPU_C::MOV_EwIw(bxInstruction_c *i)
{
    Bit16u op2_16;
    Bit8u op2_integrity;

    op2_16 = i->Iw();
    op2_integrity = IMMEDIATE_INTEGRITY /**/;

    /* now write sum back to destination */
    if (i->modC0()) {
      BX_WRITE_16BIT_REG(i->rm(), op2_16);
      BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->rm(), 0, NULL);
  	TheLabels.WriteSymbolicRegister(i->rm(), 1, NULL);
  }
#endif
      }
    else {
      write_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(i->seg(), RMAddr(i), NULL);
  	write_virtual_expression(i->seg(), RMAddr(i) + 1, NULL);
  }
#endif
      }
}


  void
BX_CPU_C::MOVZX_GwEb(bxInstruction_c *i)
{
#if BX_CPU_LEVEL < 3
  BX_PANIC(("MOVZX_GvEb: not supported on < 386"));
#else
  Bit8u  op2_8;
  Bit8u op2_integrity;
  Expression *Op2Expr[2];

  if (i->modC0()) {
    op2_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op2_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr[0] = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
	Op2Expr[1] = MakeACopyOf(Op2Expr[0]);
  }
#endif
    }
  else {
    /* pointer, segment address pair */
    read_virtual_byte(i->seg(), RMAddr(i), &op2_8, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &(Op2Expr[0]));
  	read_virtual_expression(i->seg(), RMAddr(i), &(Op2Expr[1]));
	if (BX_CPU_THIS_PTR RMAddr_expression != NULL)
	{
		Op2Expr[0] = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op2Expr[0]);
		Op2Expr[1] = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op2Expr[1]);
	}
	//Op2Expr[0] = NULL;
	//Op2Expr[1] = NULL;
  }
#endif
    }

    /* zero extend byte op2 into word op1 */
    BX_WRITE_16BIT_REG(i->nnn(), (Bit16u) op2_8);
    BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), (Bit16u) op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->nnn(), 0, MakeACopyOf(Op2Expr[0]));
  	TheLabels.WriteSymbolicRegister(i->nnn(), 1, MakeACopyOf(Op2Expr[1]));
  }
#endif
#endif /* BX_CPU_LEVEL < 3 */
}

  void
BX_CPU_C::MOVZX_GwEw(bxInstruction_c *i)
{
#if BX_CPU_LEVEL < 3
  BX_PANIC(("MOVZX_GvEw: not supported on < 386"));
#else
  Bit16u op2_16;
  Bit8u op2_integrity;
  Expression *Op2Expr[2];

  if (i->modC0()) {
    op2_16 = BX_READ_16BIT_REG(i->rm());
    op2_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr[0] = TheLabels.ReadSymbolicRegister(i->rm(), 0);
  	Op2Expr[1] = TheLabels.ReadSymbolicRegister(i->rm(), 1);
  }
#endif
    }
  else {
    /* pointer, segment address pair */
    read_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &(Op2Expr[0]));
  	read_virtual_expression(i->seg(), RMAddr(i) + 1, &(Op2Expr[1]));
	if (BX_CPU_THIS_PTR RMAddr_expression != NULL)
	{
		Op2Expr[0] = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op2Expr[0]);
		Op2Expr[1] = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op2Expr[1]);
	}
  }
#endif
    }

    /* normal move */
    BX_WRITE_16BIT_REG(i->nnn(), op2_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 0, MakeACopyOf(Op2Expr[0]));
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 1, MakeACopyOf(Op2Expr[1]));
  }
#endif

#endif /* BX_CPU_LEVEL < 3 */
}

  void
BX_CPU_C::MOVSX_GwEb(bxInstruction_c *i)
{
#if BX_CPU_LEVEL < 3
  BX_PANIC(("MOVSX_GvEb: not supported on < 386"));
#else
  Bit8u op2_8;
  Bit8u op2_integrity;
  Expression *Op2Expr[2];

  if (i->modC0()) {
    op2_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op2_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr[0] = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
	Op2Expr[1] = Op2Expr[0];
  }
#endif
    }
  else {
    /* pointer, segment address pair */
    read_virtual_byte(i->seg(), RMAddr(i), &op2_8, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &(Op2Expr[0]));
  	read_virtual_expression(i->seg(), RMAddr(i), &(Op2Expr[1]));
	if (BX_CPU_THIS_PTR RMAddr_expression != NULL)
	{
		Op2Expr[0] = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op2Expr[0]);
		Op2Expr[1] = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op2Expr[1]);
	}
  }
#endif
    }

    /* sign extend byte op2 into word op1 */
    BX_WRITE_16BIT_REG(i->nnn(), (Bit8s) op2_8);
    BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 0, MakeACopyOf(Op2Expr[0]));
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 1, MakeACopyOf(Op2Expr[1]));
  }
#endif

#endif /* BX_CPU_LEVEL < 3 */
}

  void
BX_CPU_C::MOVSX_GwEw(bxInstruction_c *i)
{
#if BX_CPU_LEVEL < 3
  BX_PANIC(("MOVSX_GvEw: not supported on < 386"));
#else
  Bit16u op2_16;
  Bit8u op2_integrity;
  Expression *Op2Expr[2];

  if (i->modC0()) {
    op2_16 = BX_READ_16BIT_REG(i->rm());
    op2_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr[0] = TheLabels.ReadSymbolicRegister(i->rm(), 0);
  	Op2Expr[1] = TheLabels.ReadSymbolicRegister(i->rm(), 1);
  }
#endif
    }
  else {
    /* pointer, segment address pair */
    read_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &(Op2Expr[0]));
  	read_virtual_expression(i->seg(), RMAddr(i) + 1, &(Op2Expr[1]));
	if (BX_CPU_THIS_PTR RMAddr_expression != NULL)
	{
		Op2Expr[0] = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op2Expr[0]);
		Op2Expr[1] = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op2Expr[1]);
	}
  }
#endif
    }

    /* normal move */
    BX_WRITE_16BIT_REG(i->nnn(), op2_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 0, MakeACopyOf(Op2Expr[0]));
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 1, MakeACopyOf(Op2Expr[1]));
  }
#endif

#endif /* BX_CPU_LEVEL < 3 */
}


  void
BX_CPU_C::XCHG_EwGw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr[2];
  Expression *Op2Expr[2];

#ifdef MAGIC_BREAKPOINT
#if BX_DEBUGGER
  // (mch) Magic break point
  if (i->nnn() == 3 && i->modC0() && i->rm() == 3) {
    BX_CPU_THIS_PTR magic_break = 1;
    }
#endif
#endif

    /* op2_16 is a register, op2_addr is an index of a register */
    op2_16 = BX_READ_16BIT_REG(i->nnn());
    op2_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr[0] = TheLabels.ReadSymbolicRegister(i->nnn(), 0);
  	Op2Expr[1] = TheLabels.ReadSymbolicRegister(i->nnn(), 1);
  }
#endif

    /* op1_16 is a register or memory reference */
    if (i->modC0()) {
      op1_16 = BX_READ_16BIT_REG(i->rm());
      op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr[0] = TheLabels.ReadSymbolicRegister(i->rm(), 0);
  	Op1Expr[1] = TheLabels.ReadSymbolicRegister(i->rm(), 1);
  }
#endif
      BX_WRITE_16BIT_REG(i->rm(), op2_16);
      BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	 TheLabels.WriteSymbolicRegister(i->rm(), 0, MakeACopyOf(Op2Expr[0]));
  	 TheLabels.WriteSymbolicRegister(i->rm(), 1, MakeACopyOf(Op2Expr[1]));
  }
#endif
      }
    else {
      /* pointer, segment address pair */
      read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &(Op1Expr[0]));
  	read_virtual_expression(i->seg(), RMAddr(i) + 1, &(Op1Expr[1]));
	if (BX_CPU_THIS_PTR RMAddr_expression != NULL)
	{
		Op1Expr[0] = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op1Expr[0]);
		Op1Expr[1] = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op1Expr[1]);
	}
  }
#endif
      Write_RMW_virtual_word(op2_16, op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(i->seg(), RMAddr(i), MakeACopyOf(Op2Expr[0]));
  	write_virtual_expression(i->seg(), RMAddr(i) + 1, MakeACopyOf(Op2Expr[1]));
  }
#endif
      }

    BX_WRITE_16BIT_REG(i->nnn(), op1_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 0, MakeACopyOf(Op1Expr[0]));
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 1, MakeACopyOf(Op1Expr[1]));
  }
#endif
}


  void
BX_CPU_C::CMOV_GwEw(bxInstruction_c *i)
{
#if (BX_CPU_LEVEL >= 6) || (BX_CPU_LEVEL_HACKED >= 6)
  // Note: CMOV accesses a memory source operand (read), regardless
  //       of whether condition is true or not.  Thus, exceptions may
  //       occur even if the MOV does not take place.

  bx_bool condition;
  Bit16u op2_16;
  Bit8u op2_integrity;
  Expression *Op2Expr[2];

  switch (i->b1()) {
    // CMOV opcodes:
    case 0x140: condition = get_OF(); break;
    case 0x141: condition = !get_OF(); break;
    case 0x142: condition = get_CF(); break;
    case 0x143: condition = !get_CF(); break;
    case 0x144: condition = get_ZF(); break;
    case 0x145: condition = !get_ZF(); break;
    case 0x146: condition = get_CF() || get_ZF(); break;
    case 0x147: condition = !get_CF() && !get_ZF(); break;
    case 0x148: condition = get_SF(); break;
    case 0x149: condition = !get_SF(); break;
    case 0x14A: condition = get_PF(); break;
    case 0x14B: condition = !get_PF(); break;
    case 0x14C: condition = getB_SF() != getB_OF(); break;
    case 0x14D: condition = getB_SF() == getB_OF(); break;
    case 0x14E: condition = get_ZF() || (getB_SF() != getB_OF()); break;
    case 0x14F: condition = !get_ZF() && (getB_SF() == getB_OF()); break;
    default:
      condition = 0;
      BX_PANIC(("CMOV_GwEw: default case"));
    }

  if (i->modC0()) {
    op2_16 = BX_READ_16BIT_REG(i->rm());
    op2_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr[0] = TheLabels.ReadSymbolicRegister(i->nnn(), 0);
  	Op2Expr[1] = TheLabels.ReadSymbolicRegister(i->nnn(), 1);
  }
#endif
    }
  else {
    /* pointer, segment address pair */
    read_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &(Op2Expr[0]));
  	read_virtual_expression(i->seg(), RMAddr(i) + 1, &(Op2Expr[1]));
	if (BX_CPU_THIS_PTR RMAddr_expression != NULL)
	{
		Op2Expr[0] = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op2Expr[0]);
		Op2Expr[1] = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op2Expr[1]);
	}
  }
#endif
    }

  if (condition) {
    BX_WRITE_16BIT_REG(i->nnn(), op2_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 0, MakeACopyOf(Op2Expr[0]));
  	 TheLabels.WriteSymbolicRegister(i->nnn(), 1, MakeACopyOf(Op2Expr[1]));
  }
#endif

    }
#else
  BX_INFO(("cmov_gwew called"));
  UndefinedOpcode(i);
#endif
}
