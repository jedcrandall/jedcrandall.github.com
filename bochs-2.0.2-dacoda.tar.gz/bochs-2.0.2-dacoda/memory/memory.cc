/////////////////////////////////////////////////////////////////////////
// $Id: memory.cc,v 1.25 2002/11/03 17:17:11 vruppert Exp $
/////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2001  MandrakeSoft S.A.
//
//    MandrakeSoft S.A.
//    43, rue d'Aboukir
//    75002 Paris - France
//    http://www.linux-mandrake.com/
//    http://www.mandrakesoft.com/
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA







#include "bochs.h"
#define LOG_THIS BX_MEM_THIS


Bit8u low_water_mark(Bit8u op1_integrity, Bit8u op2_integrity, Bit8u op1_length, Bit8u op2_length)
{
	if (op1_integrity && op2_integrity)
		return 0xFF;
	else
		return 0x00;
}

void set_integ_bit(Bit32u thea20addr, Bit8u *integrity_bits, Bit8u integ_write, Bit8u size)
{

	if (integ_write == 0xFF)
		integrity_bits[thea20addr >> 2] = 0xFF;
	else
		integrity_bits[thea20addr >> 2] = 0x00;
}

Bit8u get_integ_bit(Bit32u thea20addr, Bit8u *integrity_bits, Bit8u size)
{

	if (integrity_bits[thea20addr >> 2] == 0xFF)
		return 0xFF;
	else
		return 0x00;
}

  void
BX_MEM_C::MeasureEntropy()
{
#if 0
	int LoopPages, LoopWords;
	int NumberAllHigh;
	int NumberAllLow;
	int StillAllHigh;
	int StillAllLow;
	//printf("Hola\n");
	
	NumberAllHigh = 0;
	NumberAllLow = 0;
	for (LoopPages = 0; LoopPages < (len / 32/*4096*/); LoopPages++)
	{
		StillAllHigh = 1;
		StillAllLow = 1;
		for (LoopWords = 0; LoopWords < 4/*1024*/; LoopWords++)
		{
			if (!integrity_bits[LoopPages * 8/*1024*/ + LoopWords])
				StillAllHigh = 0;
			else
				StillAllLow = 0;
		}
		if (StillAllHigh) NumberAllHigh++;
		if (StillAllLow) NumberAllLow++;
		
	}
	printf("Compress %d + %d = %d out of %d = %2.2f percent\n", NumberAllHigh, NumberAllLow, NumberAllHigh + NumberAllLow, len / 32/*4096*/, (double) (NumberAllHigh + NumberAllLow) * 100.0 / (double) (len / 32/*4096*/));

	int Loop;
	int TotalOnes = 0, TotalZeroes = 0;
	int NextWasAlsoZero = 0, NextWasAlsoOne = 0;
	
	for (Loop = 1; Loop < len / 4; Loop++)
	{
		if (integrity_bits[Loop])
		{
			TotalOnes++;
			if (integrity_bits[Loop - 1])
				NextWasAlsoOne++;
		}
		else
		{
			TotalZeroes++;
			if (!integrity_bits[Loop - 1])
				NextWasAlsoZero++;
		}

	}

	printf("Zeros: %2.2f percent, Ones: %2.2f percent\n", (double) NextWasAlsoZero / (double) TotalZeroes * 100.0, (double) NextWasAlsoOne / (double) TotalOnes * 100.0);
#endif
	int Loop;
	int Ones = 0;
	int Zeroes = 0;

	for (Loop = 0; Loop < len / 4; Loop++)
	{
		if (integrity_bits[Loop])
			Ones++;
		else
			Zeroes++;
	}
	printf("%d\t%d\t%2.2f\t%d\n", Zeroes, Ones, (double) Zeroes / (double) (Zeroes + Ones), TimeStamp);
	fflush(stdout);
	TimeStamp++;
}

#if BX_PROVIDE_CPU_MEMORY

  void
BX_MEM_C::writePhysicalPage(BX_CPU_C *cpu, Bit32u addr, unsigned len, void *data, void *integrity)
{
  Bit8u *data_ptr;
  Bit32u integrity_ptr;
  Bit32u a20addr;

  // Note: accesses should always be contained within a single page now.

#if BX_IODEBUG_SUPPORT
  bx_iodebug_c::mem_write( cpu, addr, len, data);
#endif

  a20addr = A20ADDR(addr);
#if 0
    BX_PANIC(("Error: Bit32u != a20addr"));
#endif
  BX_INSTR_PHY_WRITE(a20addr, len);

//  if (*(Bit8u *)integrity != 0xFF)
  //	BX_PANIC(("Aha!"));
  
 
  
/*  if ((*(Bit32u *)data == 0x400c4f10) && ((*(Bit8u *)integrity != 0xFF)))
  	BX_PANIC(("Thar she blows"));*/
  
/***  if (cpu->dr7 & 0x000000ff)
  {
  	*(Bit8u *)integrity = 0xFF;
  }***/
  
  //if (*(Bit8u *)integrity != 0xFF && cpu->sregs[BX_SEG_REG_CS].selector.rpl != 0)
  //{
  //	BX_PANIC(("Eck!!!!!!!!!!!!!!!!!!"));
  //}

#if BX_DEBUGGER
  // (mch) Check for physical write break points, TODO
  // (bbd) Each breakpoint should have an associated CPU#, TODO
  for (int i = 0; i < num_write_watchpoints; i++)
        if (write_watchpoint[i] == a20addr) {
	      BX_CPU(0)->watchpoint = a20addr;
              BX_CPU(0)->break_point = BREAK_POINT_WRITE;
              break;
        }
#endif

#if BX_SupportICache
  if (a20addr < BX_MEM_THIS len)
    cpu->iCache.decWriteStamp(cpu, a20addr);
#endif

//  if ((*(Bit8u *)integrity != 0xFF) && (*(Bit8u *)integrity != 0x00))
//  	BX_PANIC(("Somthing funky going on here"));

  /***if (*(Bit8u *)integrity != 0xFF)// && (cpu->sregs[BX_SEG_REG_CS].selector.rpl != 0))
  {
  	BX_PANIC(("I'm going to R-U-N-N-O-F-T"));
  }***/

  if ( a20addr <= BX_MEM_THIS len ) {
    // all of data is within limits of physical memory
    if ( (a20addr & 0xfff80000) != 0x00080000 ) {
      if (len == 4) {
/*  if ((cpu->sregs[BX_SEG_REG_CS].selector.rpl != 0) && (cpu->RMAddr_integrity == 0x00))
  {
  	*(Bit8u *)integrity = 0x00;
  }*/
      	//if (cpu->get_EIP() < 0x48000)
	//	(*(Bit8u *)integrity) = 0xff;
	/**************
	if (((*(Bit8u*)data) == 0x08 || (*(Bit8u*)data) == 0x40) && (*(Bit8u *)integrity == 0x00))
	{
		if (cpu->dword.eip >= 0x40000000) || (cpu->dword.eip < 0x08000000))
		{
			(*(Bit8u *)integrity) = 0xFF;	
		}
	}******************************/
        WriteHostDWordToLittleEndian(&vector[a20addr], *(Bit32u*)data);
/***        set_bit((Bit32u) a20addr, (Bit8u *) integrity_bits, get_bit(0, (Bit8u *) integrity));
        set_bit((Bit32u) a20addr + 1, (Bit8u *) integrity_bits, get_bit(1, (Bit8u *) integrity));
        set_bit((Bit32u) a20addr + 2, (Bit8u *) integrity_bits, get_bit(2, (Bit8u *) integrity));
        set_bit((Bit32u) a20addr + 3, (Bit8u *) integrity_bits, get_bit(3, (Bit8u *) integrity));***/
	//if (cpu->dword.eip >= 0xC0000000)//((cpu->dword.eip >= 0x40000000) || (cpu->dword.eip < 0x08000000))
	//	set_integ_bit(a20addr, integrity_bits, 0xFF /*** *(Bit8u *)integrity ***/, 4);
	//else
	set_integ_bit(a20addr, integrity_bits, *(Bit8u *)integrity, 4);

	//if (*(Bit32u *)data == 0x0804a750)
	//	BX_PANIC(("gotcha"));


        BX_DBG_DIRTY_PAGE(a20addr >> 12);
        return;
        }
      if (len == 2) {
/***        set_bit((Bit32u) a20addr, (Bit8u *) integrity_bits, get_bit(0, (Bit8u *) integrity));
        set_bit((Bit32u) a20addr + 1, (Bit8u *) integrity_bits, get_bit(1, (Bit8u *) integrity));****/
	//set_integ_bit(a20addr, integrity_bits, *(Bit8u *)integrity, 2);
	//if ((!get_integ_bit(a20addr, integrity_bits, 2) && (!(a20addr % 2)) /*&& (vector[a20addr + 2] == 0) && (vector[a20addr + 3] == 0)*/)  || (cpu->sregs[BX_SEG_REG_CS].selector.rpl == 0))
	
	if (1)//cpu->sregs[BX_SEG_REG_CS].selector.rpl == 0)
	{
		set_integ_bit(a20addr, integrity_bits, *(Bit8u *)integrity, 1);
		//if ((cpu->sregs[BX_SEG_REG_CS].selector.rpl != 0) && ((vector[a20addr + 2] != 0) || (vector[a20addr + 3] != 0)))
		//	printf("%c%c%c%c\n", vector[a20addr], vector[a20addr + 1], vector[a20addr + 2], vector[a20addr + 3]);
	}
	else
		set_integ_bit(a20addr, integrity_bits, low_water_mark(*(Bit8u *)integrity, get_integ_bit(a20addr, integrity_bits, 2), INTEG_WORD, INTEG_WORD), 1);

	WriteHostWordToLittleEndian(&vector[a20addr], *(Bit16u*)data);

        BX_DBG_DIRTY_PAGE(a20addr >> 12);
        return;
        }
      if (len == 1) {


	* ((Bit8u *) (&vector[a20addr])) = * (Bit8u *) data;
/**        set_bit((Bit32u) a20addr, (Bit8u *) integrity_bits, get_bit(0, (Bit8u *) integrity));***/

	//if ((!get_integ_bit(a20addr, integrity_bits, 1) && (!(a20addr % 4)) && (vector[a20addr + 1] == 0) && (vector[a20addr + 2] == 0) && (vector[a20addr + 3] == 0)) ||
	if (1)//cpu->sregs[BX_SEG_REG_CS].selector.rpl == 0)
		set_integ_bit(a20addr, integrity_bits, *(Bit8u *)integrity, 1);
	else
		set_integ_bit(a20addr, integrity_bits, low_water_mark(*(Bit8u *)integrity, get_integ_bit(a20addr, integrity_bits, 1), INTEG_BYTE, INTEG_BYTE), 1);

        BX_DBG_DIRTY_PAGE(a20addr >> 12);
        return;
        }
      // len == other, just fall thru to special cases handling
      }

#ifdef BX_LITTLE_ENDIAN
  data_ptr = (Bit8u *) data;
  integrity_ptr = 0;
#else // BX_BIG_ENDIAN
  BX_PANIC(("Error: I didn't write this stuff for big endian"));
  data_ptr = (Bit8u *) data + (len - 1);
#endif

write_one:
    if ( (a20addr & 0xfff80000) != 0x00080000 ) {
      // addr *not* in range 00080000 .. 000FFFFF
      vector[a20addr] = *data_ptr;
      set_integ_bit(a20addr, integrity_bits, *(Bit8u *)integrity, 1);
/***      set_bit(a20addr, integrity_bits, get_bit(integrity_ptr, (Bit8u *) integrity));***/
      BX_DBG_DIRTY_PAGE(a20addr >> 12);
inc_one:
      if (len == 1) return;
      len--;
      a20addr++;
#ifdef BX_LITTLE_ENDIAN
      data_ptr++;
      integrity_ptr++;
#else // BX_BIG_ENDIAN
      data_ptr--;
#endif
      goto write_one;
      }

    // addr in range 00080000 .. 000FFFFF

    if (a20addr <= 0x0009ffff) {
      // regular memory 80000 .. 9FFFF
      vector[a20addr] = *data_ptr;
      set_integ_bit(a20addr, integrity_bits, *(Bit8u *)integrity, 1);
      BX_DBG_DIRTY_PAGE(a20addr >> 12);
      goto inc_one;
      }
    if (a20addr <= 0x000bffff) {
      // VGA memory A0000 .. BFFFF
      DEV_vga_mem_write(a20addr, *data_ptr);
      BX_DBG_DIRTY_PAGE(a20addr >> 12);
      BX_DBG_UCMEM_REPORT(a20addr, 1, BX_WRITE, *data_ptr); // obsolete
      goto inc_one;
      }
    // adapter ROM     C0000 .. DFFFF
    // ROM BIOS memory E0000 .. FFFFF
    // (ignore write)
    //BX_INFO(("ROM lock %08x: len=%u",
    //  (unsigned) a20addr, (unsigned) len));
#if BX_PCI_SUPPORT == 0
#if BX_SHADOW_RAM
    // Write it since its in shadow RAM
    vector[a20addr] = *data_ptr;
    set_integ_bit(a20addr, integrity_bits, *(Bit8u *)integrity, 1);
    BX_DBG_DIRTY_PAGE(a20addr >> 12);
#else
    // ignore write to ROM
#endif
#else
    // Write Based on 440fx Programming
    if (bx_options.Oi440FXSupport->get () &&
        ((a20addr >= 0xC0000) && (a20addr <= 0xFFFFF))) {
      switch (DEV_pci_wr_memtype(a20addr & 0xFC000)) {
        case 0x1:   // Writes to ShadowRAM
//        BX_INFO(("Writing to ShadowRAM %08x, len %u ! ", (unsigned) a20addr, (unsigned) len));
          shadow[a20addr - 0xc0000] = *data_ptr;
          BX_DBG_DIRTY_PAGE(a20addr >> 12);
          goto inc_one;

        case 0x0:   // Writes to ROM, Inhibit
          BX_DEBUG(("Write to ROM ignored: address %08x, data %02x", (unsigned) a20addr, *data_ptr));
          goto inc_one;
        default:
          BX_PANIC(("writePhysicalPage: default case"));
          goto inc_one;
        }
      }
#endif
    goto inc_one;
    }

  else {
    // some or all of data is outside limits of physical memory
    unsigned i;

#ifdef BX_LITTLE_ENDIAN
  data_ptr = (Bit8u *) data;
#else // BX_BIG_ENDIAN
  data_ptr = (Bit8u *) data + (len - 1);
#endif


#if BX_SUPPORT_VBE
    // Check VBE LFB support

    if ((a20addr >= VBE_DISPI_LFB_PHYSICAL_ADDRESS) &&
        (a20addr <  (VBE_DISPI_LFB_PHYSICAL_ADDRESS +  VBE_DISPI_TOTAL_VIDEO_MEMORY_BYTES)))
    {
      for (i = 0; i < len; i++) {

        //if (a20addr < BX_MEM_THIS len) {
          //vector[a20addr] = *data_ptr;
          //BX_DBG_DIRTY_PAGE(a20addr >> 12);
          DEV_vga_mem_write(a20addr, *data_ptr);
        //  }

        // otherwise ignore byte, since it overruns memory
        addr++;
        a20addr = (addr);
#ifdef BX_LITTLE_ENDIAN
        data_ptr++;
#else // BX_BIG_ENDIAN
        data_ptr--;
#endif
      }
      return;
    }

#endif


#if BX_SUPPORT_APIC
    bx_generic_apic_c *local_apic = &cpu->local_apic;
    bx_generic_apic_c *ioapic = bx_devices.ioapic;
    if (local_apic->is_selected (a20addr, len)) {
      local_apic->write (a20addr, (Bit32u *)data, len);
      return;
    } else if (ioapic->is_selected (a20addr, len)) {
      ioapic->write (a20addr, (Bit32u *)data, len);
      return;
    }
    else
#endif
    for (i = 0; i < len; i++) {
      if (a20addr < BX_MEM_THIS len) {
        vector[a20addr] = *data_ptr;
      set_integ_bit(a20addr, integrity_bits, *(Bit8u *)integrity, 1);
        BX_DBG_DIRTY_PAGE(a20addr >> 12);
        }
      // otherwise ignore byte, since it overruns memory
      addr++;
      a20addr = (addr);
#ifdef BX_LITTLE_ENDIAN
      data_ptr++;
#else // BX_BIG_ENDIAN
      data_ptr--;
#endif
      }
    return;
    }
}


  void
BX_MEM_C::readPhysicalPage(BX_CPU_C *cpu, Bit32u addr, unsigned len, void *data, void *integrity)
{
  Bit8u *data_ptr;
  Bit32u a20addr;
  Bit32u integrity_ptr;

#if BX_IODEBUG_SUPPORT
  bx_iodebug_c::mem_read( cpu, addr, len, data);
#endif


  (*(Bit8u *)integrity) = 0xFF;

  a20addr = A20ADDR(addr);
  BX_INSTR_PHY_READ(a20addr, len);

#if BX_DEBUGGER
  // (mch) Check for physical read break points, TODO
  // (bbd) Each breakpoint should have an associated CPU#, TODO
  for (int i = 0; i < num_read_watchpoints; i++)
        if (read_watchpoint[i] == a20addr) {
	      BX_CPU(0)->watchpoint = a20addr;
              BX_CPU(0)->break_point = BREAK_POINT_READ;
              break;
        }
#endif

  if ( (a20addr + len) <= BX_MEM_THIS len ) {
    // all of data is within limits of physical memory
    if ( (a20addr & 0xfff80000) != 0x00080000 ) {
      if (len == 4) {
        ReadHostDWordFromLittleEndian(&vector[a20addr], * (Bit32u*) data);
/****	*((Bit8u *)integrity) = (get_bit(a20addr % 4, integrity_bits) << 7) |
                     (get_bit(a20addr % 4 + 1, integrity_bits) << 6) |
                     (get_bit(a20addr % 4 + 2, integrity_bits) << 5) |
                     (get_bit(a20addr % 4 + 3, integrity_bits) << 4);***/

	/*if (!get_integ_bit(a20addr, integrity_bits, 4))
		{
		printf("a20addr is %d\n", a20addr);
		BX_PANIC(("Another reason to panic"));
		}*/
	(*(Bit8u *)integrity) = get_integ_bit(a20addr, integrity_bits, 4);

	/*if ( (* (Bit32u*) data) == 0x08138de0) //BX_PANIC(("Panic, panic, panic"));
	{
		printf("Integrity was %d @ %08x from %08x\n", (*(Bit8u *)integrity), cpu->dword.eip, a20addr);
		//if (cpu->dword.eip < 0x40000000) BX_PANIC(("Panic, panic"));
	}*/

	/**if ((* (Bit32u*) data == 0xc0107238) && ((*(Bit8u *)integrity) != 0xFF))
	{
		printf("Address is %08x\n", a20addr);
		(*(Bit8u *)integrity) = 0xFF;
	}**/
      //(*(Bit8u *)integrity) = 0xFF;
	/*if (((*(Bit8u *)integrity) == 0x66) && ((* (Bit32u*) data) != 0))
	{
		printf("Monkey business reading %d from %08x\n", (* (Bit32u*) data), a20addr);
		set_integ_bit(a20addr, integrity_bits, 0xFF, 4);
	}*/


        return;
        }
      if (len == 2) {
        ReadHostWordFromLittleEndian(&vector[a20addr], * (Bit16u*) data);
/***	*((Bit8u *)integrity) = (get_bit(a20addr % 2, integrity_bits) << 7) |
                     (get_bit(a20addr % 2 + 1, integrity_bits) << 6);***/
	(*(Bit8u *)integrity) = get_integ_bit(a20addr, integrity_bits, 2);
	/*if ((*(Bit8u *)integrity) == 0x66)
	{
		printf("Monkey business reading %d from %08x\n", (* (Bit32u*) data), a20addr);
		set_integ_bit(a20addr, integrity_bits, 0xFF, 2);
	}*/
  if (cpu->RMAddr_integrity != 0xFF)
  {
  	*(Bit8u *)integrity = 0x00;
  }
        return;
        }
      if (len == 1) {
        * (Bit8u *) data =  * ((Bit8u *) (&vector[a20addr]));
/***	*((Bit8u *)integrity) = (get_bit(a20addr, integrity_bits) << 7);***/
	(*(Bit8u *)integrity) = get_integ_bit(a20addr, integrity_bits, 1);
	/*if ((*(Bit8u *)integrity) == 0x66)
	{
		printf("Monkey business reading %d from %08x\n", (* (Bit32u*) data), a20addr);
		set_integ_bit(a20addr, integrity_bits, 0xFF, 1);
	}*/

  if (cpu->RMAddr_integrity != 0xFF)
  {
  	*(Bit8u *)integrity = 0x00;
  }
        return;
        }
      // len == 3 case can just fall thru to special cases handling
      }


#ifdef BX_LITTLE_ENDIAN
    data_ptr = (Bit8u *) data;
      //(*(Bit8u *)integrity) = 0xFF;
#else // BX_BIG_ENDIAN
    data_ptr = (Bit8u *) data + (len - 1);
#endif



read_one:
    if ( (a20addr & 0xfff80000) != 0x00080000 ) {
      // addr *not* in range 00080000 .. 000FFFFF
      *data_ptr = vector[a20addr];
/**      set_bit(integrity_ptr, (Bit8u *) integrity, get_bit(a20addr, integrity_bits));****/
inc_one:
      if (len == 1)
      {
      (*(Bit8u *)integrity) = 0xFF;
      	return;
	}
      len--;
      a20addr++;
#ifdef BX_LITTLE_ENDIAN
      data_ptr++;
      //integrity_ptr++;
#else // BX_BIG_ENDIAN
      data_ptr--;
#endif
      goto read_one;
      }

    // addr in range 00080000 .. 000FFFFF
#if BX_PCI_SUPPORT == 0
    if ((a20addr <= 0x0009ffff) || (a20addr >= 0x000c0000) ) {
      // regular memory 80000 .. 9FFFF, C0000 .. F0000
      *data_ptr = vector[a20addr];
      goto inc_one;
      }
    // VGA memory A0000 .. BFFFF
    *data_ptr = DEV_vga_mem_read(a20addr);
    BX_DBG_UCMEM_REPORT(a20addr, 1, BX_READ, *data_ptr); // obsolete
    goto inc_one;
#else   // #if BX_PCI_SUPPORT == 0
    if (a20addr <= 0x0009ffff) {
      *data_ptr = vector[a20addr];
      goto inc_one;
      }
    if (a20addr <= 0x000BFFFF) {
      // VGA memory A0000 .. BFFFF
      *data_ptr = DEV_vga_mem_read(a20addr);
      BX_DBG_UCMEM_REPORT(a20addr, 1, BX_READ, *data_ptr);
      goto inc_one;
      }

    // a20addr in C0000 .. FFFFF
    if (!bx_options.Oi440FXSupport->get ()) {
      *data_ptr = vector[a20addr];
      goto inc_one;
      }
    else {
      switch (DEV_pci_rd_memtype(a20addr & 0xFC000)) {
        case 0x1:   // Read from ShadowRAM
          *data_ptr = shadow[a20addr - 0xc0000];
          BX_INFO(("Reading from ShadowRAM %08x, Data %02x ", (unsigned) a20addr, *data_ptr));
          goto inc_one;

        case 0x0:   // Read from ROM
          *data_ptr = vector[a20addr];
          //BX_INFO(("Reading from ROM %08x, Data %02x  ", (unsigned) a20addr, *data_ptr));
          goto inc_one;
        default:
          BX_PANIC(("::readPhysicalPage: default case"));
        }
      }
    goto inc_one;
#endif  // #if BX_PCI_SUPPORT == 0
    }
  else {
    // some or all of data is outside limits of physical memory
    unsigned i;

#ifdef BX_LITTLE_ENDIAN
    data_ptr = (Bit8u *) data;
#else // BX_BIG_ENDIAN
    data_ptr = (Bit8u *) data + (len - 1);
#endif

#if BX_SUPPORT_VBE
    // Check VBE LFB support

    if ((a20addr >= VBE_DISPI_LFB_PHYSICAL_ADDRESS) &&
        (a20addr <  (VBE_DISPI_LFB_PHYSICAL_ADDRESS +  VBE_DISPI_TOTAL_VIDEO_MEMORY_BYTES)))
    {
      for (i = 0; i < len; i++) {

        //if (a20addr < BX_MEM_THIS len) {
          //vector[a20addr] = *data_ptr;
          //BX_DBG_DIRTY_PAGE(a20addr >> 12);
          *data_ptr = DEV_vga_mem_read(a20addr);
        //  }

        // otherwise ignore byte, since it overruns memory
        addr++;
        a20addr = (addr);
#ifdef BX_LITTLE_ENDIAN
        data_ptr++;
#else // BX_BIG_ENDIAN
        data_ptr--;
#endif
      }
      (*(Bit8u *)integrity) = 0xFF;
      return;
    }

#endif


#if BX_SUPPORT_APIC
    bx_generic_apic_c *local_apic = &cpu->local_apic;
    bx_generic_apic_c *ioapic = bx_devices.ioapic;
    if (local_apic->is_selected (addr, len)) {
      local_apic->read (addr, data, len);
      (*(Bit8u *)integrity) = 0xFF;
      return;
    } else if (ioapic->is_selected (addr, len)) {
      ioapic->read (addr, data, len);
      (*(Bit8u *)integrity) = 0xFF;
      return;
    }
#endif
    for (i = 0; i < len; i++) {
#if BX_PCI_SUPPORT == 0
      if (a20addr < BX_MEM_THIS len)
        *data_ptr = vector[a20addr];
      else
        *data_ptr = 0xff;
#else   // BX_PCI_SUPPORT == 0
      if (a20addr < BX_MEM_THIS len) {
        if ((a20addr >= 0x000C0000) && (a20addr <= 0x000FFFFF)) {
          if (!bx_options.Oi440FXSupport->get ())
            *data_ptr = vector[a20addr];
          else {
            switch (DEV_pci_rd_memtype(a20addr & 0xFC000)) {
              case 0x0:   // Read from ROM
                *data_ptr = vector[a20addr];
                //BX_INFO(("Reading from ROM %08x, Data %02x ", (unsigned) a20addr, *data_ptr));
                break;

              case 0x1:   // Read from Shadow RAM
                *data_ptr = shadow[a20addr - 0xc0000];
                BX_INFO(("Reading from ShadowRAM %08x, Data %02x  ", (unsigned) a20addr, *data_ptr));
                break;
              default:
                BX_PANIC(("readPhysicalPage: default case"));
              } // Switch
            }
          }
        else {
          *data_ptr = vector[a20addr];
          BX_INFO(("Reading from Norm %08x, Data %02x  ", (unsigned) a20addr, *data_ptr));
          }
        }
      else
        *data_ptr = 0xff;
#endif  // BX_PCI_SUPPORT == 0
      addr++;
      a20addr = (addr);
#ifdef BX_LITTLE_ENDIAN
      data_ptr++;
#else // BX_BIG_ENDIAN
      data_ptr--;
#endif
      }
      (*(Bit8u *)integrity) = 0xFF;
    return;
    }
}

#endif // #if BX_PROVIDE_CPU_MEMORY

