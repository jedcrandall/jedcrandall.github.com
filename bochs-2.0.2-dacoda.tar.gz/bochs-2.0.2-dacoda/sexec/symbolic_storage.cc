#include "symbolic_storage.h"

#include <string.h>

#define MAX_EXPR_DEPTH 10

SymbolicStorage TheLabels;

extern BOOL EffectivelyNull(Expression *);
extern BOOL OughtToBeIdempotent(Expression *);

extern int GLOBALCthulhuMode;
extern FILE *GLOBALPredicatesPipe;

SymbolicStorage::SymbolicStorage()
{
	int Index, Byte;

	for (Index = 0; Index < 10; Index++)
	{
		for (Byte = 0; Byte < 3; Byte++)
		{
			SymbolicRegisters[Index][Byte] = NULL;
		}
	}
	
	for (PredHead = 0; PredHead < NUM_SAVED_PREDICATES; PredHead++)
	{
		ThePredicates[PredHead] = NULL;
	}
	PredHead = 0;

	for (StoredLabelBytesTotal = 0; StoredLabelBytesTotal < NUM_SAVED_LABELBYTES; StoredLabelBytesTotal++)
	{
		StoredLabelBytes[StoredLabelBytesTotal] = 0;
	}
	StoredLabelBytesTotal = 0;
	IdempotentExpr = (Expression *) new Label(0xFFFFFFFF);
	((Label *) IdempotentExpr)->SetInCPU(FALSE);
	SaveMeSaveMe = NULL;
}

void SymbolicStorage::AddLabelByte(unsigned char AddMe)
{
	StoredLabelBytes[StoredLabelBytesTotal++ % NUM_SAVED_LABELBYTES] = AddMe;
}

int SymbolicStorage::GetLabelByte(ULONG LabelNumber)
{
	if (LabelNumber > StoredLabelBytesTotal)
		return -1;
	if ((StoredLabelBytesTotal - LabelNumber + 12) > NUM_SAVED_LABELBYTES)
		return -1;


	return StoredLabelBytes[LabelNumber % NUM_SAVED_LABELBYTES];
}

void SymbolicStorage::WriteSymbolicMemory(ULONG PhysicalAddress, Expression *pExpression)
{
	SymbolicStorageMap::iterator p;

	p = SymbolicMemory.find(PhysicalAddress);
	if (p != SymbolicMemory.end())
	{
		if (p->second != NULL)
		{
			//delete p->second;
			p->second = NULL;
		}
		SymbolicMemory.erase(p);
	}

	if (pExpression != NULL)
	{
		if ((pExpression->Depth() > MAX_EXPR_DEPTH) || OughtToBeIdempotent(pExpression))
		{
			//delete pExpression;
			SymbolicMemory[PhysicalAddress] = IdempotentExpr;//(Expression *) new Label(0xFFFFFFFF);
		}
		else if (!EffectivelyNull(pExpression))
			SymbolicMemory[PhysicalAddress] = pExpression;
		//else
			//delete pExpression;
	}
}

Expression *SymbolicStorage::ReadSymbolicMemory(ULONG PhysicalAddress)
{
	SymbolicStorageMap::iterator p;

	p = SymbolicMemory.find(PhysicalAddress);
	if (p != SymbolicMemory.end())
	{
		//Expression *returnMe;
		if (p->second->Type == T_QUAD)
			return ((QuadExpression *) p->second)->GetByte(PhysicalAddress % 4);
		else
			return p->second;
	}
	else
	{
		return NULL;
	}
}

int SymbolicStorage::NumLabelsInMemory()
{
	return SymbolicMemory.size();
}

void SymbolicStorage::WriteSymbolicRegister(ULONG Index, ULONG Byte, Expression *pExpression)
{

	/*if ((Index > 10) || ((void *) pExpression == (void *) this))
	{
		printf("Index == %d and pExpression == %p and this == %p\n", Index, pExpression, this);
		fflush(stdout);
	}
	if (pExpression != NULL)
	{
		if ((pExpression->Type < 1) || (pExpression->Type > 7))
		{
			printf("pExpression->Type == %d\n", pExpression->Type);
			fflush(stdout);
		}
	}*/
	/*SymbolicStorageMap::iterator p;

	p = SymbolicRegisters.find(Index * 4 + Byte);
	if (p != SymbolicRegisters.end())
	{
		if (p->second != NULL)
		{
			delete p->second;
			p->second = NULL;
		}
		SymbolicRegisters.erase(p);
	}
	if (pExpression != NULL)
	{
		if (!EffectivelyNull(pExpression))
			SymbolicRegisters[Index * 4 + Byte] = pExpression;
		else
			delete pExpression;
	}*/
#if 0
	if (SymbolicRegisters[Index][Byte] != NULL)
	{
		//delete SymbolicRegisters[Index][Byte];
		SymbolicRegisters[Index][Byte] = NULL;
	}
	if (pExpression != NULL)
	{
		if ((pExpression->Depth(0) > MAX_EXPR_DEPTH) || OughtToBeIdempotent(pExpression))
		{
			//delete pExpression;
			SymbolicRegisters[Index][Byte] = (Expression *) new Label(0xFFFFFFFF);
		}
		else if (!EffectivelyNull(pExpression))
			SymbolicRegisters[Index][Byte] = pExpression;
		//else
			//delete pExpression;
	}
#endif
	SymbolicRegisters[Index][Byte] = NULL;
	if (pExpression != NULL)
	{
		if ((pExpression->Depth() > MAX_EXPR_DEPTH) || OughtToBeIdempotent(pExpression))
		{
			SymbolicRegisters[Index][Byte] = IdempotentExpr;
		}
		else if (!EffectivelyNull(pExpression))
			SymbolicRegisters[Index][Byte] = pExpression;
	}
}

Expression *SymbolicStorage::ReadSymbolicRegister(ULONG Index, ULONG Byte)
{
	/*SymbolicStorageMap::iterator p;

	p = SymbolicRegisters.find(Index * 4 + Byte);
	if (p != SymbolicRegisters.end())
	{
		return p->second;
	}
	else
	{
		return NULL;
	}*/
#if 0
	if (SymbolicRegisters[Index][0] != NULL)
		if (SymbolicRegisters[Index][0]->Type == T_QUAD)
			return ((QuadExpression *) SymbolicRegisters[Index][0])->GetByte(Byte);

	return SymbolicRegisters[Index][Byte];
	//return SymbolicRegisters[Index][Byte];
#endif
	//Expression *returnMe;
	if (SymbolicRegisters[Index][0] != NULL)
	{
		if (SymbolicRegisters[Index][0]->Type == T_QUAD)
		{
			return ((QuadExpression *) SymbolicRegisters[Index][0])->GetByte(Byte);
		}
		else
		{
			return SymbolicRegisters[Index][Byte];
		}
	}
	else
	{
		return SymbolicRegisters[Index][Byte];
	}
}


void SymbolicStorage::PhysicalLabelDump()
{
	SymbolicStorageMap::iterator Loop;

	for (Loop = SymbolicMemory.begin(); Loop != SymbolicMemory.end(); Loop++)
	{
		printf("%08x is ", Loop->first);
		if (Loop->second != NULL)
		{
			Loop->second->Print(0, stdout);
		}
	}
}

void SymbolicStorage::LabelDump(void *f)
{
	unsigned int laddr;
	unsigned int offset;
	SymbolicStorageMap::iterator Loop;
	linear2phyfunction *l2p = (linear2phyfunction *) f;
	unsigned int paddr, paddr_valid;

	//l2p(15, &paddr, &paddr_valid);

	for (laddr = 0; laddr < 0xFFFFF000; laddr += 4096)
	{
		l2p(laddr, &paddr, &paddr_valid);
		if (paddr_valid)
		{
			for (offset = 0; offset < 4096; offset++)
			{
				Loop = SymbolicMemory.find(paddr + offset);
				if (Loop != SymbolicMemory.end())
				{
					printf("%08x is ", laddr + offset);
					if (Loop->second != NULL)
					{
						Loop->second->Print(0, stdout);
					}
				}
			}
		}
	}

}

void MarkTrue(Expression *MarkMe)
{
	MarkMe->MyNode->Marked = TRUE;
}


void Traverse(Expression *Me, ReachableNode *pReachable)
{
	Operation *OpMe;
	DoubleExpression *DMe;
	QuadExpression *QMe;
	Lookup *LoMe;
	Predicate *PMe;

	if (Me == NULL)
	{
		return;
	}

	switch(Me->Type) {
	//else if (Me->IsALabel())
	case T_LABEL: {
		return;
	}
	//else if (Me->IsAConstant())
	case T_CONSTANT: {
		return;
	}
	//else if (Me->IsALookup())
	case T_LOOKUP: {
		LoMe = (Lookup *) Me;
		if (LoMe->GetAddr() != NULL)
		{
			if (!(LoMe->GetAddr()->MyNode->Marked))
			{
				MarkTrue(LoMe->GetAddr());
				//(*pReachable)[LoMe->GetAddr()] = TRUE;
				Traverse(LoMe->GetAddr(), pReachable);
			}
		}
		if (LoMe->GetValue() != NULL)
		{
			if (!(LoMe->GetValue()->MyNode->Marked))
			{
				MarkTrue(LoMe->GetValue());
				//(*pReachable)[LoMe->GetValue()] = TRUE;
				Traverse(LoMe->GetValue(), pReachable);
			}
		}
		return;
	}
	//else if (Me->IsAQuadExpression())
	case T_QUAD: {
		QMe = (QuadExpression *) Me;
		if (QMe->GetByte(0) != NULL)
		{
			if (!(QMe->GetByte(0)->MyNode->Marked))
			{
				MarkTrue(QMe->GetByte(0));
				//(*pReachable)[QMe->GetByte(0)] = TRUE;
				Traverse(QMe->GetByte(0), pReachable);
			}
		}
		if (QMe->GetByte(1) != NULL)
		{
			if (!(QMe->GetByte(1)->MyNode->Marked))
			{
				MarkTrue(QMe->GetByte(1));
				//(*pReachable)[QMe->GetByte(1)] = TRUE;
				Traverse(QMe->GetByte(1), pReachable);
			}
		}
		if (QMe->GetByte(2) != NULL)
		{
			if (!(QMe->GetByte(2)->MyNode->Marked))
			{
				MarkTrue(QMe->GetByte(2));
				//(*pReachable)[QMe->GetByte(2)] = TRUE;
				Traverse(QMe->GetByte(2), pReachable);
			}
		}
		if (QMe->GetByte(3) != NULL)
		{
			if (!(QMe->GetByte(3)->MyNode->Marked))
			{
				MarkTrue(QMe->GetByte(3));
				//(*pReachable)[QMe->GetByte(3)] = TRUE;
				Traverse(QMe->GetByte(3), pReachable);
			}	
		}
		return;
	}
	//else if (Me->IsADoubleExpression())
	case T_DOUBLE: {
		DMe = (DoubleExpression *) Me;
		if (DMe->GetByte(0) != NULL)
		{
			if (!(DMe->GetByte(0)->MyNode->Marked))
			{
				MarkTrue(DMe->GetByte(0));
				//(*pReachable)[DMe->GetByte(0)] = TRUE;
				Traverse(DMe->GetByte(0), pReachable);
			}
		}
		if (DMe->GetByte(1) != NULL)
		{
			if (!(DMe->GetByte(1)->MyNode->Marked))
			{
				MarkTrue(DMe->GetByte(1));
				//(*pReachable)[DMe->GetByte(1)] = TRUE;
				Traverse(DMe->GetByte(1), pReachable);
			}
		}
		return;
	}
	//else if (Me->IsAnOperation())
	case T_OPERATION: {
		OpMe = (Operation *) Me;
		if (OpMe->GetOp1() != NULL)
		{
			if (!(OpMe->GetOp1()->MyNode->Marked))
			{		
				MarkTrue(OpMe->GetOp1());
				//(*pReachable)[OpMe->GetOp1()] = TRUE;
				Traverse(OpMe->GetOp1(), pReachable);
			}
		}
		if (OpMe->GetOp2() != NULL)
		{
			if (!(OpMe->GetOp2()->MyNode->Marked))
			{
				MarkTrue(OpMe->GetOp2());
				//(*pReachable)[OpMe->GetOp2()] = TRUE;
				Traverse(OpMe->GetOp2(), pReachable);
			}
		}
		return;
	}
	//else
	case T_PREDICATE: {
		PMe = (Predicate *) Me;
		if (PMe->GetLeft() != NULL)
		{
			if (!(PMe->GetLeft()->MyNode->Marked))
			{
				MarkTrue(PMe->GetLeft());
				Traverse(PMe->GetLeft(), pReachable);
			}
		}
		if (PMe->GetRight() != NULL)
		{
			if (!(PMe->GetRight()->MyNode->Marked))
			{
				MarkTrue(PMe->GetRight());
				Traverse(PMe->GetRight(), pReachable);
			}
		}
		return;
	}
	default: {
		printf("What the?... %d...\n", Me->Type);
		return;
	}
	} // switch
}

void SymbolicStorage::MarkReachable(ReachableNode *pReachable)
{
	SymbolicStorageMap::iterator Loop;

	for (Loop = SymbolicMemory.begin(); Loop != SymbolicMemory.end(); Loop++)
	{
		//(*pReachable)[Loop->second] = TRUE;
		MarkTrue(Loop->second);
		Traverse(Loop->second, pReachable);
	}

	if (SaveMeSaveMe != NULL)
	{
		MarkTrue(SaveMeSaveMe);
		Traverse(SaveMeSaveMe, pReachable);
		SaveMeSaveMe = NULL;
	}

	int Index, Byte;
	for (Index = 0; Index < 10; Index++)
	{
		for (Byte = 0; Byte < 3; Byte++)
		{
			if (SymbolicRegisters[Index][Byte] != NULL)
			{
				MarkTrue(SymbolicRegisters[Index][Byte]);
				//(*pReachable)[SymbolicRegisters[Index][Byte]] = TRUE;
				Traverse(SymbolicRegisters[Index][Byte], pReachable);
			}
		}
	}
	for (Index = 0; Index < NUM_SAVED_PREDICATES; Index++)
	{
		if (ThePredicates[Index] != NULL)
		{
			MarkTrue(ThePredicates[Index]);
			Traverse(ThePredicates[Index], pReachable);
		}
	}
}

void SymbolicStorage::AddPredicate(Expression *pExpression)
{
	ThePredicates[PredHead] = pExpression;
	PredHead++;
	PredHead %= NUM_SAVED_PREDICATES;
	if (GLOBALCthulhuMode)
	{
		pExpression->Print(0, GLOBALPredicatesPipe);
		fflush(GLOBALPredicatesPipe);
	}
}

BOOL HasALabelBetween(Expression *Me, int Lower, int Upper);

extern Skippy_struct *Skippy;

void SymbolicStorage::PrintPredicates(ULONG StartLabel, ULONG EndLabel, ULONG CommType)
{
	int Loop;
	BOOL mmmPeanutButter;
	Skippy_struct *LoopySnoopy;
	int LabelLoop;

	for (Loop = 0; Loop < NUM_SAVED_PREDICATES; Loop++)
	{
		if (ThePredicates[Loop] != NULL)
		{
			mmmPeanutButter = 0;
			for (LoopySnoopy = Skippy; LoopySnoopy != NULL; LoopySnoopy = LoopySnoopy->pNext)
			{
				/**if (HasALabelBetween(ThePredicates[Loop], LoopySnoopy->IndexBegin, (LoopySnoopy->IndexBegin + LoopySnoopy->SizeSkippy)))
					mmmPeanutButter = 1;**/
				int i = LoopySnoopy->IndexBegin;
				int j, k;
				j = GetLabelByte(i + 1);
				k = GetLabelByte(i + 2);
				if (Loop == 0)/**(j == 0x50) && (k = 0xba) && (Loop == 0))**/ printf("%d ", i);
				int sz = LoopySnoopy->Size;

				//int upper = GetLabelByte(i + 17);
				//int lower = GetLabelByte(i + 18);

				int proto = GetLabelByte(i + 23);


				//if ((upper != -1) && (lower != -1) && (proto != -1))
				//{
					int header;

					if (proto == 6)
						header = 58;
					else if (proto == 17)
						header = 42;
					else
						header = 34;
					//sz = upper * 256 + lower;

					if (HasALabelBetween(ThePredicates[Loop], i + header, i + sz - 1))
						mmmPeanutButter = 1;
				//}

			}
			if (Loop == 0) printf("\n");
			if (mmmPeanutButter)
			{
				if (HasALabelBetween(ThePredicates[Loop], StartLabel, EndLabel) && ((Predicate *) ThePredicates[Loop])->IsInteresting())
				{
					if (CommType == 0)
						ThePredicates[Loop]->Print(0, stdout);
					else if ((CommType == 1) && (((Predicate *) ThePredicates[Loop])->GetEIP() >= 0xC0000000))
						ThePredicates[Loop]->Print(0, stdout);
					else if ((CommType == 2) && (((Predicate *) ThePredicates[Loop])->GetEIP() < 0xC0000000))
						ThePredicates[Loop]->Print(0, stdout);

				}
			}
		}
	}

}

void SymbolicStorage::PrintAllPredicates(ULONG StartLabel, ULONG EndLabel)
{
	int Loop;
	BOOL mmmPeanutButter;
	Skippy_struct *LoopySnoopy;
	int LabelLoop;

	for (Loop = 0; Loop < NUM_SAVED_PREDICATES; Loop++)
	{
		if (ThePredicates[Loop] != NULL)
		{
			if (HasALabelBetween(ThePredicates[Loop], StartLabel, EndLabel))
			{
				ThePredicates[Loop]->Print(0, stdout);
			}
		}
	}

}

void FillLabelList(Expression *Me, unsigned long int *TheList);

struct ListOfPredicates_struct
{
	Predicate *ThePred;
	ListOfPredicates_struct *pNext;
};

void SymbolicStorage::SummarizePredicates(ULONG StartLabel, ULONG EndLabel)
{
#if 0
	int Loop;
	BOOL mmmPeanutButter;
	Skippy_struct *LoopySnoopy;
	int LabelLoop;
	int TotalYeps = 0;
	int LongestYeps = 0;
	int KernelPreds = 0, OtherPreds = 0;

	int State = 0, Count = 0, NewState;
	for (LabelLoop = StartLabel; LabelLoop <= EndLabel; LabelLoop++)
	{
		mmmPeanutButter = 0;
		for (LoopySnoopy = Skippy; LoopySnoopy != NULL; LoopySnoopy = LoopySnoopy->pNext)
		{
			if ((LabelLoop >= LoopySnoopy->IndexBegin) && (LabelLoop <= (LoopySnoopy->IndexBegin + LoopySnoopy->SizeSkippy)))
				mmmPeanutButter = 1;
		}
		if (mmmPeanutButter)
		{
			NewState = 0;
			for (Loop = 0; Loop < NUM_SAVED_PREDICATES; Loop++)
			{
				if (HasALabelBetween(ThePredicates[Loop], LabelLoop, LabelLoop))
				{
					if (((Predicate *) ThePredicates[Loop])->IsInteresting())
						NewState = 1;

				}
			}
			if (NewState == State)
			{
				Count++;
			}
			else
			{
				printf("%d %s (%d..%d), ", Count, State ? "Yeps" : "Nopes", LabelLoop - Count, LabelLoop - 1);
				if (State == 1)
				{
					if (Count > LongestYeps)
						LongestYeps = Count;
				}
				State = NewState;
				Count = 1;
			}
			if (State == 1) TotalYeps++;

		}

	}
	printf("and finally... %d %s\n", Count, State ? "Yeps" : "Nopes");
	printf("Total yeps: %d\n", TotalYeps);
	printf("Longest string of yeps: %d\n", LongestYeps);

	for (Loop = 0; Loop < NUM_SAVED_PREDICATES; Loop++)
	{
		if (ThePredicates[Loop] != NULL)
		{
			mmmPeanutButter = 0;
			for (LoopySnoopy = Skippy; LoopySnoopy != NULL; LoopySnoopy = LoopySnoopy->pNext)
			{
				if (HasALabelBetween(ThePredicates[Loop], LoopySnoopy->IndexBegin, (LoopySnoopy->IndexBegin + LoopySnoopy->SizeSkippy)))
					mmmPeanutButter = 1;
			}
			if (mmmPeanutButter)
			{
				if (HasALabelBetween(ThePredicates[Loop], StartLabel, EndLabel))
				{
					if (((Predicate *) ThePredicates[Loop])->IsInteresting())
					{
						if (((Predicate *) ThePredicates[Loop])->GetEIP() >= 0x80000000)
						{
							KernelPreds++;
						}
						else
						{
							OtherPreds++;
						}
					}
				}
			}
		}
	}

	printf("%d kernel predicates and %d userspace makes %d\n", KernelPreds, OtherPreds, KernelPreds + OtherPreds);
#else
int LoopOverListOfPredicates;
int Loop;
int mmmPeanutButter;
	int TotalYeps = 0;
	int LongestYeps = 0;
	int KernelPreds = 0, OtherPreds = 0;
	Skippy_struct *LoopySnoopy;

	int State = 0, Count = 0, NewState;



ListOfPredicates_struct **TempPredList;
ListOfPredicates_struct *AddPredList;
unsigned long int LabelList[1000];
char *Signature = new char[1000000];
int SignatureIndex = 0;
memset(Signature, 0, 1000000);
unsigned int ProcessesInvolved[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
unsigned int ProcLoop;
unsigned int PTID;
unsigned int Histogram[1000];

for (Loop = 0; Loop < 1000; Loop++)
{
	Histogram[Loop] = 0;
}


int TempPredListSize = EndLabel - StartLabel + 1;
TempPredList = (ListOfPredicates_struct **) new ListOfPredicates_struct[TempPredListSize];

	for (LoopOverListOfPredicates = 0; LoopOverListOfPredicates <  TempPredListSize; LoopOverListOfPredicates++)
		TempPredList[LoopOverListOfPredicates] = (ListOfPredicates_struct *) NULL;

	for (Loop = 0; Loop < NUM_SAVED_PREDICATES; Loop++)
	{
		if (ThePredicates[Loop] != NULL)
		{
			mmmPeanutButter = 0;
			for (LoopySnoopy = Skippy; (LoopySnoopy != NULL) && (!mmmPeanutButter); LoopySnoopy = LoopySnoopy->pNext)
			{
				int i = LoopySnoopy->IndexBegin;
				int sz = LoopySnoopy->Size;
				int j, k;
				j = GetLabelByte(i + 1);
				k = GetLabelByte(i + 2);
				if ((j == 0x50) && (k == 0xba))
				{

					//int upper = GetLabelByte(i + 16);
					//int lower = GetLabelByte(i + 17);

					int proto = GetLabelByte(i + 23);


					//if ((upper != -1) && (lower != -1) && (proto == 6 || proto == 17))
					//{
						unsigned int header;

						if (proto == 6)
							header = 14 + 20 + 4*(GetLabelByte(i + 14 + 20 + 12) >> 4);//58;
						else if (proto == 17)
							header = 14 + 20 + 8;//42;
						else
						{
							//printf("Funny proto\n");
							header = 14 + 20;
						}
						//sz = upper * 256 + lower;

						if ((proto == 6) || (proto == 17))
							if (HasALabelBetween(ThePredicates[Loop], i + header, i + sz - 1))
								mmmPeanutButter = 1;
							
						//if ((proto != 6) && (proto != 17))
						//	printf("Throwing our funny proto %d\n", i);
							
						//if (mmmPeanutButter)
						//	printf("Using %d\n", i);
					//}
				}
			}
			if (mmmPeanutButter)
			{
				if (HasALabelBetween(ThePredicates[Loop], StartLabel, EndLabel))
				{
					if (((Predicate *) ThePredicates[Loop])->IsInteresting())
					{
						if (((Predicate *) ThePredicates[Loop])->GetCPL() == 0)  //GetEIP() >= 0x80000000)
						{
							KernelPreds++;
						}
						else
						{
							OtherPreds++;
						}
						PTID = ((Predicate *) ThePredicates[Loop])->GetPTID();
						ProcLoop = 0; 
						while(ProcLoop < 10 && ProcessesInvolved[ProcLoop] != PTID)
						{
							ProcLoop++;
							if (ProcessesInvolved[ProcLoop] == 0)
							{
								ProcessesInvolved[ProcLoop] = PTID;
								ProcLoop = 11;
							}
						}
					}
					LabelList[0] = 0;
					LabelList[996] = 0;
					LabelList[997] = 0;
					LabelList[998] = 0;
					LabelList[999] = 0;
					FillLabelList(ThePredicates[Loop], LabelList);
					int Index = 0;
					while (LabelList[Index] != 0)
					{
						if ((LabelList[Index] >= StartLabel) && (LabelList[Index] <= EndLabel))
						{
							AddPredList = new ListOfPredicates_struct;
							AddPredList->ThePred = (Predicate *) ThePredicates[Loop];
							AddPredList->pNext = TempPredList[LabelList[Index] - StartLabel];
							TempPredList[LabelList[Index] - StartLabel] = AddPredList;
						}
						Index++;
					}
				}
			}

		}
	}

	State = 0;
	for (Loop = 0; Loop < TempPredListSize; Loop++)
	{
		ListOfPredicates_struct *pLoopyDoopy, *pDeleteMe;

		NewState = 0;
		pLoopyDoopy = TempPredList[Loop];
		while (pLoopyDoopy != NULL)
		{
			if (pLoopyDoopy->ThePred->IsInteresting())
			{
				NewState = 1;
				/***if (pLoopyDoopy->ThePred->GetEIP() >= 0x80000000)
				{
					KernelPreds++;
				}
				else
				{
					OtherPreds++;
				}***/
			}
			pDeleteMe = pLoopyDoopy;
			pLoopyDoopy = pLoopyDoopy->pNext;
			delete pDeleteMe;
		}
		if ((NewState == 1) && (SignatureIndex < 999999))
		{
			int PrintMe = this->GetLabelByte(StartLabel + Loop);
			if (PrintMe != -1)
			{
				if (PrintMe == '\\')
				{
					Signature[SignatureIndex++] = '\\';
					Signature[SignatureIndex++] = '\\';
				}
				else if (PrintMe == '\n')
				{
					Signature[SignatureIndex++] = '\\';
					Signature[SignatureIndex++] = 'n';
				}
				else if (PrintMe == '\t')
				{
					Signature[SignatureIndex++] = '\\';
					Signature[SignatureIndex++] = 't';
				}
				else if ((PrintMe > 0x20) && (PrintMe < 0x7F) && (PrintMe != ','))
				{
					Signature[SignatureIndex++] = PrintMe;
				}
				else
				{
					Signature[SignatureIndex++] = '\\';
					Signature[SignatureIndex++] = 'x';
					char ss[6];
					sprintf(ss, "%02x", (unsigned char) PrintMe);
					Signature[SignatureIndex++] = ss[0];
					Signature[SignatureIndex++] = ss[1];
					Signature[SignatureIndex++] = ',';
				}
			}
		}
		if (NewState == State)
		{
			Count++;
		}
		else
		{
			printf("%d %s (%d..%d), ", Count, State ? "Yeps" : "Nopes", StartLabel + Loop - Count, StartLabel + Loop);
			if (State == 1)
			{
				char kittycat[30];
				snprintf(kittycat, 29, " (%d..%d)", StartLabel + Loop - Count, StartLabel + Loop - 1);
				strncpy(&(Signature[SignatureIndex]), kittycat, 30);
				SignatureIndex += strlen(kittycat);

			}
			if (State == 1)
			{
				if (Count < 999)
					Histogram[Count]++;
				else
					Histogram[999]++;
				if (Count > LongestYeps)
				{
					LongestYeps = Count;
				}
				Signature[SignatureIndex++] = '\n';
				Signature[SignatureIndex++] = '\n';
			}
			State = NewState;
			Count = 1;
		}
		if (State == 1) TotalYeps++;
	}

	printf("and finally... %d %s\n", Count, State ? "Yeps" : "Nopes");
	printf("Total yeps: %d\n", TotalYeps);
	printf("Longest string of yeps: %d\n", LongestYeps);
	printf("%d kernel predicates and %d userspace makes %d\n", KernelPreds, OtherPreds, KernelPreds + OtherPreds);
	printf("Processes involved:\n");
	for (ProcLoop = 0; ProcLoop < 10; ProcLoop++)
	{
		if (ProcessesInvolved[ProcLoop] != 0)
			printf("%08x, ", ProcessesInvolved[ProcLoop]);
	}
	printf("\n");
	printf("The signature is:\n\n%s\n\n", Signature);
	
	printf("Histogram:\n");

	for (Loop = 0; Loop < 999; Loop++)
	{
		if (Histogram[Loop])
		{
			printf("%d %d's\n", Histogram[Loop], Loop);
		}
	}
	if (Histogram[999])
	{
		printf("%d more than 998's\n", Histogram[999]);
	}

	delete TempPredList;
	delete Signature;

#endif
}

struct PredList_struct
{
	Predicate *Pred;
	unsigned long int PredNumber;
	struct PredList_struct *pNext;
};

struct Packet_struct
{
	unsigned long int StartLabel;
	unsigned long int Size;
	int LowestPredNumber;
	struct PredList_struct *pInterPacket;
	struct PredList_struct *pNotInterPacket;
	struct Packet_struct *pNext;
};

void SymbolicStorage::SigFromGamma(ULONG GammaStart, ULONG GammaEnd)
{
	struct Packet_struct *P = NULL; //stack of packets
	struct Packet_struct *TempP = NULL;
	struct Packet_struct *O = NULL; //ordered list of packets
	struct Packet_struct *LoopO = NULL;
	struct Packet_struct *LoopP = NULL;
	Skippy_struct *LoopySnoopy;
	unsigned long int PacketStart;
	unsigned long int PacketSize;
	PredList_struct **TempPredList;
	PredList_struct *AddPredList;
	PredList_struct *LoopPredList;
	unsigned long int LoopOverListOfPredicates;
	unsigned long int Loop;
	unsigned long int mmmPeanutButter;
	unsigned long int LabelList[1000];

	//Put the first packet from gamma on P
	//TODO:Others?
	PacketStart = 0;
	PacketSize = 0;
	for (LoopySnoopy = Skippy; LoopySnoopy != NULL; LoopySnoopy = LoopySnoopy->pNext)
	{
		if ((LoopySnoopy->IndexBegin < GammaStart) && (LoopySnoopy->IndexBegin > PacketStart))
		{
			PacketStart = LoopySnoopy->IndexBegin;
			PacketSize = LoopySnoopy->Size;
		}
	}

	P = new Packet_struct;
	P->StartLabel = PacketStart;
	P->Size = PacketSize;
	P->LowestPredNumber = -1;
	P->pInterPacket = NULL;
	P->pNotInterPacket = NULL;
	P->pNext = NULL;

	//Print out P for debugging purposes
	printf("P has StartLabel %d, Size %d, LowestPredNumber %d\n", P->StartLabel, P->Size, P->LowestPredNumber);



	//Build a list of predicates for each labeled byte
	TempPredList = (PredList_struct **) new ListOfPredicates_struct[NUM_SAVED_LABELBYTES];

	for (LoopOverListOfPredicates = 0; LoopOverListOfPredicates < NUM_SAVED_LABELBYTES; LoopOverListOfPredicates++)
		TempPredList[LoopOverListOfPredicates] = (PredList_struct *) NULL;



	for (Loop = 0; Loop < NUM_SAVED_PREDICATES; Loop++)
	{
		if (ThePredicates[Loop] != NULL)
		{
			mmmPeanutButter = 0;
			if (((Predicate *) ThePredicates[Loop])->IsInteresting())
			{
				for (LoopySnoopy = Skippy; LoopySnoopy != NULL; LoopySnoopy = LoopySnoopy->pNext)
				{
					int i = LoopySnoopy->IndexBegin;
					int sz = LoopySnoopy->Size;

					if (HasALabelBetween(ThePredicates[Loop], i + 34, i + sz))
						mmmPeanutButter = 1;

				}
				if (mmmPeanutButter)
				{
					LabelList[0] = 0;
					LabelList[996] = 0;
					LabelList[997] = 0;
					LabelList[998] = 0;
					LabelList[999] = 0;
					FillLabelList(ThePredicates[Loop], LabelList);
					int Index = 0;
					while (LabelList[Index] != 0)
					{
						signed long int NewNumber;
						if (StoredLabelBytesTotal < NUM_SAVED_LABELBYTES)
						{
							NewNumber = LabelList[Index];
						}
						else
						{
							NewNumber = StoredLabelBytesTotal - LabelList[Index];
							if (NewNumber > NUM_SAVED_LABELBYTES)
								NewNumber = -1;
							else
								NewNumber = NUM_SAVED_LABELBYTES - NewNumber;
						}
						if (NewNumber != -1)
						{
							AddPredList = new PredList_struct;
							AddPredList->Pred = (Predicate *) ThePredicates[Loop];
							AddPredList->PredNumber = ((PredHead + NUM_SAVED_PREDICATES) - Loop) % NUM_SAVED_PREDICATES;
							AddPredList->pNext = TempPredList[NewNumber];
							TempPredList[NewNumber] = AddPredList;
							if ((NewNumber >= P->StartLabel) && (NewNumber <= (P->StartLabel + P->Size)))
								printf("Add to TempPredList\t%d\t%d\n", NewNumber, AddPredList->PredNumber);
						}
						Index++;
					}
				}
			}

		}
	}

	//While the stack is not empty
	while (P != NULL)
	{
		TempP = P;
		P = P->pNext; //Pop TempP
		printf("Popping %d\n", TempP->StartLabel);


		//Look for others
		for (Loop = TempP->StartLabel + 34; Loop < TempP->StartLabel + TempP->Size; Loop++)
		{
			if (1) //(Loop > StoredLabelBytesTotal - NUM_SAVED_LABELBYTES) && (Loop <= StoredLabelBytesTotal))
			{
				for (LoopPredList = TempPredList[Loop]; LoopPredList != NULL; LoopPredList = LoopPredList->pNext)
				{
					int IsInterPacket = 0;

					LabelList[0] = 0;
					LabelList[996] = 0;
					LabelList[997] = 0;
					LabelList[998] = 0;
					LabelList[999] = 0;
					FillLabelList((Expression *) LoopPredList->Pred, LabelList);
					int Index = 0;
					while (LabelList[Index] != 0)
					{
						if (1)//(LabelList[Index] > StoredLabelBytesTotal - NUM_SAVED_LABELBYTES) && (LabelList[Index] <= StoredLabelBytesTotal))
						{
							PacketStart = 0;
							PacketSize = 0;
							for (LoopySnoopy = Skippy; LoopySnoopy != NULL; LoopySnoopy = LoopySnoopy->pNext)
							{
								if ((LabelList[Index] >= LoopySnoopy->IndexBegin) && (LabelList[Index] <= (LoopySnoopy->IndexBegin + LoopySnoopy->Size)))
								//((LoopySnoopy->IndexBegin < GammaStart) && (LoopySnoopy->IndexBegin > PacketStart))
								{
									PacketStart = LoopySnoopy->IndexBegin;
									PacketSize = LoopySnoopy->Size;
								}
							}
							//Loop over O/P/TempP and make sure it's not already there
							//if not, push it onto P
							if (PacketStart == TempP->StartLabel)
							{
								//printf("Not interpacket\n");
								IsInterPacket = 0;
							}
							else if (PacketSize != 0)
							{
								//printf("Interpacket\n");
								IsInterPacket = 1;
								int AlreadyThere = 0;
								//loop over P
								for (LoopP = P; LoopP != NULL; LoopP = LoopP->pNext)
								{
									if (LoopP->StartLabel == PacketStart)
										AlreadyThere = 1;
								}
								//loop over O
								for (LoopO = O; LoopO != NULL; LoopO = LoopO->pNext)
								{
									if (LoopO->StartLabel == PacketStart)
										AlreadyThere = 1;
								}
								//push it if not already there
								if (!AlreadyThere)
								{
									printf("Pushing something %d!\n", PacketStart);
									Packet_struct *PushP;
									PushP = new Packet_struct;
									PushP->StartLabel = PacketStart;
									PushP->Size = PacketSize;
									PushP->LowestPredNumber = -1;
									PushP->pInterPacket = NULL;
									PushP->pNotInterPacket = NULL;
									PushP->pNext = P;
									P = PushP;
								}
							}
						}
						Index++;
					}

					if (!IsInterPacket)
					{
						if (TempP->LowestPredNumber == -1)
						{
							TempP->LowestPredNumber = LoopPredList->PredNumber;//TempP->LowestPredNumber;
						}
						else if (LoopPredList->PredNumber < TempP->LowestPredNumber)
						{
							TempP->LowestPredNumber = LoopPredList->PredNumber;//TempP->LowestPredNumber;
						}
					}

				//build the two lists in TempP
					if (IsInterPacket)
					{
						//printf("Build list 1\n");
						PredList_struct *pNewNode;
						pNewNode = new PredList_struct;
						pNewNode->Pred = LoopPredList->Pred;
						pNewNode->PredNumber = LoopPredList->PredNumber;
						pNewNode->pNext = TempP->pInterPacket;
						TempP->pInterPacket = pNewNode;
					}
					else
					{
						//printf("Build list 2\n");
						PredList_struct *pNewNode;
						pNewNode = new PredList_struct;
						pNewNode->Pred = LoopPredList->Pred;
						pNewNode->PredNumber = LoopPredList->PredNumber;
						pNewNode->pNext = TempP->pNotInterPacket;
						TempP->pNotInterPacket = pNewNode;
					}
				}
			}
		}

		//Add TempP to O
		if (O == NULL)
		{
			TempP->pNext = O;
			O = TempP;
		}
		else
		{
			/**TempP->pNext = O;
			O = TempP;**/
			if (O->LowestPredNumber > TempP->LowestPredNumber)
			{
				TempP->pNext = O;
				O = TempP;
			}
			else
			{
				for (LoopO = O; LoopO != NULL && LoopO->LowestPredNumber < TempP->LowestPredNumber; LoopO = LoopO->pNext)
				{
					if (LoopO->pNext != NULL)
					{
						if (LoopO->pNext->LowestPredNumber > TempP->LowestPredNumber)
						{
							TempP->pNext = LoopO->pNext;
							LoopO->pNext = TempP;
						}
					}
					else
					{
						TempP->pNext = NULL;
						LoopO->pNext = TempP;
					}
				}
			}
		}

	}

	//Print out O for debugging purposes
	for (LoopO = O; LoopO != NULL; LoopO = LoopO->pNext)
	{
		printf("O element has StartLabel %d, LowestPredNumber %d\n", LoopO->StartLabel, LoopO->LowestPredNumber);
	}

	//Cleanup
	for (Loop = 0; Loop < NUM_SAVED_LABELBYTES; Loop++)
	{
		PredList_struct *pLoopyDoopy, *pDeleteMe;

		pLoopyDoopy = TempPredList[Loop];
		while (pLoopyDoopy != NULL)
		{
			pDeleteMe = pLoopyDoopy;
			pLoopyDoopy = pLoopyDoopy->pNext;
			delete pDeleteMe;
		}
	}
	
	Packet_struct *pAnihilateMe = NULL;
	for (LoopO = O; LoopO != NULL; LoopO = LoopO->pNext)
	{
		if (pAnihilateMe != NULL)
		{
			PredList_struct *pMakeMeDisappear = NULL;
			for (LoopPredList = pAnihilateMe->pInterPacket; LoopPredList != NULL; LoopPredList = LoopPredList->pNext)
			{
				if (pMakeMeDisappear != NULL)
				{
					delete pMakeMeDisappear;
				}
				pMakeMeDisappear = LoopPredList;
			}
			if (pMakeMeDisappear != NULL)
			{
				delete pMakeMeDisappear;
			}
			pMakeMeDisappear = NULL;
			for (LoopPredList = pAnihilateMe->pNotInterPacket; LoopPredList != NULL; LoopPredList = LoopPredList->pNext)
			{
				if (pMakeMeDisappear != NULL)
				{
					delete pMakeMeDisappear;
				}
				pMakeMeDisappear = LoopPredList;
			}
			if (pMakeMeDisappear != NULL)
			{
				delete pMakeMeDisappear;
			}
			delete pAnihilateMe;
		}
		pAnihilateMe = LoopO;
	}
	if (pAnihilateMe != NULL)
	{
		PredList_struct *pMakeMeDisappear = NULL;
		for (LoopPredList = pAnihilateMe->pInterPacket; LoopPredList != NULL; LoopPredList = LoopPredList->pNext)
		{
			if (pMakeMeDisappear != NULL)
			{
				delete pMakeMeDisappear;
			}
			pMakeMeDisappear = LoopPredList;
		}
		if (pMakeMeDisappear != NULL)
		{
			delete pMakeMeDisappear;
		}
		pMakeMeDisappear = NULL;
		for (LoopPredList = pAnihilateMe->pNotInterPacket; LoopPredList != NULL; LoopPredList = LoopPredList->pNext)
		{
			if (pMakeMeDisappear != NULL)
			{
				delete pMakeMeDisappear;
			}
			pMakeMeDisappear = LoopPredList;
		}
		if (pMakeMeDisappear != NULL)
		{
			delete pMakeMeDisappear;
		}
		delete pAnihilateMe;
	}

	delete TempPredList;
}

void FillLabelList(Expression *Me, unsigned long int *TheList)
{
	Label *LaMe;
	Operation *OpMe;
	DoubleExpression *DMe;
	QuadExpression *QMe;
	Lookup *LoMe;
	Predicate *PMe;
	BOOL ReturnMe;
	int Index;

	if (Me == NULL)
	{
		return;
	}

	switch(Me->Type) {
	//else if (Me->IsALabel())
	case T_LABEL: {
		LaMe = (Label *) Me;
		Index = 0;
		while (TheList[Index] && (Index < 996)) Index++;
		TheList[Index] = LaMe->GetNumber();
		TheList[Index + 1] = 0;
	}
	//else if (Me->IsAConstant())
	case T_CONSTANT: {
		return;
	}
	//else if (Me->IsALookup())
	case T_LOOKUP: {
		LoMe = (Lookup *) Me;
		if (LoMe->GetAddr() != NULL)
		{
			FillLabelList(LoMe->GetAddr(), TheList);
		}
		if (LoMe->GetValue() != NULL)
		{
			FillLabelList(LoMe->GetValue(), TheList);
		}
		return;
	}
	//else if (Me->IsAQuadExpression())
	case T_QUAD: {
		QMe = (QuadExpression *) Me;
		if (QMe->GetByte(0) != NULL)
		{
			FillLabelList(QMe->GetByte(0), TheList);
		}
		if (QMe->GetByte(1) != NULL)
		{
			FillLabelList(QMe->GetByte(1), TheList);
		}
		if (QMe->GetByte(2) != NULL)
		{
			FillLabelList(QMe->GetByte(2), TheList);
		}
		if (QMe->GetByte(3) != NULL)
		{
			FillLabelList(QMe->GetByte(3), TheList);
		}
		return;
	}
	//else if (Me->IsADoubleExpression())
	case T_DOUBLE: {
		DMe = (DoubleExpression *) Me;
		if (DMe->GetByte(0) != NULL)
		{
			FillLabelList(DMe->GetByte(0), TheList);
		}
		if (DMe->GetByte(1) != NULL)
		{
			FillLabelList(DMe->GetByte(1), TheList);
		}
		return;
	}
	//else if (Me->IsAnOperation())
	case T_OPERATION: {
		OpMe = (Operation *) Me;
		if (OpMe->GetOp1() != NULL)
		{
			FillLabelList(OpMe->GetOp1(), TheList);
		}
		if (OpMe->GetOp2() != NULL)
		{
			FillLabelList(OpMe->GetOp2(), TheList);
		}
		return;
	}
	//else
	case T_PREDICATE: {
		PMe = (Predicate *) Me;
		if (PMe->GetLeft() != NULL)
		{
			FillLabelList(PMe->GetLeft(), TheList);
		}
		if (PMe->GetRight() != NULL)
		{
			FillLabelList(PMe->GetRight(), TheList);
		}
		return;
	}
	default: {
		printf("Jeepers creepers... %d...\n", Me->Type);
		return;
	}
	} // switch
}


SymbolicStorage::~SymbolicStorage()
{
}

BOOL HasALabelBetween(Expression *Me, int Lower, int Upper)
{
	Label *LaMe;
	Operation *OpMe;
	DoubleExpression *DMe;
	QuadExpression *QMe;
	Lookup *LoMe;
	Predicate *PMe;
	BOOL ReturnMe;

	if (Me == NULL)
	{
		return FALSE;
	}

	switch(Me->Type) {
	//else if (Me->IsALabel())
	case T_LABEL: {
		LaMe = (Label *) Me;
		if ((LaMe->GetNumber() >= Lower) && (LaMe->GetNumber() <= Upper))
			return TRUE;
		else
			return FALSE;
	}
	//else if (Me->IsAConstant())
	case T_CONSTANT: {
		return FALSE;
	}
	//else if (Me->IsALookup())
	case T_LOOKUP: {
		LoMe = (Lookup *) Me;
		ReturnMe = FALSE;
		if (LoMe->GetAddr() != NULL)
		{
			ReturnMe = ReturnMe || HasALabelBetween(LoMe->GetAddr(), Lower, Upper);
		}
		if (LoMe->GetValue() != NULL)
		{
			ReturnMe = ReturnMe || HasALabelBetween(LoMe->GetValue(), Lower, Upper);
		}
		return ReturnMe;
	}
	//else if (Me->IsAQuadExpression())
	case T_QUAD: {
		QMe = (QuadExpression *) Me;
		ReturnMe = FALSE;
		if (QMe->GetByte(0) != NULL)
		{
			ReturnMe = ReturnMe || HasALabelBetween(QMe->GetByte(0), Lower, Upper);
		}
		if (QMe->GetByte(1) != NULL)
		{
			ReturnMe = ReturnMe || HasALabelBetween(QMe->GetByte(1), Lower, Upper);
		}
		if (QMe->GetByte(2) != NULL)
		{
			ReturnMe = ReturnMe || HasALabelBetween(QMe->GetByte(2), Lower, Upper);
		}
		if (QMe->GetByte(3) != NULL)
		{
			ReturnMe = ReturnMe || HasALabelBetween(QMe->GetByte(3), Lower, Upper);
		}
		return ReturnMe;
	}
	//else if (Me->IsADoubleExpression())
	case T_DOUBLE: {
		DMe = (DoubleExpression *) Me;
		ReturnMe = FALSE;
		if (DMe->GetByte(0) != NULL)
		{
			ReturnMe = ReturnMe || HasALabelBetween(DMe->GetByte(0), Lower, Upper);
		}
		if (DMe->GetByte(1) != NULL)
		{
			ReturnMe = ReturnMe || HasALabelBetween(DMe->GetByte(1), Lower, Upper);
		}
		return ReturnMe;
	}
	//else if (Me->IsAnOperation())
	case T_OPERATION: {
		OpMe = (Operation *) Me;
		ReturnMe = FALSE;
		if (OpMe->GetOp1() != NULL)
		{
			ReturnMe = ReturnMe || HasALabelBetween(OpMe->GetOp1(), Lower, Upper);
		}
		if (OpMe->GetOp2() != NULL)
		{
			ReturnMe = ReturnMe || HasALabelBetween(OpMe->GetOp2(), Lower, Upper);
		}
		return ReturnMe;
	}
	//else
	case T_PREDICATE: {
		PMe = (Predicate *) Me;
		ReturnMe = FALSE;
		if (PMe->GetLeft() != NULL)
		{
			ReturnMe = ReturnMe || HasALabelBetween(PMe->GetLeft(), Lower, Upper);
		}
		if (PMe->GetRight() != NULL)
		{
			ReturnMe = ReturnMe || HasALabelBetween(PMe->GetRight(), Lower, Upper);
		}
		return ReturnMe;
	}
	default: {
		printf("Jiminny cricket?... %d...\n", Me->Type);
		return FALSE;
	}
	} // switch
}
