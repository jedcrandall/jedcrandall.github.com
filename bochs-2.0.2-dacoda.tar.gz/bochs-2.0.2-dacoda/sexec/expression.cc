#include "expression.h"

#ifndef __CTHULHU_PARSER
#include "garbage.h"
extern GarbageCollector TheGarbageCollector;
extern int GLOBALCthulhuMode;
extern FILE *GLOBALPredicatesPipe;

int LabelNumber = 0;
int GLOBALSexecMode = 0;
Skippy_struct *Skippy = NULL;
#endif

int CountsOfStuff[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

BOOL OughtToBeIdempotent(Expression *Me)
{
	if (Me != NULL)
		return Me->Idempotency();
	else
		return FALSE;
#if 0
	Label *LMe;
	Operation *OpMe;
	DoubleExpression *DMe;
	QuadExpression *QMe;
	Lookup *LoMe;
	Predicate *PMe;

	if (Me == NULL)
	{
		return FALSE;
	}

	switch(Me->Type) {
	//else if (Me->IsALabel())
	case T_LABEL: {
		LMe = (Label *) Me;
		if (LMe->GetNumber() == -1)
			return TRUE;
		else
			return FALSE;
	}
	//else if (Me->IsAConstant())
	case T_CONSTANT: {
		return FALSE;
	}
	//else if (Me->IsALookup())
	case T_LOOKUP: {
		LoMe = (Lookup *) Me;
		return (OughtToBeIdempotent(LoMe->GetAddr()) || OughtToBeIdempotent(LoMe->GetValue()));
	}
	//else if (Me->IsAQuadExpression())
	case T_QUAD: {
		QMe = (QuadExpression *) Me;
		return (OughtToBeIdempotent(QMe->GetByte(0)) || OughtToBeIdempotent(QMe->GetByte(1)) || OughtToBeIdempotent(QMe->GetByte(2)) || OughtToBeIdempotent(QMe->GetByte(3)));
	}
	//else if (Me->IsADoubleExpression())
	case T_DOUBLE: {
		DMe = (DoubleExpression *) Me;
		return (OughtToBeIdempotent(DMe->GetByte(0)) || OughtToBeIdempotent(DMe->GetByte(1)));
	}
	//else if (Me->IsAnOperation())
	case T_OPERATION: {
		OpMe = (Operation *) Me;
		return (OughtToBeIdempotent(OpMe->GetOp1()) || OughtToBeIdempotent(OpMe->GetOp2()));
	}
	//else
	case T_PREDICATE: {
		PMe = (Predicate *) Me;
		return (OughtToBeIdempotent(PMe->GetLeft()) || OughtToBeIdempotent(PMe->GetRight()));
	}
	default: {
		printf("Errrgh...%d.\n", Me->Type);
		return FALSE;
	}
	} // switch
#endif
}

Expression *SplitOperation(Expression *SplitMe, int ByteIndex)
{
	Expression *Op1, *Op2;
	DoubleExpression *DOp1, *DOp2;
	QuadExpression *QOp1, *QOp2;
	Operation *ReturnMe;
	Expression *NewOp1, *NewOp2;
	Operation *OSplitMe;

	OSplitMe = (Operation *) SplitMe;

	if (!(SplitMe->IsAnOperation()))
		printf("Dag nabbit\n");

	Op1 = OSplitMe->GetOp1();
	Op2 = OSplitMe->GetOp2();

	if (Op1 == NULL)
	{
		NewOp1 = NULL;
	}
	else if (Op1->IsAQuadExpression())
	{
		QOp1 = (QuadExpression *) Op1;
		NewOp1 = QOp1->GetByte(ByteIndex);
	}
	else if (Op1->IsADoubleExpression())
	{
		DOp1 = (DoubleExpression *) Op1;
		NewOp1 = DOp1->GetByte(ByteIndex);
	}
	else
	{
		if (ByteIndex == 0)
			NewOp1 = Op1;
		else
			NewOp1 = NULL;
	}

	if (Op2 == NULL)
	{
		NewOp2 = NULL;
	}
	else if (Op2->IsAQuadExpression())
	{
		QOp2 = (QuadExpression *) Op2;
		NewOp2 = QOp2->GetByte(ByteIndex);
	}
	else if (Op2->IsADoubleExpression())
	{
		DOp2 = (DoubleExpression *) Op2;
		NewOp2 = DOp2->GetByte(ByteIndex);
	}
	else
	{
		if (ByteIndex == 0)
			NewOp2 = Op2;
		else
			NewOp2 = NULL;
	}

	ReturnMe = new Operation(NewOp1, NewOp2, OSplitMe->GetOperator());

	return (Expression *) ReturnMe;
}

/****/
BOOL HasAConstant(Expression *Me)
{
	Operation *OpMe;
	DoubleExpression *DMe;
	QuadExpression *QMe;
	Lookup *LoMe;
	Predicate *PMe;

	if (Me == NULL)
	{
		return FALSE;
	}

	switch(Me->Type) {
	//else if (Me->IsALabel())
	case T_LABEL: {
		return FALSE;
	}
	//else if (Me->IsAConstant())
	case T_CONSTANT: {
		return TRUE;
	}
	//else if (Me->IsALookup())
	case T_LOOKUP: {
		LoMe = (Lookup *) Me;
		return (HasAConstant(LoMe->GetAddr()) || HasAConstant(LoMe->GetValue()));
	}
	//else if (Me->IsAQuadExpression())
	case T_QUAD: {
		QMe = (QuadExpression *) Me;
		return (HasAConstant(QMe->GetByte(0)) || HasAConstant(QMe->GetByte(1)) || HasAConstant(QMe->GetByte(2)) || HasAConstant(QMe->GetByte(3)));
	}
	//else if (Me->IsADoubleExpression())
	case T_DOUBLE: {
		DMe = (DoubleExpression *) Me;
		return (HasAConstant(DMe->GetByte(0)) || HasAConstant(DMe->GetByte(1)));
	}
	//else if (Me->IsAnOperation())
	case T_OPERATION: {
		OpMe = (Operation *) Me;
		return (HasAConstant(OpMe->GetOp1()) || HasAConstant(OpMe->GetOp2()));
	}
	//else
	case T_PREDICATE: {
		PMe = (Predicate *) Me;
		return (HasAConstant(PMe->GetLeft()) || HasAConstant(PMe->GetRight()));
	}
	default: {
		printf("Son of a %d...\n", Me->Type);
		return FALSE;
	}
	} // switch
}
/****/

BOOL EffectivelyNull(Expression *Me)
{
	if (Me != NULL)
		return Me->Nullness();
	else
		return TRUE;
#if 0
	Operation *OpMe;
	DoubleExpression *DMe;
	QuadExpression *QMe;
	Lookup *LoMe;
	Predicate *PMe;

	if (Me == NULL)
	{
		return TRUE;
	}

	switch(Me->Type) {
	//else if (Me->IsALabel())
	case T_LABEL: {
		return FALSE;
	}
	//else if (Me->IsAConstant())
	case T_CONSTANT: {
		return TRUE;
	}
	//else if (Me->IsALookup())
	case T_LOOKUP: {
		LoMe = (Lookup *) Me;
		return ((LoMe->GetAddr() == NULL) && (LoMe->GetValue() == NULL));
	}
	//else if (Me->IsAQuadExpression())
	case T_QUAD: {
		QMe = (QuadExpression *) Me;
		return ((QMe->GetByte(0) == NULL) && (QMe->GetByte(1) == NULL) && (QMe->GetByte(2) == NULL) && (QMe->GetByte(3) == NULL));
	}
	//else if (Me->IsADoubleExpression())
	case T_DOUBLE: {
		DMe = (DoubleExpression *) Me;
		return ((DMe->GetByte(0) == NULL) && (DMe->GetByte(1) == NULL));
	}
	//else if (Me->IsAnOperation())
	case T_OPERATION: {
		OpMe = (Operation *) Me;
		return (EffectivelyNull(OpMe->GetOp1()) && EffectivelyNull(OpMe->GetOp2()));
	}
	//else
	case T_PREDICATE: {
		PMe = (Predicate *) Me;
		return (EffectivelyNull(PMe->GetLeft()) || EffectivelyNull(PMe->GetRight()));
	}
	default: {
		printf("Son of a %d...\n", Me->Type);
		return FALSE;
	}
	} // switch
#endif
}

void PrintNull(int Level, FILE *f)
{
	int Loop;
	for (Loop = 0; Loop < Level; Loop++) fprintf(f, " ");
	fprintf(f, "(NULL)\n");
}

/*Expression *MakeACopyOf(Expression *Me)
{
	//return Me;
	Label *EvilClone = NULL;
	Label *LMe;
	Lookup *JustALittleSinisterClone;
	Lookup *LoMe;
	QuadExpression *OnlyBadWhenHighOnSugarClone;
	QuadExpression *QMe;
	DoubleExpression *ReallyBadWhenHighOnSugarClone;
	DoubleExpression *DMe;
	Operation *OpMe;
	Operation *VictimOfCircumstance;
	Constant *CMe;
	Constant *Inexorable;

	if (Me == NULL || EffectivelyNull(Me))
		return NULL;

	switch (Me->Type) {
	//if (Me->IsALabel())
	case T_LABEL: {
		LMe = (Label *) Me;
		EvilClone = new Label(LMe->GetNumber());
		return (Expression *) EvilClone;
	}
	// else if (Me->IsAConstant())
	case T_CONSTANT: {
		CMe = (Constant *) Me;
		Inexorable = new Constant(CMe->GetConstant());
		return (Expression *) Inexorable;
	}
	//else if (Me->IsALookup())
	case T_LOOKUP: {
		LoMe = (Lookup *) Me;
		JustALittleSinisterClone = new Lookup(LoMe->GetAddr(), LoMe->GetValue());
		return (Expression *) JustALittleSinisterClone;
	}
	//else if (Me->IsAQuadExpression())
	case T_QUAD: {
		QMe = (QuadExpression *) Me;
		OnlyBadWhenHighOnSugarClone = new QuadExpression(QMe->GetByte(0), QMe->GetByte(1), QMe->GetByte(2), QMe->GetByte(3));
		return (Expression *) OnlyBadWhenHighOnSugarClone;
	}
	//else if (Me->IsADoubleExpression())
	case T_DOUBLE: {
		DMe = (DoubleExpression *) Me;
		ReallyBadWhenHighOnSugarClone = new DoubleExpression(DMe->GetByte(0), DMe->GetByte(1));
		return (Expression *) ReallyBadWhenHighOnSugarClone;
	}
	//else if (Me->IsAnOperation())
	case T_OPERATION: {
		OpMe = (Operation *) Me;
		VictimOfCircumstance = new Operation(OpMe->GetOp1(), OpMe->GetOp2(), OpMe->GetOperator());
		return (Expression *) VictimOfCircumstance;
	}
	//else
	default: {
		printf("Son of a grrrr %d...\n", Me->Type);
		return NULL;
	}
	} // switch
}*/

Expression::Expression()
{
	//TheGarbageCollector.Insert(this);
	Type = -1;
}

Expression::~Expression()
{
	//TheGarbageCollector.Remove(this);
}

#ifndef __CTHULHU_PARSER
Label::Label()
{
	TheGarbageCollector.Insert(this);
	Type = T_LABEL;
	CountsOfStuff[T_LABEL]++;
	Number = LabelNumber++;
	InCPU = TRUE;
	MyDepth = 1;
	MyNullness = 0;
	MyIdempotency = 0;
}
#endif

Label::Label(int LabelAssigned)
{
#ifndef __CTHULHU_PARSER
	TheGarbageCollector.Insert(this);
#endif
	Type = T_LABEL;
	CountsOfStuff[T_LABEL]++;
	Number = LabelAssigned;
	//if ((CountsOfStuff[T_LABEL] % 50000) == 0)
	//	printf("Counts: %d %d %d %d %d %d %d %d\n", CountsOfStuff[1], CountsOfStuff[2], CountsOfStuff[3], CountsOfStuff[4], CountsOfStuff[5], CountsOfStuff[6], CountsOfStuff[7], CountsOfStuff[8]);
	InCPU = TRUE;
	MyDepth = 1;
	MyNullness = 0;
	if (LabelAssigned == -1)
		MyIdempotency = 1;
	else
		MyIdempotency = 0;
}

int Label::GetNumber()
{
	return Number;
}

void Label::Print(int Level, FILE *f)
{
	int Loop;
	for (Loop = 0; Loop < Level; Loop++) fprintf(f, " ");
	fprintf(f, "(Label %d)\n", Number);
}

Label::~Label()
{
	//TheGarbageCollector.Remove(this);
	CountsOfStuff[T_LABEL]--;
}

/***
Constant::Constant(BYTE ValueAssigned)
{
	Value = ValueAssigned;
}

BYTE Constant::GetValue()
{
	return Value;
}

Constant::~Constant()
{
}

Memory::Memory(ULONG VirtualAddressAssigned, BYTE ValueAssigned)
{
	VirtualAddress = VirtualAddressAssigned;
	Value = ValueAssigned;
}

ULONG Memory::GetVirtualAddress()
{
	return VirtualAddress;
}

BYTE Memory::GetValue()
{
	return Value;
}

Memory::~Memory()
{
}

Operator::Operator()
{
}

Operator::~Operator()
{
}



Boolean::Boolean()
{
}

Boolean::~Boolean()
{
}
**/
DoubleExpression::DoubleExpression(Expression *B0, Expression *B1)
{
#ifndef __CTHULHU_PARSER
	TheGarbageCollector.Insert(this);
#endif
	Type = T_DOUBLE;
	CountsOfStuff[T_DOUBLE]++;
	TwoBytes[0] = MakeACopyOf(B0);
	TwoBytes[1] = MakeACopyOf(B1);
	
	int B0Depth, B1Depth;
	int B0Nullness, B1Nullness;
	int B0Idempotency, B1Idempotency;
	
	if (B0 == NULL)
	{
		B0Depth = 0;
		B0Nullness = 1;
		B0Idempotency = 0;
	}
	else
	{
		B0Depth = B0->Depth(); 
		B0Nullness = B0->Nullness();
		B0Idempotency = B0->Idempotency();
	}
	if (B1 == NULL)
	{
		B1Depth = 0;
		B1Nullness = 1;
		B1Idempotency = 0;
	}
	else
	{
		B1Depth = B1->Depth();
		B1Nullness = B1->Nullness();
		B1Idempotency = B1->Idempotency();
	}
	if (B1Depth > B0Depth)
		MyDepth = B1Depth + 1;
	else
		MyDepth = B0Depth + 1; 
	MyNullness = B1Nullness && B0Nullness;
	MyIdempotency = B1Idempotency || B0Idempotency;
}

Expression *DoubleExpression::GetByte(int Index)
{
	if (Index > 1)
		return NULL;
	else
		return TwoBytes[Index];
}

void DoubleExpression::Print(int Level, FILE *f)
{
	int Loop;
	for (Loop = 0; Loop < Level; Loop++) fprintf(f, " ");
	fprintf(f, "(DoubleExpression\n");
	if (TwoBytes[0] != NULL)
		TwoBytes[0]->Print(Level + 1, f);
	else
		PrintNull(Level + 1, f);
	if (TwoBytes[1] != NULL)
		TwoBytes[1]->Print(Level + 1, f);
	else
		PrintNull(Level + 1, f);
	for (Loop = 0; Loop < Level; Loop++) fprintf(f, " ");
	fprintf(f, ")\n");
}


DoubleExpression::~DoubleExpression()
{
	//TheGarbageCollector.Remove(this);
	//if (TwoBytes[0] != NULL)
	//	delete TwoBytes[0];
	//if (TwoBytes[1] != NULL)
	//	delete TwoBytes[1];
	CountsOfStuff[T_DOUBLE]--;
}


//int NumQuadAlive = 0;

QuadExpression::QuadExpression(Expression *B0, Expression *B1, Expression *B2, Expression *B3)
{
#ifndef __CTHULHU_PARSER
	TheGarbageCollector.Insert(this);
#endif
	Type = T_QUAD;
	CountsOfStuff[T_QUAD]++;
	FourBytes[0] = MakeACopyOf(B0);
	FourBytes[1] = MakeACopyOf(B1);
	FourBytes[2] = MakeACopyOf(B2);
	FourBytes[3] = MakeACopyOf(B3);
	
	//NumQuadAlive++;
	
	int B0Depth, B1Depth;
	int B0Nullness, B1Nullness;
	int B0Idempotency, B1Idempotency;
	int B2Depth, B3Depth;
	int B2Nullness, B3Nullness;
	int B2Idempotency, B3Idempotency;
	
	if (B0 == NULL)
	{
		B0Depth = 0;
		B0Nullness = 1;
		B0Idempotency = 0;
	}
	else
	{
		B0Depth = B0->Depth(); 
		B0Nullness = B0->Nullness();
		B0Idempotency = B0->Idempotency();
	}
	if (B1 == NULL)
	{
		B1Depth = 0;
		B1Nullness = 1;
		B1Idempotency = 0;
	}
	else
	{
		B1Depth = B1->Depth();
		B1Nullness = B1->Nullness();
		B1Idempotency = B1->Idempotency();
	}
	if (B2 == NULL)
	{
		B2Depth = 0;
		B2Nullness = 1;
		B2Idempotency = 0;
	}
	else
	{
		B2Depth = B2->Depth();
		B2Nullness = B2->Nullness();
		B2Idempotency = B2->Idempotency();
	}
	if (B3 == NULL)
	{
		B3Depth = 0;
		B3Nullness = 1;
		B3Idempotency = 0;
	}
	else
	{
		B3Depth = B3->Depth();
		B3Nullness = B3->Nullness();
		B3Idempotency = B3->Idempotency();
	}
	if (B1Depth > B0Depth)
		MyDepth = B1Depth;
	else
		MyDepth = B0Depth;
	if (MyDepth < B2Depth) MyDepth = B2Depth;
	if (MyDepth < B3Depth) MyDepth = B3Depth;
	MyDepth = MyDepth + 1; 
	MyNullness = B1Nullness && B0Nullness && B2Nullness && B3Nullness;
	MyIdempotency = B1Idempotency || B0Idempotency || B2Idempotency || B3Idempotency;	
}

Expression *QuadExpression::GetByte(int Index)
{
	return FourBytes[Index % 4];
}

void QuadExpression::Print(int Level, FILE *f)
{
	int Loop;
	for (Loop = 0; Loop < Level; Loop++) fprintf(f, " ");
	fprintf(f, "(QuadExpression\n");
	if (FourBytes[0] != NULL)
		FourBytes[0]->Print(Level + 1, f);
	else
		PrintNull(Level + 1, f);
	if (FourBytes[1] != NULL)
		FourBytes[1]->Print(Level + 1, f);
	else
		PrintNull(Level + 1, f);
	if (FourBytes[2] != NULL)
		FourBytes[2]->Print(Level + 1, f);
	else
		PrintNull(Level + 1, f);
	if (FourBytes[3] != NULL)
		FourBytes[3]->Print(Level + 1, f);
	else
		PrintNull(Level + 1, f);
	for (Loop = 0; Loop < Level; Loop++) fprintf(f, " ");
	fprintf(f, ")\n");
}


QuadExpression::~QuadExpression()
{
	//TheGarbageCollector.Remove(this);
	//if (FourBytes[0] != NULL)
	//	delete FourBytes[0];
	//if (FourBytes[1] != NULL)
	//	delete FourBytes[1];
	//if (FourBytes[2] != NULL)
	//	delete FourBytes[2];
	//if (FourBytes[3] != NULL)
	//	delete FourBytes[3];
	CountsOfStuff[T_QUAD]--;
	//NumQuadAlive--;
	//printf("NumQuadAlive %d\n", NumQuadAlive);
}

Lookup::Lookup(Expression *Addr, Expression *Value)
{
#ifndef __CTHULHU_PARSER
	TheGarbageCollector.Insert(this);
#endif
	Type = T_LOOKUP;
	CountsOfStuff[T_LOOKUP]++;
	TheAddr = MakeACopyOf(Addr);
	TheValue = MakeACopyOf(Value);

	int AddrDepth, ValueDepth;
	int AddrNullness, ValueNullness;
	int AddrIdempotency, ValueIdempotency;
	
	if (Addr == NULL)
	{
		AddrDepth = 0;
		AddrNullness = 1;
		AddrIdempotency = 0;
	}
	else
	{
		AddrDepth = Addr->Depth(); 
		AddrNullness = Addr->Nullness();
		AddrIdempotency = Addr->Idempotency();
	}
	if (Value == NULL)
	{
		ValueDepth = 0;
		ValueNullness = 1;
		ValueIdempotency = 0;
	}
	else
	{
		ValueDepth = Value->Depth();
		ValueNullness = Value->Nullness();
		ValueIdempotency = Value->Idempotency();
	}
	if (ValueDepth > AddrDepth)
		MyDepth = ValueDepth + 1;
	else
		MyDepth = AddrDepth + 1; 
	MyNullness = ValueNullness && AddrNullness;
	MyIdempotency = ValueIdempotency || AddrIdempotency;
		
}

Lookup::~Lookup()
{
	//TheGarbageCollector.Remove(this);
	//if (TheAddr != NULL)
	//	delete TheAddr;
	//if (TheValue != NULL)
	//	delete TheValue;
	CountsOfStuff[T_LOOKUP]--;

}

void Lookup::Print(int Level, FILE *f)
{
	int Loop;
	for (Loop = 0; Loop < Level; Loop++) fprintf(f, " ");
	fprintf(f, "(Lookup\n");
	if (TheAddr != NULL)
		TheAddr->Print(Level + 1, f);
	else
		PrintNull(Level + 1, f);
	if (TheValue != NULL)
		TheValue->Print(Level + 1, f);
	else
		PrintNull(Level + 1, f);
	for (Loop = 0; Loop < Level; Loop++) fprintf(f, " ");
	fprintf(f, ")\n");
}

Expression *Lookup::GetAddr()
{
	return TheAddr;
}

Expression *Lookup::GetValue()
{
	return TheValue;
}

#include <stdlib.h>

Operation::Operation(Expression *InOp1, Expression *InOp2, char *InOperator)
{
#ifndef __CTHULHU_PARSER
	TheGarbageCollector.Insert(this);
#endif
	Type = T_OPERATION;
	CountsOfStuff[T_OPERATION]++;
	Op1 = MakeACopyOf(InOp1);
	Op2 = MakeACopyOf(InOp2);
	Operator = InOperator;
	//if (rand() % 50000 == 0) puts(InOperator);
	
	int InOp1Depth, InOp2Depth;
	int InOp1Nullness, InOp2Nullness;
	int InOp1Idempotency, InOp2Idempotency;
	
	if (InOp1 == NULL)
	{
		InOp1Depth = 0;
		InOp1Nullness = 1;
		InOp1Idempotency = 0;
	}
	else
	{
		InOp1Depth = InOp1->Depth(); 
		InOp1Nullness = InOp1->Nullness();
		InOp1Idempotency = InOp1->Idempotency();
	}
	if (InOp2 == NULL)
	{
		InOp2Depth = 0;
		InOp2Nullness = 1;
		InOp2Idempotency = 0;
	}
	else
	{
		InOp2Depth = InOp2->Depth();
		InOp2Nullness = InOp2->Nullness();
		InOp2Idempotency = InOp2->Idempotency();
	}
	if (InOp2Depth > InOp1Depth)
		MyDepth = InOp2Depth + 1;
	else
		MyDepth = InOp1Depth + 1; 
	MyNullness = InOp2Nullness && InOp1Nullness;
	MyIdempotency = InOp2Idempotency || InOp1Idempotency;
	
}

Expression *Operation::GetOp1()
{
	return Op1;
}

Expression *Operation::GetOp2()
{
	return Op2;
}

char *Operation::GetOperator()
{
	return Operator;
}

void Operation::Print(int Level, FILE *f)
{
	int Loop;
	for (Loop = 0; Loop < Level; Loop++) fprintf(f, " ");
#ifndef __CTHULHU_PARSER
	if (GLOBALCthulhuMode)
	{
		fprintf(f, "(Operation %s\n", Operator);
	}	
	else
#else
	if (1)
#endif
	{
		fprintf(f, "(Operation \"%s\"\n", Operator);
	}
	
	if (Op1 != NULL)
		Op1->Print(Level + 1, f);
	else
		PrintNull(Level + 1, f);
	if (Op2 != NULL)
		Op2->Print(Level + 1, f);
	else
		PrintNull(Level + 1, f);
	for (Loop = 0; Loop < Level; Loop++) fprintf(f, " ");
	fprintf(f, ")\n");
}

Operation::~Operation()
{
	//TheGarbageCollector.Remove(this);
	//if (Op1 != NULL)
	//	delete Op1;
	//if (Op2 != NULL)
	//	delete Op2;
	CountsOfStuff[T_OPERATION]--;
}

//int GlobalConstCount = 0;

Constant::Constant(int InConstant)
{
#ifndef __CTHULHU_PARSER
	TheGarbageCollector.Insert(this);
#endif
	Type = T_CONSTANT;
	CountsOfStuff[T_CONSTANT]++;
	//GlobalConstCount++;
	//if (!(GlobalConstCount % 500))
	//	printf("GlobalConstCount == %d\n", GlobalConstCount);
	TheConstant = InConstant;
	
	MyIdempotency = 0;
	MyNullness = 1;
	MyDepth = 1;
}

void Constant::Print(int Level, FILE *f)
{
	int Loop;
	for (Loop = 0; Loop < Level; Loop++) fprintf(f, " ");
#ifndef __CTHULHU_PARSER
	if (GLOBALCthulhuMode)
	{
		fprintf(f, "(Constant %d)\n", TheConstant, TheConstant, TheConstant);
		
	}
	else
#else
	if (1)
#endif
	{
		if ((TheConstant > 0x30) && (TheConstant < 0x7d))
			fprintf(f, "(Constant %d \"%x %c\")\n", TheConstant, TheConstant, TheConstant);
		else
			fprintf(f, "(Constant %d \"%x ?\")\n", TheConstant, TheConstant);
	}
	
}

Constant::~Constant()
{
	//TheGarbageCollector.Remove(this);
	CountsOfStuff[T_CONSTANT]--;
	//GlobalConstCount--;
}

Predicate::Predicate(Expression *InLeft, Expression *InRight, char *InRelation, unsigned int InWhereAt, unsigned int InPageTableBase, BOOL InInteresting, unsigned int inCPL)
{
#ifndef __CTHULHU_PARSER
	TheGarbageCollector.Insert(this);
#endif
	Type = T_PREDICATE;
	Left = InLeft;
	Right = InRight;
	Relation = InRelation;
	WhereAt = InWhereAt;
	Interesting = InInteresting;
	PageTableBase = InPageTableBase;
	CPL = inCPL;
	
	int LeftDepth, RightDepth;
	int LeftIdempotency, RightIdempotency;
	
	if (Left == NULL)
	{
		LeftDepth = 0;
		LeftIdempotency = 0;
	}
	else
	{
		LeftDepth = Left->Depth();
		LeftIdempotency = Left->Idempotency();
	}
	if (Right == NULL)
	{
		RightDepth = 0;
		RightIdempotency = 0;
	}
	else
	{
		RightDepth = Right->Depth();
		RightIdempotency = Right->Idempotency();
	}
	if (RightDepth > LeftDepth)
		MyDepth = RightDepth + 1;
	else
		MyDepth = LeftDepth + 1; 
	MyNullness = 0;
	if (RightIdempotency || LeftIdempotency)
		MyIdempotency = 1;
	else
		MyIdempotency = 0;

}

void Predicate::Print(int Level, FILE *f)
{
	int Loop;
	for (Loop = 0; Loop < Level; Loop++) fprintf(f, " ");
#ifndef __CTHULHU_PARSER
	if (GLOBALCthulhuMode)
	{
		fprintf(f, "(Predicate %s %08x %08x\n", Relation, WhereAt, PageTableBase);
	}
	else
#else
	if (1)
#endif
	{
		fprintf(f, "(Predicate %s \"from EIP == %08x, cr3 == %08x\"\n", Relation, WhereAt, PageTableBase);
	}
	
	if (Left != NULL)
		Left->Print(Level + 1, f);
	else
		PrintNull(Level + 1, f);

	if (Right != NULL)
		Right->Print(Level + 1, f);
	else
		PrintNull(Level + 1, f);
	for (Loop = 0; Loop < Level; Loop++) fprintf(f, " ");
	fprintf(f, ")\n");
}

Predicate::~Predicate()
{
}






