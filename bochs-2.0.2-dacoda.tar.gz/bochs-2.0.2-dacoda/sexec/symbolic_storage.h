#ifndef __SYMBOLIC_STORAGE_H
#define __SYMBOLIC_STORAGE_H

#include "garbage.h"

typedef void linear2phyfunction(unsigned int, unsigned int *, unsigned int *);

#include "expression.h"
class Expression;

#include <map>
using namespace std;

#ifndef ULONG
#define ULONG unsigned long int
#endif

#define NUM_SAVED_PREDICATES 100000
#define NUM_SAVED_LABELBYTES 1000000

class SymbolicStorage
{
private:
	typedef map<ULONG, Expression *> SymbolicStorageMap;
	SymbolicStorageMap SymbolicMemory;
	//SymbolicStorageMap SymbolicRegisters;
	Expression *SymbolicRegisters[10][4];
	Expression *ThePredicates[NUM_SAVED_PREDICATES];
	int PredHead;
	unsigned char StoredLabelBytes[NUM_SAVED_LABELBYTES];
	unsigned long int StoredLabelBytesTotal;
	Expression *IdempotentExpr;
	Expression *SaveMeSaveMe;
public:
	SymbolicStorage();
	void WriteSymbolicMemory(ULONG PhysicalAddress, Expression *pExpression);
	Expression *ReadSymbolicMemory(ULONG PhysicalAddress);
	int NumLabelsInMemory();
	void WriteSymbolicRegister(ULONG Index, ULONG Byte, Expression *pExpression);
	Expression *ReadSymbolicRegister(ULONG Index, ULONG Byte);
	void LabelDump(void *f);
	void PhysicalLabelDump();
	void MarkReachable(ReachableNode *pReachable);
	void AddPredicate(Expression *pExpression);
	void PrintPredicates(ULONG StartLabel, ULONG EndLabel, ULONG CommType);
	void PrintAllPredicates(ULONG StartLabel, ULONG EndLabel);
	void SummarizePredicates(ULONG StartLabel, ULONG EndLabel);
	void AddLabelByte(unsigned char AddMe);
	int GetLabelByte(ULONG LabelNumber);
	void SigFromGamma(ULONG GammaStart, ULONG GammaEnd);
	void PleaseSaveMe(Expression *Shade) {SaveMeSaveMe = Shade;};
	~SymbolicStorage();
};

#endif
