/* Log manager for the treatment of a packet arrival event
 *
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 04/24/2005
 * Last update: 10/30/2006
 */
#ifndef __LOG_M_NETPKT_H
#define __LOG_M_NETPKT_H

#include <iostream>
using namespace std;

#include "log_manager.h"
#include "log_e_netpkt.h"
#include "bochs.h"

class LogMNetPkt : public LogManager
{
  private:
    static LogMNetPkt* instance;

  protected:
     LogMNetPkt();
   
  public:
    static LogMNetPkt* Instance();
    static LogENetPkt* readLoggedNetPkt(ifstream *logIn);
    static void writeLogEntry(LogENetPkt *logEntry, ofstream *logFile);
    static void timerHandler();
    ~LogMNetPkt();
};

#endif
