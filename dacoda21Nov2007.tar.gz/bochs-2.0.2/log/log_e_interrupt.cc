/**
 * Log entry for interrupt events.
 * Author: Daniela Oliveira
 * Date: 11/21/2005
 * Last update: 03/05/2007
 */

#include "config.h"

#if BX_LOG_REPLAY

#include <iostream>
#include <fstream> // just for debugging
using namespace std;

#include "log_e_interrupt.h"

extern ofstream devFile;

LogEInterrupt::LogEInterrupt()
{
   //printf("LogEInterrupt constructor\n");
   idNumber = idNumberGenerator++;
}

/**
 * This constructor is used when I want to make a copy of my object.
 */
LogEInterrupt::LogEInterrupt(LogEInterrupt *logEntry) 
{
 // idNumber = idNumberGenerator++;
  setTick(logEntry->getTick());
  setRaise(logEntry->getRaise());
  setIRQNum(logEntry->getIRQNum());
} 



void LogEInterrupt::setIRQNum(unsigned num)
{
  irq_num = num;
}

unsigned LogEInterrupt::getIRQNum()
{
  return irq_num;
}

void LogEInterrupt::setRaise(unsigned num)
{
  raise = num;
}
                                                                                    
unsigned LogEInterrupt::getRaise()
{
  return raise;
}

/**
 * Set the value of atributes irq_num and raise according to 
 * byte value passed as a parameter. Encoding is explained in log_e_interrupt.h
 */  
Bit8u LogEInterrupt::getFlags() 
{
  bitset<NUM_FLAGS_INTERRUPT> bs(irq_num);
  bs.set(4, raise);  
  if (!checkFlags(bs)) {
    /*cout << "LogEInterrupt::getFlags: invalid flag: " << bs.to_ulong() << 
    "(" << bs.template to_string<char, char_traits<char>, allocator<char> >() << ")\n";
    exit(1); */
  }

  //devFile << "Bitset: " << bs.to_ulong() << 
   //"(" << bs.template to_string<char, char_traits<char>, allocator<char> >() << ") ";
  return (Bit8u) (bs.to_ulong());
}

/**
 * Set the value of atributes irq_num and raise according to 
 * byte value passed as a parameter. Encoding is explained in log_e_interrupt.h
 */  

void LogEInterrupt::setFlags(Bit8u value) 
{
  bitset<NUM_FLAGS_INTERRUPT> bs(value);
 // devFile << "flagValue in setFlags: " <<  (unsigned) value << "bs.to_ulong:" << bs.to_ulong() << " ";
  if (!checkFlags(bs)) {
   /* cout << "LogEInterrupt::setFlags: invalid flag: " << bs.to_ulong() << 
    "(" << bs.template to_string<char, char_traits<char>, allocator<char> >() << ")\n";
    exit(1); */
  }
 // devFile << " Bitset: " << bs.to_ulong() << 
   // "(" << bs.template to_string<char, char_traits<char>, allocator<char> >() << ")";
  bitset<4> bsIRQ;
  for(int i=0; i< 4; i++) {
    bsIRQ[i] = bs[i];
  } 
  irq_num = (unsigned) bsIRQ.to_ulong();
  //devFile << " Irq_num: " << irq_num << " ";
  if (bs.test(4)) {
    raise = 1;
  }
  else {
    raise = 0;
  }
  //devFile << " Raise: " << raise << "\n";

}

/**
 * Return true if flags passed as a parameter is a valid flag and false otherwise.
 * Valid flags: value from 0 to 31.
 */
bool LogEInterrupt::checkFlags(bitset<NUM_FLAGS_INTERRUPT> flagsReceived)
{
  if (flagsReceived.to_ulong() > 31) {
    return false;
  }
  else return true;
}
/**
 * Return true if flags passed as a parameter is a valid flag and false otherwise.
 * Valid flags: value from 0 to 31.
 */

LogEInterrupt::~LogEInterrupt()
{
   //printf("LogEInterrupt destructor\n");

}

#endif
