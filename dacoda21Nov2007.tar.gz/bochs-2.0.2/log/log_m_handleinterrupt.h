/**
 * Log manager for handling interrupt events.
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 05/08/2005
 * Last update: 06/19/2006 
 */
#ifndef __LOG_M_HANDLEINTERRUPT_H
#define __LOG_M_HANDLEINTERRUPT_H

#include <iostream>
using namespace std;

#include "log_manager.h"
#include "log_e_handleinterrupt.h"
#include "bochs.h"

class LogMHandleInterrupt : public LogManager
{
  private:
    static LogMHandleInterrupt* instance;
    static bool isAsyncEventHandled;
    static bool isInterruptHandled;

  protected:
     LogMHandleInterrupt();

  public:
    static LogMHandleInterrupt* Instance();
   // static LogEHandleInterrupt *readLoggedHandleInterrupt(ifstream *logIn);
    static void timerHandler();
    static void setIsAsyncEventHandled(bool value);
    static bool getIsAsyncEventHandled();
    static void setIsInterruptHandled(bool value);
    static bool getIsInterruptHandled();
    ~LogMHandleInterrupt();
};

#endif
