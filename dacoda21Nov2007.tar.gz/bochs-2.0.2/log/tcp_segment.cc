/**
 * Abstraction of a TCP segment  
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 01/30/2007
 * Last update: 03/05/2007
 */

#if BX_LOG_REPLAY && BX_LOG_RECOVERY

#include "tcp_segment.h"
#include "log_manager.h"
#include "recovery_manager.h"
//#include "bochs.h"
//#include <signal.h>
#include <fstream>
#include <bitset>
#include <string>
using namespace std;

// just for debug
extern ofstream devFile;
extern ofstream ioFile;
extern ofstream normFile;


/**
 * Class Word16
 */
Word16::Word16(Bit8u p1, Bit8u p2) {
  part1 = p1;
  part2 = p2;
}
   
Word16::Word16(Bit16u number) {
  part1 = (number >> 8) & 0x00FF;
  part2 = number & 0x00FF;
  
} 
bool Word16::equal(Word16 *w16) {

 if ( (part1 == w16->getPart(1)) && (part2 == w16->getPart(2)) ) {
    return true;
  } 
  else {
    return false;
  }

}

Bit8u Word16::getPart(Bit8u num) {

  switch(num) {

    case 1:
      return part1;
      
    case 2:
      return part2;
   
    default:
      cout << "Error in Word16::getPart: there is no part number " << num << "\n";
      exit(1);
  }

}
    
void Word16::print() {

  devFile << (unsigned) part1 << "." << (unsigned) part2 << "\n";  
}
    

Bit16u Word16::toBit16u() {

  return ((Bit16u) ((part1 * 256) + part2));

}
    
Word16::~Word16() {

}

/**
 * Class Word32
 */
Word32::Word32(Bit8u p1, Bit8u p2, Bit8u p3, Bit8u p4) {
  part1 = p1;
  part2 = p2;
  part3 = p3;
  part4 = p4;
}
 
Word32::Word32(Bit32u number) {


  part1 = (number >> 24) & 0x000000FF;
  part2 = (number >> 16) & 0x000000FF;
  part3 = (number >> 8) & 0x000000FF;
  part4  = number & 0x000000FF;
  
}   
bool Word32::equal(Word32 *w32) {

 if ( (part1 == w32->getPart(1)) && (part2 == w32->getPart(2)) && 
    (part3 == w32->getPart(3)) && (part4 == w32->getPart(4)) ) {
    return true;
  } 
  else {
    return false;
  }

}

Bit8u Word32::getPart(Bit8u num) {

  switch(num) {

    case 1:
      return part1;
      
    case 2:
      return part2;

    case 3:
      return part3;
      
    case 4:
      return part4;

   
    default:
      cout << "Error in Word32::getPart: there is no part number " << num << "\n";
      exit(1);

  }
}
    
void Word32::print() {

 if ((LogManager::isReplayMode() && RecoveryManager::isRecovering()) || (LogManager::isSemiReplayMode()) ||
   (RecoveryManager::isSemiReplayFinished())) {

  devFile << (unsigned) part1 << "." << (unsigned) part2 << "." <<
          (unsigned) part3 << "." << (unsigned) part4 << "\n";  

  } 
  else if ((LogManager::isReplayMode()) && (!RecoveryManager::isRecovering())) {
  ioFile << (unsigned) part1 << "." << (unsigned) part2 << "." <<
          (unsigned) part3 << "." << (unsigned) part4 << "\n";  

  } 
  else if (LogManager::isLogMode()) {
    normFile << (unsigned) part1 << "." << (unsigned) part2 << "." <<
          (unsigned) part3 << "." << (unsigned) part4 << "\n";  
 
  }
}
    

Bit32u Word32::toBit32u() {

  return (Bit32u) ((part1 * 16777216) + (part2 * 65536) + (part3 * 256) + part4);

}
    
Word32::~Word32() {

}


/**
 * Constructor
 */
TCPSegment::TCPSegment(unsigned char *ethF, int nBytes) 
{
  ack= false;
  psh = false;
  rst = false;
  syn = false;
  fin = false;
  //cout << "TCPSegment created.\n";
  ethFrame = ethF;
  extractFields();
  ethNBytes = nBytes;
 } 

void TCPSegment::setReceived(bool value) {
  received = value;
}
    
bool TCPSegment::getReceived() {
  return received;
}

bool  TCPSegment::getACK() {
  return ack;
}
    
bool  TCPSegment::getRST() {
  return rst;
}
    
bool  TCPSegment::getSYN() {
  return syn;
}
    
bool TCPSegment::getFIN() {
  return fin;
}

Word32 *TCPSegment::getSrcIP() {
  return sourceIP;
}
    
Word32 *TCPSegment::getDestIP() {
  return destinyIP;
}
    
Word16 *TCPSegment::getSrcPort() {
  return portSrc;
}
    
Word16 *TCPSegment::getDestPort() {
  return portDest;
}

Word32 *TCPSegment::getSequenceNumber() {
  return seqNumber;
}
    
Word32 *TCPSegment::getACKNumber() {
  return ackNumber;
}

void TCPSegment::setACKNumber(Bit32u number) {

  delete ackNumber;
  ackNumber = new Word32(number);
  devFile << "Setando ack number em TCPSegment::setACKNumber para: " << ackNumber->toBit32u() << "\n"; 
  ethFrame[42] = ackNumber->getPart(1);
  ethFrame[43] = ackNumber->getPart(2);
  ethFrame[44] = ackNumber->getPart(3);
  ethFrame[45] = ackNumber->getPart(4);
}

void TCPSegment::setSequenceNumber(Bit32u number) {
  delete seqNumber;
  seqNumber = new Word32(number);
  ethFrame[38] = seqNumber->getPart(1);
  ethFrame[39] = seqNumber->getPart(2);
  ethFrame[40] = seqNumber->getPart(3);
  ethFrame[41] = seqNumber->getPart(4);

}

/**
 * Extract all necessary fields from the Ethernet frame
 */
void TCPSegment::extractFields() {

  if (ethFrame == NULL) {
    cout << "Error in TCPSegment::extractFields: cannot extract fields from a null frame\n";
    exit(1);
  }
  extractIPHeaderLength(ethFrame[14]);
  ipDatagramLength = new Word16(ethFrame[16], ethFrame[17]);
  tcpSegLen = Bit16u (ipDatagramLength->toBit16u()  - (ipHeaderLength * 4));
  sourceIP = new Word32(ethFrame[26], ethFrame[27], ethFrame[28], ethFrame[29]);
  destinyIP = new Word32(ethFrame[30], ethFrame[31], ethFrame[32], ethFrame[33]);
  portSrc = new Word16(ethFrame[34], ethFrame[35]);
  portDest = new Word16(ethFrame[36], ethFrame[37]);
  seqNumber = new Word32(ethFrame[38], ethFrame[39], ethFrame[40], ethFrame[41]);
  ackNumber = new Word32(ethFrame[42], ethFrame[43], ethFrame[44], ethFrame[45]);
  extractHeaderLength(ethFrame[46]);
  extractFlags(ethFrame[47]);
  checksum = new Word16(ethFrame[50], ethFrame[51]); 
}

void TCPSegment::extractIPHeaderLength(Bit8u byte) {

  bitset<8> bs(byte);
  bitset<4> bsIHL;
  for(int i=0; i< 4; i++) {
    bsIHL[i] = bs[i];
  } 
  ipHeaderLength = (unsigned) bsIHL.to_ulong();
 // devFile << "Version + IP Header bitset: " << bs.template to_string<char, char_traits<char>, allocator<char> >() 
  //        << "\n";

}

void TCPSegment::extractHeaderLength(Bit8u byte) {


  headerLength = (byte >> 4) & 0x0F;
  //devFile << "ethFrame[46]: " << (unsigned) byte;
  bitset<8> bs(byte);
/*  bitset<4> bsHL;
  for(int i=4; i< 8; i++) {
    bsHL[j] = bs[i];
    j++
  } 
 
  headerLength = (unsigned) bsHL.to_ulong();*/
 // Commented out by Jed
  //devFile << " Header length to string: " << bs.template to_string<char, char_traits<char>, allocator<char> >()  << "\n";
}
    

void TCPSegment::extractFlags(Bit8u byte) {

   bitset<8> bs(byte);
   
   if (bs.test(4)) { // ACK
    ack = true;
   }

   if (bs.test(3)) { // PSH
     psh = true;

   }

   if (bs.test(2)) { // RST
     rst = true;

   }

   if (bs.test(1)) { // SYN
    syn = true;

   }

   if (bs.test(0)) { // FIN
    fin = true;

   }
   if ((LogManager::isReplayMode() && RecoveryManager::isRecovering()) || (LogManager::isSemiReplayMode()) ||
   (RecoveryManager::isSemiReplayFinished())) {
 // Commented out by Jed
     //devFile << " Flags byte: " << bs.template to_string<char, char_traits<char>, allocator<char> >() << "\n" ;  
   }
   else if ((LogManager::isReplayMode()) && (!RecoveryManager::isRecovering())) {
 // Commented out by Jed
     //ioFile << " Flags byte: " << bs.template to_string<char, char_traits<char>, allocator<char> >() << "\n" ;
   }




}

void TCPSegment::print() {

  Word16 *receiveWindow = new Word16(ethFrame[48], ethFrame[49]);

  if ((LogManager::isReplayMode() && RecoveryManager::isRecovering()) || (LogManager::isSemiReplayMode()) ||
   (RecoveryManager::isSemiReplayFinished())) {

  devFile << "TCP SEGMENT: \n";
  devFile << "IP HeaderLengh: " << (unsigned) ipHeaderLength << "\n";
  devFile << "IP Datagram length: " << ipDatagramLength->toBit16u() << "\n";
  devFile << "TCP segment length: " << tcpSegLen << "\n";
  devFile <<  "Source IP: ";
  sourceIP->print();
  devFile << "Destination IP: ";
  destinyIP->print();
  devFile << "Port source: " << portSrc->toBit16u() << "\n";
  devFile << "Port destiny: " << portDest->toBit16u() << "\n";
  devFile << "Sequence number: " << seqNumber->toBit32u() << "\n";
  devFile << "Ack number: " << ackNumber->toBit32u() << "\n";
  devFile << "Header length: " << (unsigned) headerLength << "\n";
  devFile << "ACK?" << ack << "\n";
  devFile << "PSH?" << psh << "\n";
  devFile << "RST?" << rst << "\n";
  devFile << "SYN?" << syn << "\n";
  devFile << "FIN?" << fin << "\n";
  devFile << "Receive Window: " << receiveWindow->toBit16u(); 
  devFile << "Checksum: " << checksum->toBit16u() << "\n";
  //setChecksumBuffer();
  devFile << "Computed checksum: " << computeChecksum(ethFrame, (14 + ethFrame[16] * 256 + ethFrame[17])) << "\n";

}else if ((LogManager::isReplayMode()) && (!RecoveryManager::isRecovering())) {
  ioFile << "TCP SEGMENT: \n";
   ioFile << "IP HeaderLengh: " << (unsigned) ipHeaderLength << "\n";
   ioFile << "IP Datagram length: " << ipDatagramLength->toBit16u() << "\n";
   ioFile << "TCP segment length: " << tcpSegLen << "\n";
   ioFile <<  "Source IP: ";
  sourceIP->print();
   ioFile << "Destination IP: ";
  destinyIP->print();
   ioFile << "Port source: " << portSrc->toBit16u() << "\n";
   ioFile  << "Port destiny: " << portDest->toBit16u() << "\n";
   ioFile << "Sequence number: " << seqNumber->toBit32u() << "\n";
  ioFile << "Ack number: " << ackNumber->toBit32u() << "\n";
   ioFile << "Header length: " << (unsigned) headerLength << "\n";
   ioFile << "ACK?" << ack << "\n";
   ioFile << "PSH?" << psh << "\n";
   ioFile << "RST?" << rst << "\n";
   ioFile << "SYN?" << syn << "\n";
   ioFile << "FIN?" << fin << "\n";
   ioFile << "Receive Window: " << receiveWindow->toBit16u(); 
   ioFile << "Checksum: " << checksum->toBit16u() << "\n";
   ioFile << "Computed checksum: " << computeChecksum(ethFrame, (14 + ethFrame[16] * 256 + ethFrame[17])) << "\n";
 }
 else if (LogManager::isLogMode()) {

   normFile << "TCP SEGMENT: \n";
   normFile << "IP HeaderLengh: " << (unsigned) ipHeaderLength << "\n";
   normFile << "IP Datagram length: " << ipDatagramLength->toBit16u() << "\n";
   normFile << "TCP segment length: " << tcpSegLen << "\n";
   normFile <<  "Source IP: ";
   sourceIP->print();
   normFile << "Destination IP: ";
   destinyIP->print();
   normFile << "Port source: " << portSrc->toBit16u() << "\n";
   normFile  << "Port destiny: " << portDest->toBit16u() << "\n";
   normFile << "Sequence number: " << seqNumber->toBit32u() << "\n";
   normFile << "Ack number: " << ackNumber->toBit32u() << "\n";
   normFile << "Header length: " << (unsigned) headerLength << "\n";
   normFile << "ACK?" << ack << "\n";
   normFile << "PSH?" << psh << "\n";
   normFile << "RST?" << rst << "\n";
   normFile << "SYN?" << syn << "\n";
   normFile << "FIN?" << fin << "\n";
   normFile << "Receive Window: " << receiveWindow->toBit16u(); 
   normFile << "Checksum: " << checksum->toBit16u() << "\n";
   normFile << "Computed checksum: " << computeChecksum(ethFrame, (14 + ethFrame[16] * 256 + ethFrame[17])) << "\n";



  }

 
}

/**
 * Generates an array with all bytes from the TCP segment. If there is a odd
 * number of bytes padding is necessary.
 */
/*void TCPSegment::setTCPBuffer() {

 

 if ((tcpSegLen % 2) == 0) {
   padding = false;
 }
 else {
   padding = true; 
 }

 int offset = 34; // TCP data starts at ethFrame[26]
 int i = 0;
 //int j= 0;

 for (i=0; i<tcpSegLen;i++) {
   tcpBuffer[i] = ethFrame[offset + i];
 }*/
 
/* if (odd) { // TCP segment has an even number of bytes
   for(i=0; i<tcpSegLen-1); i+=2) {
     tcpBuffer[j] = ethFrame[offset + i] * 256 + ethFrame[offset + i + 1];
     j++;
     numOctectsTCPSeg++;
   }
   tcpBuffer[j] = ethFrame[offset + i]; 
   numOctectsTCPSeg++;
 }
 else { // TCP segment has an even number of bytes
    for(i=0; i<(tcpSegLen-1); i+=2) {
     tcpBuffer[j] = ethFrame[offset + i] * 256 + ethFrame[offset + i + 1];
     j++;
     numOctectsTCPSeg++;
   }
 }*/

 // Set checksum bytes to zero
 //tcpBuffer[50] = 0;
 //tcpBuffer[51] = 0;

/* if ((numOctectsTCPSeg % 2) == 0) {
   padding = false;
 }
 else {
   padding = true; 
 }*/

//}

/*void TCPSegment::setIPAddrBuffer() {

  int i;
  int offsetSrc = 26; // Src IP address start at eth frame
  int offsetDest = 30; // Dest IP address start at eth frame
  for(i=0; i<4; i++) {
    srcIPAddrBuffer[i] = ethFrame[offsetSrc + i];
    destIPAddrBuffer[i] = ethFrame[offsetDest + i];
  }
}*/

/*void TCPSegment::setChecksumBuffer() {

  numChecksumBytes = 0;
  // Set source ip in buffer
  int offsetSrc = 26; 
  for(int i=0; i<4;i++) {
    checksumBuffer[i] = ethFrame[offsetSrc + i]; 
     numChecksumBytes++;
  }

  // Set destination ip in buffer
  int offsetDest = 30;
  for(int i=4;i<7;i++) {
    checksumBuffer[i] = ethFrame[offsetDest + i];
     numChecksumBytes++;
  }
  
  // Set reserved
  checksumBuffer[8] = 0;
   numChecksumBytes++;
 
  // Set protocol
  checksumBuffer[9] = 6;
   numChecksumBytes++;

  // Set TCP len
  Bit8u upperPart = (tcpSegLen << 8) & (0x00FF);
  Bit8u lowerPart = tcpSegLen & (0x00FF);
  devFile << "Testing shift TCP Len: " << upperPart * 256 + lowerPart << "\n";
  checksumBuffer[10] = upperPart;
   numChecksumBytes++;
  checksumBuffer[11] = lowerPart;
   numChecksumBytes++;

  int tcpOffset = 34;
  for(int i=0; i<tcpSegLen; i++) {
    checksumBuffer[12+i] = ethFrame[34 + i];
     numChecksumBytes++;
    if (((34 +i) == 50) || ((34 + i) == 51)) { // Set zeros in checkpoint position
      checksumBuffer[12+i] = 0;
    }    
  }*/

/*  if ((tcpSegLen % 2) != 0)  {
    checksumBuffer[numChecksumBytes] = 0;
    padding = true;
 } else {
    padding = false;
  }*/
/*  devFile << "Numbytes buffer checksum: " << numChecksumBytes << "\n";
}*/


/**
 * Compute checksum for TCP segment
 * Reference: http://www.netfor2.com/tcpsum.htm
 */
/*Bit16u TCPSegment::computeChecksum() {

  Bit16u prot_tcp=6;
  Bit16u padd=0;
  Bit16u word16;
  Bit32u sum;
  int i;

        setTCPBuffer();	
        setIPAddrBuffer();*/
 
       // Bit16u *buff = (Bit16u *)tcpBuffer;
	
	// Find out if the length of data is even or odd number. If odd,
	// add a padding byte = 0 at the end of packet
/*	if (padding&1==1){
		padd=1;
		tcpBuffer[tcpSegLen]=0;
	}
	*/
	//initialize sum to zero
//	sum=0;
	
	// make 16 bit words out of every two adjacent 8 bit words and 
	// calculate the sum of all 16 vit words
/*	for (i=0;i<tcpSegLen+padd;i=i+2){
		word16 =((tcpBuffer[i]<<8)&0xFF00)+(tcpBuffer[i+1]&0xFF);
		sum = sum + (unsigned long)word16;
	}	*/
	// add the TCP pseudo header which contains:
	// the IP source and destinationn addresses,
/*	for (i=0;i<4;i=i+2){
		word16 =((srcIPAddrBuffer[i]<<8)&0xFF00)+(srcIPAddrBuffer[i+1]&0xFF);
		sum=sum+word16;	
	}
	for (i=0;i<4;i=i+2){
		word16 =((destIPAddrBuffer[i]<<8)&0xFF00)+(destIPAddrBuffer[i+1]&0xFF);
		sum=sum+word16; 	
	}*/
	// the protocol number and the length of the TCP packet
//	sum = sum + prot_tcp + tcpSegLen;

	// keep only the last 16 bits of the 32 bit calculated sum and add the carries
    /*	while (sum>>16)
		sum = (sum & 0xFFFF)+(sum >> 16);*/
		
	// Take the one's complement of sum
/*	sum = ~sum;

        return ((unsigned short) sum);

}*/

//Bit16u TCPSegment::computeChecksum2() {

    /*     int sum;
         int padd =0;
         Bit16u word16;

        setChecksumBuffer();
        //initialize sum to zero
	sum=0;
	
        // Find out if the length of data is even or odd number. If odd,
	// add a padding byte = 0 at the end of packet
	if (padding&1==1){
		padd=1;
	}

	// make 16 bit words out of every two adjacent 8 bit words and 
	// calculate the sum of all 16 vit words
	for (int i=0;i<numChecksumBytes+padd;i=i+2){
		word16 =((checksumBuffer[i]<<8)&0xFF00)+(checksumBuffer[i+1]&0xFF);
		sum = sum + (unsigned long)word16;
	}	

        // keep only the last 16 bits of the 32 bit calculated sum and add the carries
    	while (sum>>16)
		sum = (sum & 0xFFFF)+(sum >> 16);
		
	// Take the one's complement of sum
	sum = ~sum;

        return ((unsigned short) sum);*/


  
   /* Compute Internet Checksum for "count" bytes
            *         beginning at location "addr".
            */
    //   int count = numChecksumBytes;
      // Bit16u *addr = (Bit16u *) checksumBuffer;
     //  Bit8u *addr2;
       //register long sum = 0;
       /*Bit16u checksum;

        
        register long sum = 0;

        int i = 0;
        while( count > 1 )  {*/
           /*  This is the inner loop */
               //sum += * (unsigned short) addr++;
        /*       sum += (Bit16u) addr[i];
               count -= 2;
               i++;
       }*/

           /*  Add left-over byte, if any */
     //  if( count > 0 )
       //        sum += checksumBuffer[numChecksumBytes-1];

           /*  Fold 32-bit sum to 16 bits */
      /* while (sum>>16)
           sum = (sum & 0xffff) + (sum >> 16);

       checksum = ~sum;
       return checksum;*/

       
       // while( count > 1 )  {
           /*  This is the inner loop */
         //      sum += * (unsigned short) addr;
           //    addr++;
             //  count -= 2;
      // }

           /*  Add left-over byte, if any */
       //if( count > 0 )
               //sum += * (unsigned char *) addr;
         //      addr2 = (Bit8u *) addr;
           //    sum += *(unsigned char *) addr;
           /*  Fold 32-bit sum to 16 bits */
       //while (sum>>16)
         //  sum = (sum & 0xffff) + (sum >> 16);

       //checksum = ~sum;
//       return 10 ;

//}

void  TCPSegment::updateChecksum() {
  unsigned int bytes = 14 + ethFrame[16] * 256 + ethFrame[17];
  devFile << "Calling computeChecksum with nBytes " << bytes << "\n";
  Bit16u cs = computeChecksum(ethFrame, bytes);
  delete checksum;
  checksum = new Word16(cs);
  // write checksum bytes into frame
  ethFrame[50] = checksum->getPart(1);
  ethFrame[51] = checksum->getPart(2);
 
}

Bit16u TCPSegment::computeChecksum(unsigned char *rxbuf, int nbytes)

{

        //devFile << "Inside computeChecksum. nbytes: " << nbytes << "\n"; 
        unsigned char *pseudo_packet;
	Bit32u Sum;
	Bit32u Loop;

	pseudo_packet = (unsigned char *) malloc(12 + nbytes - 34 + (nbytes % 2));
	memset(pseudo_packet, 0, 12 + nbytes - 34 + (nbytes % 2));

	memcpy(pseudo_packet, rxbuf + 26, 8);
	pseudo_packet[9] = rxbuf[23];
	if (pseudo_packet[9] != 0x6) printf("Arrrrgh\n");
	pseudo_packet[10] = (nbytes - 34) >> 8;
	pseudo_packet[11] = (nbytes - 34) & 0xff;
	memcpy(pseudo_packet + 12, rxbuf + 34, nbytes - 34);
	pseudo_packet[28] = 0;
	pseudo_packet[29] = 0;

	Sum = 0;
	for (Loop = 0; Loop < ((12 + nbytes - 34 + (nbytes % 2)) / 2); Loop++)
	{
		Sum += pseudo_packet[Loop * 2] * 256 + pseudo_packet[Loop * 2 + 1];
	}

	Sum = (Sum >> 16) + (Sum & 0xffff);
	Sum = (Sum >> 16) + (Sum & 0xffff);
	Sum = ~Sum & 0xffff;

#if 0
	Sum = (Sum >> 8) + ((Sum & 0xff) << 8);
#endif
	return (Bit16u) Sum;


}
TCPSegment::~TCPSegment() {

}




#endif
