/**
 * Abstraction of a TCP segment  
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 01/22/2007
 * Last update: 
 */
#ifndef __TCP_SEGMENT_H
#define __TCP_SEGMENT_H

//#include "bochs.h"
#include "logical_end_end_transport.h"
#include <iostream>
//#include "config.h"
//#include <list>
//#include <unistd.h>
//#include <set>
using namespace std;

#if BX_LOG_RECOVERY

#define TCP_SEG_SIZE 2048 // enough for a TCP segment
/**
 * Represents a 16-bit word
 */

class Word16 
{
  private:

  protected:
    Bit8u part1, part2;


  public:
    Word16(Bit8u p1, Bit8u p2);
    Word16(Bit16u number);
    bool equal(Word16 *w16);
    Bit8u getPart(Bit8u num);
    void print();
    Bit16u toBit16u();
    ~Word16();

};

/**
 * Represents a 32-bit word
 */
class Word32 
{
  protected:
  Bit8u part1, part2, part3, part4;

  public:
    Word32(Bit8u p1, Bit8u p2, Bit8u p3, Bit8u p4);
    Word32(Bit32u number);
    bool equal(Word32 *w32);
    Bit8u getPart(Bit8u num);
    void print();
    Bit32u toBit32u();
    ~Word32();
};

class TCPSegment
{
  private:
    bool received; // true if packet was received, false otherwise
    Bit8u ipHeaderLength;
    Word16 *ipDatagramLength;
    Word32 *sourceIP;
    Word32 *destinyIP;
    Word16 *portSrc;
    Word16 *portDest;
    Word32 *seqNumber;
    Word32 *ackNumber;
    Bit8u headerLength;
    bool ack;
    bool psh;
    bool rst;
    bool syn;
    bool fin;
    Word16 *checksum;
    unsigned char *ethFrame;
    int ethNBytes;
    Bit16u tcpSegLen; // length of the tcp segment: header + data
   /* // for checksum computation
    Bit8u tcpBuffer[TCP_SEG_SIZE]; 
    bool padding; 
    //int numOctectsTCPSeg;
    Bit8u srcIPAddrBuffer[4];
    Bit8u destIPAddrBuffer[4];
    Bit8u checksumBuffer[TCP_SEG_SIZE];
    int numChecksumBytes; */

    void extractFields();
    void extractHeaderLength(Bit8u byte);
    void extractFlags(Bit8u byte);
    void extractIPHeaderLength(Bit8u byte);
   /* Bit16u computeChecksum();
    void setTCPBuffer();
    void setIPAddrBuffer();
    void setChecksumBuffer();
    Bit16u computeChecksum2();*/
    Bit16u computeChecksum(unsigned char *rxbuf, int nbytes);
  protected:
   
  public:
    TCPSegment(unsigned char *ethF, int nBytes);
    void setReceived(bool value);
    bool getReceived();
    bool getACK();
    bool getRST();
    bool getSYN();
    bool getFIN();
    Word32 *getSrcIP();
    Word32 *getDestIP();
    Word16 *getSrcPort();
    Word16 *getDestPort();
    Word32 *getSequenceNumber();
    Word32 *getACKNumber();
    void setACKNumber(Bit32u number);
    void setSequenceNumber(Bit32u number);

    void updateChecksum();


    void print();
    ~TCPSegment();
   };

#endif

#endif
