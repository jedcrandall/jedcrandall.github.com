/**
 * Log Manager. All log classes inherit from it. This class implements the singleton pattern.
 * Author: Daniela
 * Date: 11/21/2005
 * Last update: 02/09/2007
 */
#ifndef __LOG_MANAGER_H
#define __LOG_MANAGER_H

#include <iostream>
#include <list>
#include <fstream>
#include <string>
#include <unistd.h>

using namespace std;

#include "log_entry.h"

// Log file
#define READ_MODE 0
#define WRITE_MODE 1
#define NUM_LOG_ENTRIES_POOL 1000

// Event types
#define PORT_IO 0
#define INTERRUPT 1
#define HANDLE_INTERRUPT 2
#define NET_PKT 3

class LogManager {

  private:
     static LogManager* instance;
     static int numLogEntries; // To know when we should write a pool of log entries in the log file.
     static void timerInterruptHandler(void *this_ptr);
     Bit64u currentLogEntryId;
     static Bit64u tickLastEvent; // For log mode the tick of the last logged event
                           // For replay mode the tick of the last read event from the log file
     string logFileNameBase;
     pid_t parentPID;
     pid_t childPID;
     char *getLogFileName();
#if BX_LOG_RECOVERY
     static bool semiReplayMode;
#endif
  protected:
     LogManager(); 
     static list<LogEntry*> logEntries;
     static list<LogEntry*> logEntriesSameTick; 
     ifstream *logFileIn; // Stream where data is read from log
     ofstream logFileOut; // Stream where data is written in log
     int timerID; // id of registered timer
     void activateInterruptTimer(Bit64u tickValue);
     void registerInterruptTimer(Bit64u tickValue, void (*func)(void *), 
                                 char *timerName);
     unsigned findNumberElementsToWrite();
     void  writeLogEntries(unsigned numElementsToWrite);
     Bit64u getCurrentLogEntryId();
   
  public:
    static LogManager* Instance();
    void openLogFile(/*char *fileName,*/ int mode);
    void closeLogFile(int mode);
    void init();
    void addLogEntry(LogEntry *logEntry);
    void writeFileLogEntries(); 
    int getTimerID(); 
    void prepareNextInterruptEvent();  
    unsigned readPoolLogEntries(); 
    bool getNextLogEntriesSameTick(); 
    bool checkLogEntriesEmpty();    
    list<LogEntry*> *getListLogEntriesSameTick();
   // LogEntry *LogManager::getCurrentLogEntry();
    LogEntry *getCurrentLogEntry();
    static Bit64u getTickLastEvent(); 
    void setParentPID(pid_t value);
    void setChildPID(pid_t value);
    static void setLogMode(int value);
    static bool isLogMode();
    static void setReplayMode(int value);
    static bool isReplayMode();
    static void startLogSession();
    static void finishLogSession();
    static void startReplaySession(); 
    static void finishReplaySession();
#if BX_LOG_RECOVERY
    static void setSemiReplayMode(bool value);
    static bool isSemiReplayMode();
#endif
   ~LogManager();
};

#endif

