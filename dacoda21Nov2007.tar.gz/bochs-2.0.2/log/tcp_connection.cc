/**
 * TCP Connection
 * Represents a TCP connection
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 01/23/2007
 * Last update: 03/05/2007 
 */
#if BX_LOG_REPLAY && BX_LOG_RECOVERY


#include "tcp_connection.h"
//#include "tcp_segment.h"

//#include "bochs.h"
//#include <signal.h>
#include <fstream>
//using namespace std;

// just for debug
extern ofstream devFile;


/**
 * Constructor
 */
TCPConnection::TCPConnection(Word32 *sIP, Word32 *dIP, Word16 *sPort, Word16 *dPort) 
{
  cout << "TCPConnection created.\n";
  srcIP = sIP->toBit32u();
  destIP = dIP->toBit32u();
  srcPort = sPort->toBit16u();
  destPort = dPort->toBit16u();
 } 

Bit32u TCPConnection::getSrcIP() {
  return srcIP;
}
    
Bit32u TCPConnection::getDestIP() {
  return destIP;
}
    
Bit16u TCPConnection::getSrcPort() {
  return srcPort;
}
    
Bit16u TCPConnection::getDestPort() {
  return destPort;
}

void TCPConnection::setState(int value) {
  state = value;
}
    
int TCPConnection::getState() {
  return state;
}

void TCPConnection::setClientInitiated(bool value) {
  clientInitiated = value;
}

void TCPConnection::print()
{
  devFile << "Connection between :" << srcIP << " to/from " << destIP << " ports: " << srcPort <<
  " " << destPort << "\n";
}
/**
 * Set the initial sequence number of client: entity communicating with recovery-enabled server
 */
void TCPConnection::setClientISN(Bit32u number) {

  clientISN = number;
}

void TCPConnection::setOldServerISN(Bit32u number) {

  oldServerISN = number;

}

Bit32u TCPConnection::getOldServerISN() {
  return oldServerISN;
}

    
void  TCPConnection::setNewServerISN(Bit32u number) {

  newServerISN =  number;
}

Bit32u TCPConnection::getNewServerISN() {
  return newServerISN;
}

/**
 * Translation offset
 */
void  TCPConnection::computeOffset() {
  
  if (oldServerISN > newServerISN) {
    offset = oldServerISN - newServerISN;
  }
  else if (oldServerISN < newServerISN) {
    offset = newServerISN - oldServerISN;
  }
  else {
    offset = 0;
  }
}

Bit32u TCPConnection::getOffset() {
  return offset;
}

bool TCPConnection::equal(Word32 *sIP, Word32 *dIP, Word16 *sPort, Word16 *dPort) {

  if ( ((sIP->toBit32u() == srcIP) && (dIP->toBit32u() == destIP) &&
       (sPort->toBit16u() == srcPort) && (dPort->toBit16u() == destPort)) ||
         ((sIP->toBit32u() == destIP) && (dIP->toBit32u() == srcIP) &&
       (sPort->toBit16u() == destPort) && (dPort->toBit16u() == srcPort))  ) {
    return true;
  }
  else {
    return false;
  }
}

bool TCPConnection::equal(TCPConnection *conn) {

  if ( ((conn->getSrcIP() == srcIP) && (conn->getDestIP() == destIP) &&
       (conn->getSrcPort() == srcPort) && (conn->getDestPort() == destPort)) ||
         ((conn->getSrcIP() == destIP) && (conn->getDestIP()  == srcIP) &&
       (conn->getSrcPort() == destPort) && ( conn->getDestPort() == srcPort))  ) {
    return true;
  }
  else {
    return false;
  }

  
}

TCPConnection::~TCPConnection() {

}




#endif
