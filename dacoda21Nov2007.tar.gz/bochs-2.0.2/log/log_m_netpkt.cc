/* Log manager for the treatment of a packet arrival event
 *
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 04/24/2006
 * Last update: 03/05/2006 
 */
#include "config.h"

#if BX_LOG_REPLAY

#include "log_m_netpkt.h"
#include "log_e_netpkt.h"

extern ofstream devFile; 
extern int replayMode;

LogMNetPkt* LogMNetPkt::instance = 0;


LogMNetPkt::LogMNetPkt()
{
   printf("LogMNetPkt constructor\n");
}

/**
 * Create a singleton instance of this class.
 */
LogMNetPkt* LogMNetPkt::Instance()
{
  if (instance == 0) {
    instance = new LogMNetPkt();
  }
  return instance;
}

/**
 * Handle a packet arrival event event 
 */
void LogMNetPkt::timerHandler()
{
#if BX_NE2K_SUPPORT
#if BX_LOG_RECOVERY
    if (LogManager::isSemiReplayMode()) {
      cout << "Processing network packet pacote during semi-replay mode \n";
    }
#endif
    //devFile << "LogMNetPkt::timerHandler. Tick: " << bx_pc_system.time_ticks() << "\n";
    bx_ne2k_c *theNE2K =  (bx_ne2k_c*) bx_devices.pluginNE2kDevice;
    eth_rx_handler_t receiveCallback = theNE2K->getRxCallback();
    LogENetPkt *logEntry = (LogENetPkt*) LogManager::Instance()->getCurrentLogEntry();
    (*receiveCallback)(((void*)theNE2K), logEntry->getBuffer(), logEntry->getBufferLen());
   /* if (replayMode) {
      LogManager::Instance()->prepareNextInterruptEvent();
    }*/
#else
    cout << "LogMNetPkt::timerHandler(): BX_NE2K is not supported. This method shouldn't have been called\n";
    exit(1);
#endif
}

/**
 * Read the current line of the file passed as a parameter and with this data 
 * creates and returns an object LogENetPkt. This method is used
 * inside LogManager::readPoolLogEntries when it is detected that the current
 * line of the log file represents the event of a packet arrival.
 */
LogENetPkt *LogMNetPkt::readLoggedNetPkt(ifstream *logIn)
{
  LogENetPkt *logN;
  Bit16u bufferLen;
  Bit8u rxBuffer[PKT_SIZE];
  Bit8u byte;
                        
  logN = new LogENetPkt();
  (*logIn).read((char *) &bufferLen, sizeof(unsigned));  
  logN->setBufferLen(bufferLen);
  //cout << "Packet: ";
  //for(int i=0; i<bufferLen; i++) { // Do this efficiently later, for DACODA use
    //(*logIn) >> byte;
    (*logIn).read((char *) /*&byte*/ rxBuffer, (bufferLen * sizeof(Bit8u)));  
    //devFile << byte << " ";
    //rxBuffer[i] = (unsigned char) byte;
  //}
  //cout << "\n";
  logN->setBuffer(rxBuffer);
  return logN;
}


/**
 * Write the LogENetPkt passed as a parameter in the log file 
 * also passed as a parameter
 */
void LogMNetPkt::writeLogEntry(LogENetPkt *logEntry, ofstream *logFile)
{
   unsigned bufferLen = logEntry->getBufferLen();
   unsigned char *buffer = logEntry->getBuffer();

  // (*logFile) << logEntry->getTick() << " ";
  // (*logFile) << bufferLen << " ";
   (*logFile).write((char*) &bufferLen, sizeof(unsigned));


  // for(int i=0; i< bufferLen; i++) {
    // (*logFile) << (unsigned) buffer[i] << " "; 
    (*logFile).write((char*) /*&buffer[i]*/ buffer, (bufferLen * sizeof(Bit8u)));

  // }
}


LogMNetPkt::~LogMNetPkt()
{
   //printf("LogMNetPkt destructor\n");
}

#endif
