/* Log manager for in port events. This class implements the singleton pattern.
 * Author: Daniela
 * Date: 11/23/2005
 * Last update: 11/14/2006
 */
#ifndef __LOG_M_INPORT_H
#define __LOG_M_INPORT_H

#include <iostream>
#include <set>
using namespace std;

#include "log_manager.h"
#include "log_e_inport.h"


class LogMInPort : public LogManager
{
  private:
    static LogMInPort* instance;

  protected:
     static set<Bit16u> nonLoggedInPorts;
     static set<Bit16u> hdInPorts;
#if BX_LOG_RECOVERY
     static set<Bit16u> ne2kPorts;
#endif
     LogMInPort();

  public:
    static LogMInPort* Instance();
    static LogEInPort *readLoggedPortIO(ifstream *logIn);
    static void writeLogEntry(LogEInPort *logEntry, ofstream *logFile);
    static void readPortData(); 
    static void readInPortData(LogEInPort * logEntry);
    static void testReadPortAllowed(Bit16u portAddr, unsigned numBytes);
    static void updateRegisterWithMemAddr(unsigned inout, unsigned numBytes, 
                                   unsigned numBitsRegWithMemAddr);
    static void writeDataInMem(unsigned numBytes, bx_address addr, Bit32u bytes, 
            Bit8u integrity, Bit16u portAddr, unsigned numBitsRegWithMemAddr);
    static void writeDataInRegister(unsigned numBytes, Bit32u bytes, 
    Bit16u portAddr, unsigned numBitsRegWithMemAddr);
    static bool isInNonLoggedInPortsSet(Bit16u portAddr);
    static void insertNonLoggedInPort(Bit16u addr);
    static bool isInHDInPortsSet(Bit16u portAddr);
    static void insertHDInPort(Bit16u addr);
#if BX_LOG_RECOVERY
    static bool isInNe2kPortsSet(Bit16u portAddr);
    static void insertNe2kPort(Bit16u addr);
#endif
    ~LogMInPort();
};
#endif
