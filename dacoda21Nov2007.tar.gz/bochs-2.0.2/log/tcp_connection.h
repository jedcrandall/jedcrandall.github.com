/**
 * TCP Connection
 * Represents a TCP connection
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 01/22/2007
 * Last update: 
 */
#ifndef __TCP_CONNECTION_H
#define __TCP_CONNECTION_H

//#include "bochs.h"
#include "tcp_segment.h"
#include <iostream>
//#include "config.h"
//#include <list>
//#include <unistd.h>
//#include <set>
using namespace std;

#if BX_LOG_RECOVERY

#define SYN_SENT 0
#define SYN_ACK 1
#define ESTABLISHED 2
#define CLOSE_WAIT 3
#define LAST_ACK 4
#define FIN_WAIT 5
//#define FIN_WAIT2 6
#define TIME_WAIT 6
#define CLOSED 7

class TCPConnection
{
  private:

    Bit32u srcIP;
    Bit32u destIP;
    Bit16u srcPort;
    Bit16u destPort;
    bool clientInitiated; // if connection was initiated by client, The server is recovery-enabled.
    Bit32u clientISN;
    Bit32u oldServerISN;
    Bit32u newServerISN;
    Bit32u offset;
    int state;
        
  protected:
   
  public:
    TCPConnection(Word32 *sIP, Word32 *dIP, Word16 *sPort, Word16 *dPort);
    Bit32u getSrcIP();
    Bit32u getDestIP();
    Bit16u getSrcPort();
    Bit16u getDestPort();
    void setState(int value);
    int getState();
    void setClientInitiated(bool value);
    void setClientISN(Bit32u number);
   // Bit32u getClientISN();
    void setOldServerISN(Bit32u number);
    Bit32u getOldServerISN();
    void setNewServerISN(Bit32u number);
    Bit32u getNewServerISN();
    void computeOffset();
    Bit32u getOffset();
    bool equal(Word32 *sIP, Word32 *dIP, Word16 *sPort, Word16 *dPort);
    bool equal(TCPConnection *conn);
    void print();
    ~TCPConnection();
   };

#endif

#endif
