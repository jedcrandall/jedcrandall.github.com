/**
 * Log Manager. All log classes inherit from it
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 11/21/2005
 * Last update: 03/05/2006
 */
#include "config.h"

#if BX_LOG_REPLAY

#include "log_manager.h"
#include "bochs.h"
#include <functional>
#include <algorithm>
#include <vector>
#include <list>
#include <sys/time.h>
using namespace std;

int logMode = 0;
int replayMode = 0;

extern int GLOBALSexecMode;

/**
 * Static members
 */
list<LogEntry*> LogManager::logEntries;
list<LogEntry*> LogManager::logEntriesSameTick; 

LogManager* LogManager::instance = 0;
int LogManager::numLogEntries = 0;
Bit64u LogManager::tickLastEvent = 0;
#if BX_LOG_RECOVERY
bool LogManager::semiReplayMode = false;
#endif
// just for debug
extern ofstream devFile;
extern ofstream inteFile;

/**
 * Constructor
 */
LogManager::LogManager() 
{
  printf("Log Manager created.\n");
} 

/**
 * Creates a singleton instance of this class.
 */
LogManager* LogManager::Instance()
{
  if (instance == 0) {
    instance = new LogManager();
    instance->logFileNameBase = "log/logs/logentries";
    instance->setParentPID(getpid());

  }
  return instance;
}


void LogManager::init()
{
  printf("LogManager::init\n");
  tickLastEvent = bx_pc_system.time_ticks();
  if (logMode) {
     openLogFile(WRITE_MODE);
  }
  else if (replayMode) {
    openLogFile(READ_MODE);
    readPoolLogEntries();
    if(!getNextLogEntriesSameTick()) return;
    LogEntry *firstEntry = (LogEntry*)logEntriesSameTick.front();
    if (firstEntry != NULL) {
      Bit64u timeToFireEvent = firstEntry->getTick() - bx_pc_system.time_ticks();
      registerInterruptTimer(timeToFireEvent, this->timerInterruptHandler,
                             "timerLogManager");
     cout << "Tick first entry: " << firstEntry->getTick() << " Tick now: " << bx_pc_system.time_ticks() << "\n";
    }
    else {
      cout << "LogManager::init(): firstEntry is NULL." << "\n";
      exit(1);
    }
  }
  else {
    cout << "LogManager::init: error - logMode or replayMode must be on."; 
  }
}

/**
 * Open log file to be written to or read from
 */ 
void LogManager::openLogFile(int mode)
{

  char *fileName = getLogFileName();
 
#include <unistd.h>
  if (mode == READ_MODE) {
      ifstream *inStream = new ifstream();
      inStream->open(fileName, ios::in | ios::binary); 
      if(!(*inStream)) 
      {
        printf("Error: File %s could not be opened.\n", fileName);
        exit(1);
      }
    logFileIn = inStream; 
  }
  else if (mode == WRITE_MODE) {
    logFileOut.open(fileName, ios::out | ios::binary);
    if(!logFileOut) 
    {
      printf("Error: File %s could not be open.\n", fileName);
      exit(1);
    }
  }
  else {
    printf("Error: wrong mode to open a file\n");
    exit(1);
  }
 
}

void LogManager::closeLogFile(int mode)
{

  if (mode == READ_MODE) {
    logFileIn->close();

  }
  else if (mode == WRITE_MODE) {
    logFileOut.close();
  }
  else {
    printf("Error: wrong mode to open a file\n");
    exit(1);
  }
}

/**
 * Read up to NUM_LOG_ENTRIES_POOL log entries from the log file and insert them in
 * the list of log entries. Return the number of log entries successfully read.
 */
unsigned LogManager::readPoolLogEntries()
{
  Bit64u idNumber;
  Bit8u eventType;
  int numEntriesRead = 0;
  Bit32u tickLogged;
                     
  //cout << "LogManager::readPoolLogEntries: \n";             
  if (!logEntries.empty()) {
    cout << "LogManager::readPoolLogEntries(): logEntries is not empty." << "\n";
    exit(1);
  }         
  logEntries.clear();
                                               
  // Read log entries from file and insert them in the logEntries list
  while ((!logFileIn->eof()) && numEntriesRead < NUM_LOG_ENTRIES_POOL) {
    logFileIn->read((char *) &eventType, sizeof(Bit8u));  

    //devFile << (unsigned) eventType << " ";
   // cout << "Event type: " << eventType << "unsigned: " << (unsigned) eventType << " ";
    if(logFileIn->eof()) {
      logFileIn->close();
      break;
    }   
    logFileIn->read((char *) &tickLogged, sizeof(Bit32u));  
    //devFile << tickLogged << " ";
    //cout << "ticklogged: " << tickLogged << " ";

    switch (eventType) {
      case PORT_IO:
       // cout << "event port/io\n";
        LogEInPort *logP;
        logP =  LogMInPort::readLoggedPortIO(logFileIn);
        logP->setIdNumber(idNumber);
        logP->setTick(tickLastEvent + tickLogged);
        logEntries.push_back(logP);
        break;

      case INTERRUPT:
       // cout << "event interrupt\n";
        LogEInterrupt *logI; 
        logI = LogMInterrupt::readLoggedInterrupt(logFileIn);
        logI->setIdNumber(idNumber);
        logI->setTick(tickLastEvent + tickLogged);
        logEntries.push_back(logI);
        break;

       case HANDLE_INTERRUPT:
        //cout << "event handle interrupt\n";
        LogEHandleInterrupt *logH; 
        logH =  new LogEHandleInterrupt(); //logmhandleinterrupt::readloggedhandleinterrupt(&logfilein);
        logH->setIdNumber(idNumber);
        logH->setTick(tickLastEvent + tickLogged);
        logEntries.push_back(logH);
       // devFile << endl;
        //cout << "\n";
        break;

     
      case NET_PKT:
        //cout << "event netpkt\n";
        LogENetPkt *logN; 
        logN = LogMNetPkt::readLoggedNetPkt(logFileIn);
        logN->setIdNumber(idNumber);
        logN->setTick(tickLastEvent + tickLogged);
        logEntries.push_back(logN);
        //devFile << "\n";
        break;

      default:
        cout << "LogManager::readPoolLogEntries: wrong event type: " << eventType <<  "\n";
        exit(1);
    }
    tickLastEvent+= tickLogged;
    numEntriesRead++;
  
  }

  return numEntriesRead;

}

/**
 * Builds a separate list of one or more log entries where all of them have the same tick. Returns true if
 * it could build a list of at least on log entry and false otherwise. Returning false means
 * that all log entries were read from the log file and consumed.
 */
bool LogManager::getNextLogEntriesSameTick() 
{
  //if (semiReplayMode)cout << "LogManager: Inside getNextLogEntriesSameTick()\n";
  
  // This method is supposed to be called only when the list of log entries
  // with same tick is empty.
  if (!logEntriesSameTick.empty()) {
    cout << "LogManager::getNextLogEntriesSameTick: logEntriesSameTick is not empty!" << "\n";
    exit(1); 
  }
  logEntriesSameTick.clear();

  // This means that all log entries were read and consumed from log file.
  if (!checkLogEntriesEmpty())  {
#if BX_LOG_RECOVERY
    if (isSemiReplayMode()) {
      /*cout << "Ending semi-replay mode at tick " << bx_pc_system.time_ticks() << "\n";
      setSemiReplayMode(false);*/
      RecoveryManager::finishSemiReplayPhase();
    } else
#endif
    if (isReplayMode()) {
      finishReplaySession();
    }
    return false;
  }

  LogEntry *logE = (LogEntry*) logEntries.front();
  logEntries.pop_front();
  logEntriesSameTick.push_back(logE);
  Bit64u tick = logE->getTick();
  
  // See if subsequent log entries have same tick and if so, insert them in list.
  if (checkLogEntriesEmpty()) {
    logE = (LogEntry*) logEntries.front();
    //cout << "Pegou a proxima log entry para ver se tem o mesmo tick: Tick: " << logE->getTick() << "\n";
    while (logE->getTick() == tick) {
      logEntries.pop_front();
      logEntriesSameTick.push_back(logE);
      if (checkLogEntriesEmpty()) {
        logE = (LogEntry*) logEntries.front();
      }
      else break; 
    }
  }
  //cout << "LogMInPort: Inside getNextLogEntriesSameTick() retornando true.\n";
  return true;

}

/**
 * Check if the list of log entries became empty. If it is empty, it tries to read a pool 
 * of new log entries from log file. In this case the method returns true. If all the entries
 * from the file were consumed, it returns false;
 */
bool LogManager::checkLogEntriesEmpty() 
{

  //if (semiReplayMode) cout << "Inside checkLogEntriesEmpty\n";  
  if (logEntries.empty()) {
    unsigned numEntriesRead = readPoolLogEntries();
    if (numEntriesRead == 0)  {
/*#if BX_LOGREPLAY_OVERHEAD
    double elapsed = getElapsedTime();
    printf("Elapsed time: %f seconds.\n", elapsed);
#endif*/
      return false;
    }
  }
  return true;
}



/**
 * Returns the current list of log entries with same tick. This is necessary in method
 * timerInterruptHandler which is static.
 */
list<LogEntry*> *LogManager::getListLogEntriesSameTick() 
{
  return &logEntriesSameTick;
}

/**
 * This method is called whenever we have an event to be triggered.
 */
void LogManager::timerInterruptHandler(void *this_ptr)
{
 
  list<LogEntry*> *listLogEntries = LogManager::Instance()->getListLogEntriesSameTick();
   
  int listSize = listLogEntries->size();
  
  // Make a copy list of log entries same tick because the original will be changed/updated by
  // others methods while executing this method
  LogEntry *log;
  list<LogEntry*> listCopy;
  list<LogEntry*>::iterator it = listLogEntries->begin();
 

  for (int i=0; i < listSize; i++) {
    log = *it;
    if (typeid(*log) == typeid(LogEInterrupt)) {
      listCopy.push_back(new LogEInterrupt((LogEInterrupt*)log));
    }
    else if (typeid(*log) == typeid(LogEHandleInterrupt)) {
      listCopy.push_back(new LogEHandleInterrupt((LogEHandleInterrupt*)log));
    }
    else if (typeid(*log) == typeid(LogEInPort)) {
      listCopy.push_back(new LogEInPort((LogEInPort*)log));
    }
    else if (typeid(*log) == typeid(LogENetPkt)) {
      listCopy.push_back(new LogENetPkt((LogENetPkt*)log));
    }
    else {
      cout << "LogManager::timerInterruptHandler at " << bx_pc_system.time_ticks() << 
      " : wrong typeid for log: " << typeid(*log).name() << "\n";
      exit(1);
    }
    it++;
  }

  
  // Now process each log entry in the copied list
  LogEntry *logEntryCopy;
  list<LogEntry*>::iterator it2 = listCopy.begin();

  for (int i=0; i< listSize; i++) {
    logEntryCopy =  *it2;

    if (typeid(*logEntryCopy) == typeid(LogEInPort)) {
       /* if (semiReplayMode)
        devFile << "Tipo do evento inport. \n";*/
      LogMInPort::readPortData();
     // LogManager::Instance()->prepareNextInterruptEvent();
    }
    else if (typeid(*logEntryCopy) == typeid(LogEInterrupt)) {
       /* if (semiReplayMode) {
          devFile << "Tipo do evento interrupt. \n";
        }*/
      LogMInterrupt::timerHandler((LogEInterrupt*) logEntryCopy); 
    }
    else if (typeid(*logEntryCopy) == typeid(LogEHandleInterrupt)) {
        /*if (semiReplayMode) {
          devFile << "Tipo do evento handle interrupt. \n";
        }*/
      LogMHandleInterrupt::timerHandler(); 
    }
    else if (typeid(*logEntryCopy) == typeid(LogENetPkt)) {
       /* if (semiReplayMode) {
          devFile << "Tipo do evento net pkt. \n";
        }*/
      LogMNetPkt::timerHandler(); 
    }
    else {
      cout << "LogManager::timerInterruptHandler: wrong typeid for logEntryCopy: " <<
      typeid(*logEntryCopy).name() << "\n";
      exit(1);
    }
#if BX_LOG_RECOVERY
    if (replayMode || semiReplayMode) //{
      //if (semiReplayMode) cout << "prepareNextInterruptEvent\n";
#endif
      LogManager::Instance()->prepareNextInterruptEvent();
  //  }
    it2++;
  }

   // Delete copied list to save space
  for (int i=0; i< listSize; i++) {  
    logEntryCopy = listCopy.front();
    listCopy.pop_front();
    delete logEntryCopy;
  }
}


void LogManager::prepareNextInterruptEvent()
{
  //if (semiReplayMode) cout << "Inside prepareNextInterruptEvent\n"; 
  if (logEntriesSameTick.empty()) {
     if(!getNextLogEntriesSameTick()) {
       //if (semiReplayMode) cout << "Returning without doing anything because !getNextLogEntriesSameTick() \n"; 
       return;
     }
    LogEntry *firstEntry = (LogEntry*) logEntriesSameTick.front();
    if ( firstEntry != NULL ) {
       Bit64u timeToFireEvent = firstEntry->getTick() - bx_pc_system.time_ticks();
       activateInterruptTimer(timeToFireEvent);
    }
    else {
      cout << "LogMInterrupt::prepareNextInterruptEvent(): firstEntry is NULL." << "\n";
      exit(1);
    }
  }
 }


int  LogManager::getTimerID()
{
  return timerID;
}

/**
 * Register the event timer with the Bochs system. This timer will take care of firing
 * all logged events at the appropriate time.
 */
void LogManager::registerInterruptTimer(Bit64u tickValue, 
                                          void (*func)(void *), char* timerName)
{
  int continuous = 0;
  int active = 1;
  timerID = bx_pc_system.register_timer_ticks(this, func, tickValue, 
  continuous, active, timerName); 
}

/**
 * Activate the event timer with the Bochs system.
 */
void LogManager::activateInterruptTimer(Bit64u tickValue)
{
  int continuous = 0;
  bx_pc_system.activate_timer_ticks(getTimerID(), tickValue, continuous);
}

/**
 * Add a new log entry in the list of log entries. If the current
 * number of log entries in the list is over NUM_LOG_ENTRIES_POOL,
 * the list is written in the log file. This is done to save memory.
 */
void LogManager::addLogEntry(LogEntry *logEntry)
{
  //cout << "add log entry. Id Number: " << logEntry->getIdNumber() << "\n";
  if (numLogEntries >= NUM_LOG_ENTRIES_POOL) {
    logEntries.sort(LogEntrySortCriterion());
    unsigned numberElementsToWrite = findNumberElementsToWrite();
    writeLogEntries(numberElementsToWrite);
    numLogEntries = logEntries.size();
  }
  numLogEntries++;
  logEntries.push_back(logEntry);
}

/**
 * Write all log entries from the list of log entries in
 * the file log.
 */
void LogManager::writeLogEntries(unsigned numElementsToWrite)
{
  LogEntry *logEntry;
//  int num = 0;
  Bit32u tickLogged;
  Bit8u eventType;
  
  //cout << "Inside writeLogEntries\n";
 
  // Read log entries from list and write them in the log file
  list<LogEntry*>::iterator it = logEntries.begin();
  for(int i=0; i< numElementsToWrite; i++) {
    logEntry = *it;
    tickLogged = (Bit32u)(logEntry->getTick() - tickLastEvent);
    //devFile << "Tick: " << logEntry->getTick() << " Tick logged: " << tickLogged << 
    //" Tick last event: " << tickLastEvent << "\n";

    if (typeid(*logEntry) == typeid(LogEInterrupt)) {
      eventType = (Bit8u) INTERRUPT;
     // devFile << (unsigned) eventType << " ";
      logFileOut.write((char *) &eventType, sizeof(Bit8u));
      logFileOut.write((char *) &tickLogged, sizeof(Bit32u));
      //devFile << logEntry->getTick() << " ";
      //devFile << tickLogged << " ";
      LogMInterrupt::writeLogEntry((LogEInterrupt*) logEntry, &logFileOut);
    }
    else if (typeid(*logEntry) == typeid(LogEHandleInterrupt)) {
      eventType = (Bit8u) HANDLE_INTERRUPT;
      //devFile << (unsigned) eventType << " ";
      logFileOut.write((char *) &eventType, sizeof(Bit8u));
      logFileOut.write((char *) &tickLogged, sizeof(Bit32u));  
      //devFile << logEntry->getTick() << " ";
      //devFile << tickLogged << " ";  
    }
    else if (typeid(*logEntry) == typeid(LogEInPort)) {
      eventType = (Bit8u) PORT_IO;
      //devFile << (unsigned)eventType << " ";
      logFileOut.write((char *) &eventType, sizeof(Bit8u));
      logFileOut.write((char *) &tickLogged, sizeof(Bit32u));
      //devFile << logEntry->getTick() << " ";
      //devFile << tickLogged << " ";
      LogMInPort::writeLogEntry((LogEInPort*) logEntry, &logFileOut);
    }
    else if (typeid(*logEntry) == typeid(LogENetPkt)) {
      eventType = (Bit8u) NET_PKT;
      //devFile << (unsigned) eventType << " ";
      logFileOut.write((char *) &eventType, sizeof(Bit8u));
      logFileOut.write((char *) &tickLogged, sizeof(Bit32u));
      //devFile << logEntry->getTick() << " ";
      //devFile << tickLogged << " ";
      LogMNetPkt::writeLogEntry((LogENetPkt*) logEntry, &logFileOut);
    }
    else {
      cout << "LogManager::writeLogEntries: wrong typeid: " << typeid(*logEntry).name() << "\n";
      exit(1);
    }
    //delete logEntry;
    it++; // points to next log entry in list
    logEntries.pop_front();
    tickLastEvent = logEntry->getTick();
    //devFile << tickLastEvent << "\n";
    delete logEntry;
  }
}


/**
 * Get the current log entry from the list of log entries, remove it from
 * the list and return it.
 */
LogEntry *LogManager::getCurrentLogEntry()
{
   LogEntry *logE = logEntriesSameTick.front();
   //currentLogEntryId = logE->getIdNumber();
   logEntriesSameTick.pop_front();
   return logE;
}

/**
 * Find the number of elements to write on the log file at this time.
 */
unsigned LogManager::findNumberElementsToWrite()
{
 
  unsigned safePoint = logEntries.size();

  list<LogEntry*>::iterator it = logEntries.end();
  it--;
  LogEntry *logEntry1, *logEntry2;
  
  logEntry2 = *it;
  it--;
  logEntry1 = *it;
  if ((logEntry2->getIdNumber() - logEntry1->getIdNumber()) == 1) return  NUM_LOG_ENTRIES_POOL;
  else return (NUM_LOG_ENTRIES_POOL -1);
  
}

/**
 * Called from external methods to flush the list of log entries to the logFile
 * before finalizing the logging of a system window of execution.
 */
void LogManager::writeFileLogEntries()
{
  logEntries.sort(LogEntrySortCriterion());
  writeLogEntries(logEntries.size());
  closeLogFile(WRITE_MODE);
}

/**
 * This is necessary when we need to switch
 * from replay mode to log mode in one run
 */
Bit64u LogManager::getCurrentLogEntryId() {
  return currentLogEntryId;
}                                                                            

Bit64u LogManager::getTickLastEvent()
{
  return tickLastEvent;
} 

/**
 * The parent process is always in charge of replaying
 */
void LogManager::setParentPID(pid_t value) 
{
  parentPID = value;
}
    
/**
 * The child process is always in charge of logging
 */
void LogManager::setChildPID(pid_t value)
{
  childPID = value;
}


/**
 * Return the name of the log file where log entries will be written to/read from
 */ 
char *LogManager::getLogFileName()
{
  if (childPID != 0) {
    static char pidBuffer[16];
    snprintf(pidBuffer,sizeof(pidBuffer),"%d",childPID);
    string fileName(logFileNameBase + '.' + pidBuffer);
    return (char *) fileName.c_str();
  }
  else {
    return (char *) logFileNameBase.c_str();
  } 
}

/**
 * These set of functions are getters and setters for ExecRecorder 2 modes: log and replay
 */
void LogManager::setLogMode(int value) {
  logMode = value;
}

bool LogManager::isLogMode() {
  if (logMode == 1) {
    return true;
  }
  else if (logMode == 0) {
    return false;
  }
}

void LogManager::setReplayMode(int value) {
  replayMode = value;
}

bool LogManager::isReplayMode() {
  if (replayMode == 1) {
    return true;
  }
  else if (replayMode == 0) {
    return false;
  }
}

/**
 * Start logging system execution
 */
void LogManager::startLogSession() {
  if (isReplayMode()) {
    cout << "Logging session cannot be initiated in replay mode\n";
    exit(1);
  }
  setLogMode(1);
  Instance()->init();
  cout << "LOG enabled at tick " << bx_pc_system.time_ticks() << "\n";
}
    
/**
 * Ends a logging session
 */
void LogManager::finishLogSession() {
  setLogMode(0);
  Instance()->writeFileLogEntries();
  cout << "LOG disabled at tick " <<  bx_pc_system.time_ticks() << ". Log entries were successfully written.\n";

#if BX_LOG_RECOVERY
// for usenix
  RecoveryManager::printClientStat();
#endif
}
    
/**
 * Starts a replay session. 
 */
void LogManager::startReplaySession() {
  if (isLogMode() == 1) {
    cout << "Replay session cannot be initiated in log mode\n";
    exit(1);
  }
  setReplayMode(1);
  Instance()->init();
  cout << "REPLAY enabled at tick " << bx_pc_system.time_ticks() << "\n";
} 

/**
 *  Ends a replay session
 */
void LogManager::finishReplaySession() {

   cout << "LogManager: Ending replay session at tick " 
    << bx_pc_system.time_ticks() << "\n";
    replayMode = 0;
    //LogEntry::setIdNumberGenerator(currentLogEntryId + 1);
#if BX_LOG_RECOVERY
  if (!RecoveryManager::isRecovering()) 
#endif
    Instance()->closeLogFile(READ_MODE);

   // BX_CPU_THIS_PTR panic("Replay has finished\n");
#if BX_LOG_RECOVERY
      cout << "Continuing execution in normal mode.\n";
      if (RecoveryManager::isRecovering()) {
          devFile << "Starting semi-replay session at tick: " << 
bx_pc_system.time_ticks() << "\n";
          RecoveryManager::startSemiReplayPhase();
      }
#endif
}

#if BX_LOG_RECOVERY
void LogManager::setSemiReplayMode(bool value) {
  
  semiReplayMode = value;
}

bool LogManager::isSemiReplayMode() {

 return semiReplayMode;
}
#endif
LogManager::~LogManager()
{
  //printf("LogManager destructor.\n");
}

#endif

