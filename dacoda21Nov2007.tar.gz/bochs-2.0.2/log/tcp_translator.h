/**
 * TCP Translator
 * Translates TCP sequence numbers, ack numbers and checksum
 * for recovery process 
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 01/22/2007
 * Last update: 
 */
#ifndef __TCP_TRANSLATOR_H
#define __TCP_TRANSLATOR_H

#include "bochs.h"
//#include "tcp_segment.h"
#include "tcp_connection.h"
#include <iostream>
#include "config.h"
#include <list>
//#include <unistd.h>
//#include <set>
using namespace std;

#if BX_LOG_RECOVERY

class TCPTranslator
{
  private:
    static TCPTranslator* instance;
    list<TCPConnection*> connections;
    TCPTranslator();
    void processTCPSegmentReceived(TCPSegment *tcpSeg);
    void processTCPSegmentSent(TCPSegment *tcpSeg);
    void processSYNReceived(TCPSegment *tcpSeg);
    void processSYNACKReceived(TCPSegment *tcpSeg);
    void processACKReceived(TCPSegment *tcpSeg);
    void processFINReceived(TCPSegment *tcpSeg);

    void processRSTReceived(TCPSegment *tcpSeg);
    void processSYNSent(TCPSegment *tcpSeg);
    void processSYNACKSent(TCPSegment *tcpSeg);
    void processACKSent(TCPSegment *tcpSeg);
    void processFINSent(TCPSegment *tcpSeg);
    void processRSTSent(TCPSegment *tcpSeg);
 

    void addConnection(TCPConnection *connection);
    void removeConnection(TCPConnection *connection);
    TCPConnection *findConnection(TCPSegment *tcpSeg);  
    void translateReceived(TCPSegment *tcpSeg, TCPConnection *connection);
    void translateSent(TCPSegment *tcpSeg, TCPConnection *connection);
 

    

  protected:
   
  public:
    static TCPTranslator* Instance();
    void processTCPSegment(TCPSegment *tcpSeg);
    bool hasActiveConnections();
    ~TCPTranslator();
   };

#endif

#endif
