/**
 * Log entry for the arrival of a network packet.
 *
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 04/24/2005
 * Last update: 10/30/2006 
 */
#ifndef __LOG_E_NETPKT_H
#define __LOG_E_NETPKT_H

#define PKT_SIZE 2048 // enough for an ethernet frame

#include <iostream>
using namespace std;

#include "log_entry.h"

class LogENetPkt : public LogEntry
{
  protected:
    unsigned bufferLen; // number of bytes in packet
    Bit8u buffer[PKT_SIZE]; // buffer with network packet
    //bool sent; // true if pkt was sent, false if received


  public:
    LogENetPkt();
    LogENetPkt(LogENetPkt *logEntry);
    void setBufferLen(unsigned value);
    unsigned getBufferLen();     
    void setBuffer(unsigned char *buf);
    unsigned char *getBuffer();
    ~LogENetPkt();
};
#endif
