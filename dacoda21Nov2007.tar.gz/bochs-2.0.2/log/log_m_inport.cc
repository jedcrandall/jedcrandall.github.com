/* Log manager for in interrupt events.
 * Author: Daniela
 * Date: 11/23/2005
 * Last update: 03/05/2006
 */
#include "config.h"

#if BX_LOG_REPLAY

#include "log_m_inport.h"
#include "log_e_inport.h"
#include "bochs.h"
#include "cpu/cpu.h"

/**
 * Static members
 */ 
LogMInPort* LogMInPort::instance = 0;
set<Bit16u> LogMInPort::nonLoggedInPorts;
set<Bit16u> LogMInPort::hdInPorts;
#if BX_LOG_RECOVERY
set<Bit16u> LogMInPort::ne2kPorts;
#endif

extern int replayMode;
extern ofstream inteFile;
extern ofstream devFile;
// Daniela
#include <iostream>
#include <fstream>
ofstream inpFile; 


LogMInPort::LogMInPort()
{
  printf("LogMInPort constructor\n");
}

/**
 * Creates a singleton instance of this class.
 */
LogMInPort* LogMInPort::Instance()
{
  if (instance == 0) {
    instance = new LogMInPort();
  }
  return instance;
}

/**
 * Create a new LogEInPort event by reading current line
 * of a log file. This method must be called from within LogManager
 * after making sure that the current line of the file corresponds
 * to a IO port event
 */
LogEInPort *LogMInPort::readLoggedPortIO(ifstream *logIn)
{
  LogEInPort *logE;
  Bit32u bytes;
  bx_address memAddress;
  Bit16u portAddr;
  Bit8u flagValue;
         
 // cout << "Inside LogMInPort::readLoggedPortIO\n";                      
  logE = new LogEInPort();
  (*logIn).read((char *) &portAddr, sizeof(Bit16u));  
  //devFile << portAddr << " ";

  //cout << "Port addr: " << portAddr << " ";
  logE->setPortAddr(portAddr);
  
  // There is only inport bytes to read from the log file if
  // the port addr is not from HD 
  if (!(isInHDInPortsSet(portAddr))) {
    (*logIn).read((char *) &bytes, sizeof(Bit32u));  
    //devFile << bytes << " ";
    //cout << "Bytes: " << bytes << " ";
    logE->setBytes(bytes);
  }

#if BX_LOG_RECOVERY
  int netTransportId;
  // if port addr is NE2k read what is the id of the logical end to end transport
  if (isInNe2kPortsSet(portAddr)) {
    // cout << "Port addr eh de rede, entao o leio: " << portAddr << "\n";
    (*logIn).read((char *) &netTransportId, sizeof(int));  
    logE->setNetTransportId(netTransportId);
  }
#endif

  (*logIn).read((char *) &flagValue, sizeof(Bit8u));  
 
  //devFile << (unsigned) flagValue << " ";
  //cout << "Flags: " << flagValue << " (unsigned): " << (unsigned)flagValue << " ";
  logE->setFlags(flagValue);
  if (logE->getStorageType() == STORAGE_MEM) {
    (*logIn).read((char *) &memAddress, sizeof(bx_address));  
    //devFile << memAddress;
    //cout << "Mem addr: " << memAddress;
    logE->setMemAddr(memAddress);
  }
 // devFile << endl;
  //cout << "\n";
  return logE;
}

/**
 * Write the LogEInPort passed as a parameter in the log file 
 * also passed as a parameter
 */
void LogMInPort::writeLogEntry(LogEInPort *logEntry, ofstream *logFile)
{
  Bit16u portAddr = logEntry->getPortAddr();
  (*logFile).write((char *) &portAddr, sizeof(Bit16u));
  //devFile << portAddr << " ";


 // Only write bytes if port addr is not from HD
 if (!(isInHDInPortsSet(portAddr))) {      
    Bit32u bytes = logEntry->getBytes();
   // devFile << bytes << " ";
    ////devFile << "Inport: "  << logEntry->getTick() << " ";
    ////devFile << "Bytes: " << bytes << endl;
    (*logFile).write((char *) &bytes, sizeof(Bit32u));
  }

#if BX_LOG_RECOVERY
 // If port addr is from NE2K write id of logical end to end transport into the log file
  if (isInNe2kPortsSet(portAddr)) {
    //cout << "Port addr eh de rede, entao o escrevo: " << portAddr << "\n";
    int netTransportId = logEntry->getNetTransportId();
    (*logFile).write((char *) &netTransportId, sizeof(int));
  }
#endif

  Bit8u flags = logEntry->getFlags();
  //devFile << (unsigned) flags << " " ;
  (*logFile).write((char *) &flags, sizeof(Bit8u));
  if (logEntry->getStorageType() == STORAGE_MEM) {
   Bit32u memAddr = logEntry->getMemAddr();
   //devFile << memAddr << endl;
   (*logFile).write((char *) &memAddr, sizeof(bx_address));
  }
 /* else {
    //devFile << "\n";
  }*/
}

void LogMInPort::readPortData() {

     
   //bx_pc_system.info("Reading data inport at tick: %llu", bx_pc_system.time_ticks());
   LogEInPort *logEntry = (LogEInPort*) LogManager::Instance()->getCurrentLogEntry();
   readInPortData(logEntry);
}

void LogMInPort::readInPortData(LogEInPort *logEntry) 
{
 
   unsigned storageType = logEntry->getStorageType();
   unsigned numBytes = logEntry->getNumBytes();
   Bit32u bytes = logEntry->getBytes();
   Bit8u integrity = logEntry->getIntegrity(); //0xFF; //logEntry->getIntegrity();
   Bit16u portAddr = logEntry->getPortAddr();
   unsigned numBitsRegWithMemAddr = logEntry->getNumBitsRegWithMemAddr();


   if (replayMode) {
#if BX_LOG_RECOVERY
     int netTransportId = logEntry->getNetTransportId();
     if (!(RecoveryManager::Instance()->isRecovering()) || 
        ( (!isInNe2kPortsSet(portAddr)) || 
          (netTransportId != RecoveryManager::Instance()->getMaliciousNetTransportId()) ) ) {
#endif   
 
    if (storageType == STORAGE_MEM) {
      bx_address addr = logEntry->getMemAddr();
      writeDataInMem(numBytes, addr, bytes, integrity, portAddr, numBitsRegWithMemAddr);
    }
    else if (storageType == STORAGE_REGISTER) {
      writeDataInRegister(numBytes, bytes, portAddr, numBitsRegWithMemAddr);
    }
    else {// depois passar isso para BX_PANIC 
      printf("LogMInPort::readInPortData: wrong storage type: %d", storageType);
      exit(1);
    }

#if BX_LOG_RECOVERY
    } 
    else {
      cout << "Malicious inport detected at tick: " << bx_pc_system.time_ticks() << "\n";
      devFile << "Malicious inport detected at tick: " << bx_pc_system.time_ticks() << "\n";
      LogManager::Instance()->finishReplaySession();  
    }
#endif
  } 
  delete logEntry;
}


void LogMInPort::testReadPortAllowed(Bit16u portAddr, unsigned numBytes) {
                                                                                
  // extracted from io.cc
   if (BX_CPU_THIS_PTR cr0.pe && (BX_CPU_THIS_PTR get_VM () ||
   ((BX_CPU_THIS_PTR sregs[BX_SEG_REG_CS].selector.rpl)>BX_CPU_THIS_PTR get_IOPL ()))) {
    if ( !BX_CPU_THIS_PTR allow_io(portAddr, numBytes) ) {
      BX_CPU_C::exception(BX_GP_EXCEPTION, 0, 0);
      }
    }
}

void LogMInPort::updateRegisterWithMemAddr(unsigned inout, unsigned numBytes, unsigned numBitsRegWithMemAddr) {
                                                                                          
 // extracted from cpu/io.cc
                          
 unsigned inc = numBytes;
 
 unsigned regIndex; // Index of register to be incremented: EDI/DI or RSI/SI
 if (inout == 0) { // inport
     regIndex = 7; // EDI/DI
 } 
 else if (inout == 1){
     regIndex = 6; // RSI/SI
 }
 else {
   cout << "Wrong inout value: " << inout << "\n";
 }
  
                                                                                          
// The code for 64 bits is not defined for our instance. If we start using 64 bits we
// need to include code to treat 64 bits here.
                                                                                          
 if (numBitsRegWithMemAddr == 64) {
   printf("LogMInPort::updateRegisterWithMemAddr: we are not prepared for 64 bits yet\n");   exit(1);
 }
 else if (numBitsRegWithMemAddr == 32) {
   if (BX_CPU_THIS_PTR get_DF ()) {
     BX_CPU_THIS_PTR gen_reg[regIndex].dword.erx-= numBytes; // Reg-= numBytes
   }
   else {
     BX_CPU_THIS_PTR gen_reg[regIndex].dword.erx+= numBytes; // Reg+= numBytes
   }
 }
 else if (numBitsRegWithMemAddr == 16) {
   if (BX_CPU_THIS_PTR get_DF ()) {
     (BX_CPU_THIS_PTR gen_reg[regIndex].word.rx)-= numBytes; // Reg-= numBytes
   }
   else {
     (BX_CPU_THIS_PTR gen_reg[regIndex].word.rx)+= numBytes; // Reg+= numBytes
   }
 }
 else {
   printf("LogMInPort::updateRegisterWithMemAddr: wrong number of bits in register with mem address: %d\n", numBytes);
    exit(1);
 }
}



void LogMInPort::writeDataInMem(unsigned numBytes, bx_address addr, Bit32u bytes, Bit8u integrity,
                                Bit16u portAddr, unsigned numBitsRegWithMemAddr)
{
   extern Expression *GlobalL0Return;
   extern Expression *GlobalL1Return;
  
   Label *L0, *L1;
   L0 = L1 = NULL;

  testReadPortAllowed(numBytes, portAddr);

  //LogicalEndToEndTransport *current = RecoveryManager::Instance()->getCurrentLogicalEndToEndTransport();
  //LogicalEndToEndTransport *malicious = RecoveryManager::Instance()->getMaliciousNetTransport();
                                                                            
  if (numBytes == 1) {
    Bit8u byte = (Bit8u) bytes;
    Bit8u byte0 = 0;
                        
    // Write a zero to memory, to trigger any segment or page
    // faults before reading from IO port. (Compatibility with io.cc)
   
      BX_CPU_C::write_virtual_byte(BX_SEG_REG_ES, addr, &byte0, &integrity);
    
    if (isInHDInPortsSet(portAddr)) {
      byte =  (Bit8u) BX_INP(portAddr, 1); 
    } 
    else {
      BX_INP(portAddr, 1); 
    }  
                                                                    
    // write the intended value
       BX_CPU_C::write_virtual_byte(BX_SEG_REG_ES, addr, &byte, &integrity);
     
#if BX_DEBUGGER
    if (BX_CPU_THIS_PTR sexecmode)
    {
	BX_CPU_C::write_virtual_expression(BX_SEG_REG_ES, addr, NULL);
    }
#endif

                                                                                                    
  } else if (numBytes == 2) {
    Bit16u word = (Bit16u) bytes;
    Bit16u word0 = 0;

#if BX_DEBUGGER
    if (portAddr == 0x290 && BX_CPU_THIS_PTR sexecmode)
    {
      L0 = (Label *) GlobalL0Return;
      L1 = (Label *) GlobalL1Return;
      GlobalL0Return = NULL;
      GlobalL1Return = NULL;
#if 0
		TheLabels.AddLabelByte((unsigned char) value16);
		TheLabels.AddLabelByte((unsigned char) (value16 >> 8));
#endif
      }
#endif
                                                              
    // Write a zero to memory, to trigger any segment or page
    // faults before reading from IO port. (Compatibility with io.cc)
      BX_CPU_C::write_virtual_word(BX_SEG_REG_ES, addr, &word0, &integrity);

    if (isInHDInPortsSet(portAddr)) {
      word = (Bit16u) BX_INP(portAddr, 2);
    }
    else {
      BX_INP(portAddr, 2);
    }

    // write the intended value
      BX_CPU_C::write_virtual_word(BX_SEG_REG_ES, addr, &word, &integrity);

#if BX_DEBUGGER
    if (BX_CPU_THIS_PTR sexecmode)
    {
    	if((L0 != NULL) || (L1 != NULL))
    	{
    		BX_CPU_C::write_virtual_expression(BX_SEG_REG_ES, addr, (Expression *) L0);
    		BX_CPU_C::write_virtual_expression(BX_SEG_REG_ES, addr + 1, (Expression *) L1);
    	}
	else
	{
    		BX_CPU_C::write_virtual_expression(BX_SEG_REG_ES, addr, NULL);
    		BX_CPU_C::write_virtual_expression(BX_SEG_REG_ES, addr + 1, NULL);
	}
    }
#endif
  } else if (numBytes == 4) {
    Bit32u dword0 = 0;
    Bit32u dword = (unsigned int) bytes;
                                                                                                    
    // Write a zero to memory, to trigger any segment or page
    // faults before reading from IO port. (Compatibility with io.cc)
      BX_CPU_C::write_virtual_dword(BX_SEG_REG_ES, addr, &dword0, &integrity);
               
    if (isInHDInPortsSet(portAddr)) {
      dword = (Bit32u) BX_INP(portAddr, 4);  
    }
    else {
      BX_INP(portAddr, 4);  
    }       
                                                                   
    // write the intended value
      BX_CPU_C::write_virtual_dword(BX_SEG_REG_ES, addr, &dword, &integrity);

#if BX_DEBUGGER
    if (BX_CPU_THIS_PTR sexecmode)
    {
      for(int i=0; i<4;i++) {
	BX_CPU_C::write_virtual_expression(BX_SEG_REG_ES, addr + i, NULL);
      }
    }
#endif

  } else {
    printf("LogMInPort::writeDataInMem: wrong number of bytes: %d\n", numBytes);
    exit(1);
  }
                       
 //  if (!isInNe2kPortsSet(portAddr) || (!current->equal(malicious))) {
     updateRegisterWithMemAddr(0, numBytes, numBitsRegWithMemAddr);
   //}
}

void LogMInPort:: writeDataInRegister(unsigned numBytes, Bit32u bytes, Bit16u portAddr, unsigned numBitsRegWithMemAddr)
{
  extern int GLOBALCMOSThingy;                                                                              
  extern int GLOBALCMOSMode;
  extern unsigned int GLOBALCMOSCycleCount;
  extern unsigned int GLOBALCMOSCyclesToRun;
  extern Skippy_struct *Skippy;
  extern int LabelNumber;
   
   //LogicalEndToEndTransport *current = RecoveryManager::Instance()->getCurrentLogicalEndToEndTransport();
   //LogicalEndToEndTransport *malicious = RecoveryManager::Instance()->getMaliciousNetTransport();

   if (numBytes == 1) {
    Bit8u byte = (Bit8u) bytes;
    
    if (isInHDInPortsSet(portAddr)) {
      byte = (Bit8u) BX_CPU_THIS_PTR inp8(portAddr);
    } 
    else {
      BX_CPU_THIS_PTR inp8(portAddr);
    }
      BX_CPU_THIS_PTR gen_reg[0].word.byte.rl = byte; // copy byte to register AL

  #if BX_DEBUGGER
    if (numBitsRegWithMemAddr == 8) {
      if (GLOBALCMOSThingy && !(BX_CPU_THIS_PTR sexecmode || GLOBALCMOSMode)) { 
        printf("GLOBALCMOSThingy\n"); /*BX_PANIC(("Bla"));*/ GLOBALCMOSThingy = 0;
      }                                                                                                                  
      if (BX_CPU_THIS_PTR sexecmode || GLOBALCMOSMode)
      {
        if (GLOBALCMOSThingy)
        {
                printf("Did something useful?\n");
                GLOBALCMOSThingy = 0;
                //WriteSymbolicDoubleRegister(0, (Expression *) new Label(al));
                TheLabels.WriteSymbolicRegister(0, 0, (Expression *) new Label(byte));
                TheLabels.WriteSymbolicRegister(0, 1, (Expression *) new Label(byte));
                TheLabels.WriteSymbolicRegister(0, 2, (Expression *) new Label(byte));
                TheLabels.WriteSymbolicRegister(0, 3, (Expression *) new Label(byte));
                GLOBALCMOSCycleCount = GLOBALCMOSCyclesToRun;
        }
        else
        {
                WriteSymbolicDoubleRegister(0, NULL);
        }
      } // if (GLOBALCMOSThingy 
    } 
    else if (numBitsRegWithMemAddr == 16) 
    {
      if (BX_CPU_THIS_PTR sexecmode)
      {
	  WriteSymbolicDoubleRegister(0, NULL);
#if 0
	  if ((portAddr == 0x280) && (byte == 0xa))
	  {
		Skippy_struct *NewSkippy;
		NewSkippy = new Skippy_struct;
		NewSkippy->IndexBegin = LabelNumber;
		NewSkippy->SizeSkippy = 0;
		NewSkippy->pNext = Skippy;
		Skippy = NewSkippy;
	  }
#endif
       }
    } 
    else {
      cout << "LogMInPort::writeDataInRegister: wrong value for numBitsRegWithMemAddr: " <<
      numBitsRegWithMemAddr << "\n";
      exit(1);
    }
#endif
  } else if (numBytes == 2) {
    Bit16u word = (Bit16u) bytes;
    if (isInHDInPortsSet(portAddr)) {
      word = (Bit16u) BX_CPU_THIS_PTR inp16(portAddr);
    }
    else {
      BX_CPU_THIS_PTR inp16(portAddr);
    }
      BX_CPU_THIS_PTR gen_reg[0].word.rx =  word; // copy word to register AX

#if BX_DEBUGGER
    if (BX_CPU_THIS_PTR sexecmode)
    {
  	Expression *ENull = NULL;
	WriteSymbolicDoubleRegister(0, ENull);
    }
#endif
  } else if (numBytes == 4) {
      if (isInHDInPortsSet(portAddr)) {
        bytes = (Bit32u) BX_CPU_THIS_PTR inp32(portAddr);
      }
      else {
        BX_CPU_THIS_PTR inp32(portAddr);
      }
        BX_CPU_THIS_PTR gen_reg[0].dword.erx = bytes; // copy dword to register EAX

#if BX_DEBUGGER
    if (BX_CPU_THIS_PTR sexecmode)
    {
  	Expression *ENull = NULL;
	WriteSymbolicQuadRegister(0, ENull);
    }
#endif


 } else {
    printf("LogMInPort::writeDataInRegister: wrong number of bytes: %d\n", numBytes);
  } 

}

/**
 * Returns true if port addr passed as a parameters is in set of non
 * logged in port addresses and false otherwise.
 */
bool LogMInPort::isInNonLoggedInPortsSet(Bit16u portAddr)
{
  set<Bit16u>::iterator it = nonLoggedInPorts.find(portAddr);
  if (it == nonLoggedInPorts.end()) {
    return false;
  }
  else {
    //cout << "Port not logged: " << portAddr << "\n";
    return true;
   }
}

/**
 * Insert a port addr in the list of non-logged inport addresses
 */
void LogMInPort::insertNonLoggedInPort(Bit16u addr)
{
   nonLoggedInPorts.insert(addr);
}

/**
 * Returns true if port addr passed as a parameters is in set of HD
 *  in port addresses and false otherwise.
 */

bool LogMInPort::isInHDInPortsSet(Bit16u portAddr)
{
  set<Bit16u>::iterator it = hdInPorts.find(portAddr);
  if (it == hdInPorts.end()) {
    return false;
  }
  else {
    return true;
   }
}

/**
 * Insert a port addr in the list of HD inport addresses
 */
void LogMInPort::insertHDInPort(Bit16u addr) 
{
  hdInPorts.insert(addr);
}

#if BX_LOG_RECOVERY
/**
 * Returns true if port addr passed as a parameters is in set of NE2K
 * port addresses and false otherwise.
 */

bool LogMInPort::isInNe2kPortsSet(Bit16u portAddr) {

  set<Bit16u>::iterator it = ne2kPorts.find(portAddr);
  if (it == ne2kPorts.end()) {
    return false;
  }
  else {
    return true;
   }


}

/**
 * Insert a port addr in the list of ne2k port addresses
 */
void LogMInPort::insertNe2kPort(Bit16u addr) {
  ne2kPorts.insert(addr);

}
#endif


LogMInPort::~LogMInPort()
{
  //printf("LogMInPort destructor\n");

}

#endif
