/**
 * Log entry for handling interrupt events.
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 05/01/2005
 * Last update:03/05/2007 
 */

#include "config.h"

#if BX_LOG_REPLAY

#include <iostream>
using namespace std;

#include "log_e_handleinterrupt.h"

LogEHandleInterrupt::LogEHandleInterrupt()
{
   //printf("LogEHandleInterrupt constructor\n");
   idNumber = idNumberGenerator++;
}

/**
 * This constructor is used when I want to make a copy of my object.
 */
LogEHandleInterrupt::LogEHandleInterrupt(LogEHandleInterrupt *logEntry) 
{
  setTick(logEntry->getTick());
} 


LogEHandleInterrupt::~LogEHandleInterrupt()
{
   //printf("LogEHandleInterrupt destructor\n");
}

#endif
