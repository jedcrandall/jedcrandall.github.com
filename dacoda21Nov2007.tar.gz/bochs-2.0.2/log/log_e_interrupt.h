/**
 * Log entry for in interrupt events.
 * Author: Daniela
 * Date: 11/21/2005
 * Last update: 06/16/2005
 */
#ifndef __LOG_E_INTERRUPT_H
#define __LOG_E_INTERRUPT_H

#include <iostream>
#include <bitset>
using namespace std;

#include "log_entry.h"

#define NUM_FLAGS_INTERRUPT 8 // we are going to encode the irq_num and raise attributes as
                    // a bitset.
#define SHIFT_FLAG 33 // to avoid reaching a non-printable caracter, after using binary format remove.

class LogEInterrupt : public LogEntry
{
  private:
    unsigned  irq_num; // IRQ line number for the event
    unsigned raise; // IRQ line number for the event

/**
 * We are encoding irq_num and raise in a bitSet as follows: Bits 0, 1, 2, 3 encodes the
 * irq line. Bit4: if set, raise=1, if not set raise=0. 
 */   
 // bitset<NUM_FLAGS_INTERRUPT> flags;
  bool checkFlags(bitset<NUM_FLAGS_INTERRUPT> flagsReceived);
 
  public:
    LogEInterrupt();
    LogEInterrupt(LogEInterrupt *logEntry); 
    void setIRQNum(unsigned num);
    unsigned getIRQNum();
    void setRaise(unsigned num);
    unsigned getRaise();
    Bit8u getFlags();
    void setFlags(Bit8u value);
    ~LogEInterrupt();
  

};
#endif
