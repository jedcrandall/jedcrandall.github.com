/**
 * Represents a logical end to end transport which can be a TCP connection or
 * a logical UDP transport. 
 * Date: 11/10/2006
 * Last update: 01/19/2007
 */
#ifndef __LOGICAL_END_END_TRANSPORT_H
#define __LOGICAL_END_END_TRANSPORT_H

#include <iostream>
#include "config.h"
#include <string>
#include <unistd.h>
using namespace std;


/**
 * Represents an IP addres
 */
class IPAddress {

  private:
    Bit8u part1, part2, part3, part4;

  public:
    IPAddress(Bit8u p1, Bit8u p2, Bit8u p3, Bit8u p4);
    bool equal(IPAddress *ipA);
    Bit8u getPart(Bit8u num);
    // to debug
    void print();
    Bit32u toULong();
    ~IPAddress();
};

class LogicalEndToEndTransport 
{
  private:
    int id;
    static int idNumberGenerator;
    IPAddress *ipSource;
    IPAddress *ipDestiny;
    Bit16u portSource;
    Bit16u portDestiny;


  public:
    LogicalEndToEndTransport(IPAddress *ipS, IPAddress *ipD, Bit16u portS, Bit16u portD);
    int getId();
    bool equal(IPAddress *ipS, IPAddress *ipD, Bit16u portS, Bit16u portD);
    bool equal(LogicalEndToEndTransport *object);
    IPAddress *getIPAddressSource();
    IPAddress *getIPAddressDestiny();
    Bit16u getPortSource();
    Bit16u getPortDestiny();
    void print();
    ~LogicalEndToEndTransport();
    
};


#endif

