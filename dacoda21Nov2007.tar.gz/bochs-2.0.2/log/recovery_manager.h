/**
 * Manages the recovery of a run.
 * Implements the sigleton pattern
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 11/03/2006
 * Last update: 01/20/2007
 */
#ifndef __RECOVERY_MANAGER_H
#define __RECOVERY_MANAGER_H

#include "bochs.h"
#include <iostream>
#include "config.h"
#include <list>
#include <unistd.h>
#include <set>
using namespace std;

#include "logical_end_end_transport.h"

#if BX_LOG_RECOVERY

class RecoveryManager
{
  private:
    static RecoveryManager* instance; // singleton pattern
    static bool startRecoverableCheckpoint; //  
    static bool recoveryOn; // If executing phase II (DACODA) or III (recovery) of the whole recovery process
    static bool recoveryMode; // If system will start recovery process when attacked
    static bool recovering; // if executing phase III of the recovery process
    list<LogicalEndToEndTransport*> netTransports;
    LogicalEndToEndTransport *currentNetTransport;
    static int maliciousNetTransportId; // id of a logical end to end transport related to an attack
    static int pipeDescriptor[2]; // Pipe for collaborating recovery process communicate about
                        // the id of a malicious net transport

    static int replayerWait; // condition that makes the replayer process wait for the end of the logger
    static void createLoggerProcessRedologFile(int *redologFileDescriptor); 
    static void stopWaiting(int i); //SIGUSR1 handler: keeps the replayer process waiting
    static void setUpRecoveryPhases(); 
    static void setDACODAOn();
    static void setDACODAOff();
    static void initDACODAPhase();
    static void finishDACODAPhase();
    static void initRecoveryPhase();
    void addLogicalEndToEndTransport(LogicalEndToEndTransport *netTransport);
    LogicalEndToEndTransport *getLogicalEndToEndTransport(IPAddress *ipS, IPAddress *ipD, Bit16u portS, Bit16u portD);
    void setCurrentLogicalEndToEndTransport(LogicalEndToEndTransport *netTransport);
    set<int> *extractSetNetTransportId(list<Expression*> *exps);
    void addSetNetTransportId(set<int> *setIds);
    int extractMaliciousNetTransportId(set<int> *setId); 
    list<Expression*> attackExpressions; // set of expressions related to an attack 
    set<int> maliciousNetTransportIds; // set of net transport ids related to an attack
  
    static bool semiReplayFinished; 
 
    // just for USENIX experiments 
    LogicalEndToEndTransport *client;
    static int clientPktTotal; 
    static int clientPktLogged;
    static int clientPktReplay;
    static int clientPktSemiReplay;
    //static bool semiReplayFinished;
    static void createPipe(); 
  protected:
    RecoveryManager();
   
  public:
    static RecoveryManager* Instance();
    static void startRecoverableRun(int *redoLogFileDescriptor);
    void initRecovery();
    static void wakeUpReplayer();
    void recover();
    void extractLogicalEndToEndTransport(unsigned char *ethFrame);
    int getCurrentLogicalEndToEndTransportId();
    static void setRecoveryOn(bool mode);
    static bool isRecoveryOn(); 
    static void setRecoveryMode(bool mode);
    static bool isRecoveryMode(); 
    static void setRecovering(bool value);
    static bool isRecovering();
    LogicalEndToEndTransport *getCurrentLogicalEndToEndTransport();
    LogicalEndToEndTransport *getMaliciousNetTransport();
    LogicalEndToEndTransport *findNetTransport(int id);
    int getMaliciousNetTransportId();
    void setMaliciousNetTransportId(int value);
    void addAttackExpression(Expression *exp);
    void addListAttackExpressions(list<Expression *> *exps);
    static void startSemiReplayPhase();
    static void finishSemiReplayPhase();
    static void setStartRecoverableCheckpoint(bool value);
    static bool isStartRecoverableCheckpoint();
    static void resetMaliciousNetTransportId();
    static bool isSemiReplayFinished();
    ~RecoveryManager();
    // for usenix
    static void printClientStat();
   };

#endif

#endif
