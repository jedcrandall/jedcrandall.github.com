/**
 * Log entry for in port events.
 * Author: Daniela
 * Date: 11/21/2005
 * Last update: 03/05/2007
 */

#include "config.h"
#if BX_LOG_REPLAY

#include <iostream>
#include <string>
#include <cmath>
using namespace std;

#include "log_e_inport.h"
#include <fstream> // just for debugging
extern ofstream devFile;

LogEInPort::LogEInPort()
{
 // cout << "LogEInport contructor. IdNumberGenerator: " <<
  //idNumberGenerator << "\n";
  idNumber = idNumberGenerator++;
}

/**
 * This constructor is used when I want to make a copy of my object.
 */
LogEInPort::LogEInPort(LogEInPort *logEntry)
{
    setTick(logEntry->getTick());
    setNumBytes(logEntry->getNumBytes());
    setBytes(logEntry->getBytes());
    setStorageType(logEntry->getStorageType());
    setMemAddr(logEntry->getMemAddr());
    setIntegrity(logEntry->getIntegrity());
    setPortAddr(logEntry->getPortAddr());
    setNumBitsRegWithMemAddr(logEntry->getNumBitsRegWithMemAddr());
}

void LogEInPort::setNumBytes(unsigned num)
{
  numBytes = num;
}

unsigned LogEInPort::getNumBytes()
{
  return numBytes;
}

void LogEInPort::setBytes(Bit32u buffer)
{
  bytes = buffer;
}

Bit32u LogEInPort::getBytes()
{
  return bytes;
}

void LogEInPort::setStorageType(unsigned type)
{
  storageType = type;
}

unsigned LogEInPort::getStorageType()
{
  return storageType;
}

void LogEInPort::setMemAddr(bx_address addr)
{
  memAddr = addr;
}

bx_address LogEInPort::getMemAddr()
{
  return memAddr;
}

void LogEInPort::setIntegrity(Bit8u integ)
{
  integrity = integ;
}

Bit8u LogEInPort::getIntegrity()
{
  return integrity;
}

void LogEInPort::setPortAddr(Bit16u addr)
{
  portAddr = addr;
}

Bit16u LogEInPort::getPortAddr()
{
  return portAddr;
}


void LogEInPort::setNumBitsRegWithMemAddr(unsigned numBits) {
                                                                                
  numBitsRegWithMemAddr = numBits;
}
                                                                                
unsigned LogEInPort::getNumBitsRegWithMemAddr() {
                                                                                
  return numBitsRegWithMemAddr;
}
       
/**
 * Return the atributes numBytes, storageType and integrity encoded and a one byte number.
 * Encoding is explained in log_e_inport.h
 */                                                                         
Bit8u LogEInPort::getFlags()
{
 // devFile << "NumBytes=>" << numBytes << " ";
  bitset<NUM_FLAGS> bs;
  if (numBytes == 1) {
    bs.set(numBytes1); 
  }
  else if (numBytes == 2) {
    bs.set(numBytes2);
  }
  else if (numBytes == 4) {
    bs.set(numBytes4);
  }
  bs.set(storage, storageType);
 // devFile << "StorageType=>" << storageType << " ";
//  if (storageType == STORAGE_MEM) {
    if (numBitsRegWithMemAddr == 16) {
      bs.set(Bits16);
    }
    else if (numBitsRegWithMemAddr == 32) {
      bs.set(Bits32);
    }
    else if (numBitsRegWithMemAddr == 64) {
      bs.set(Bits64);
    }
  //}
 // devFile << "numBitsRegWithMemAddr=>" << numBitsRegWithMemAddr <<  " ";
  bs.set(integ, integrity);
  //devFile << "Integrity=>" << (unsigned)integrity << " ";
   if (!checkFlags(bs)) {
   /* cout << "LogEInPort::getFlags: invalid flag: " << bs.to_ulong() << 
    "(" << bs.template to_string<char, char_traits<char>, allocator<char> >() << ")\n";
    exit(1); */
  }

  return (Bit8u) (bs.to_ulong());
}
  
/**
 * Set the value of atributes numBytes, storageType and integrity according to byte value
 * passed as a parameter. Encoding is explained in log_e_inport.h
 */        
void LogEInPort::setFlags(Bit8u value) 
{
  //cout << "Inside LogEInPort::setFlags\n";
 // unsigned char test = (unsigned char) value;
 // cout << "Value: " << value << "\n";
  
 // int valueBits = (int) value;
  bitset<NUM_FLAGS> bs(value);
  //cout << "Received value: " << value << " bs.to_ulong(): " << 
  //bs.to_ulong() << " bs.to_string(): " <<
  //bs.template to_string<char, char_traits<char>, allocator<char> >() << "\n"; 
  if (!checkFlags(bs)) {
    /*cout << "LogEInPort::setFlags: invalid flag: " << bs.to_ulong() << 
    "(" << bs.template to_string<char, char_traits<char>, allocator<char> >() << ")\n";
    exit(1); */
  }
//  flags.reset();
  if (bs.test(0)) {
    numBytes = 1;
  }
  if (bs.test(1)) {
    numBytes = 2;
  }
  if (bs.test(2)) {
    numBytes = 4;
  }
  if (bs.test(3)) {
    storageType = STORAGE_MEM;
  }
  else 
  {
    storageType = STORAGE_REGISTER;
  }
  if (bs.test(4)) {
    numBitsRegWithMemAddr = 16;
  }
  else if (bs.test(5)) {
    numBitsRegWithMemAddr = 32;
  }
  else if (bs.test(6)) {
    numBitsRegWithMemAddr = 64;
  }
  else { // position 4, 5 and 6 is unset.
    numBitsRegWithMemAddr = 8;
  }
  if (bs.test(7)) {
    integrity = 0xFF;
  }
  else 
  {
    integrity = 0;
  }
}

/**
 * Return true is flags passed as a parameter is a valid flag and false otherwise.
 * Invalid flags: when more than 1 bit is set among positions 0, 1, and 2 or among
 * positions 4, 5, and 6.
 */
bool LogEInPort::checkFlags(bitset<NUM_FLAGS> flagsReceived)
{
 bitset<3> bs;
 for(int i=0; i<3; i++) {
  bs[i] = flagsReceived[i];
 }
 if ((bs.count() > 1) || (bs.count() == 0)) return false;

 for(int i=0; i<3; i++) {
    bs[i] = flagsReceived[i+4];
  }
 if (bs.count() > 1) return false;
 return true;
}


#if BX_LOG_RECOVERY
int LogEInPort::getNetTransportId() { 
  
  return netTransportId;
}
    
void LogEInPort::setNetTransportId(int value) {

  netTransportId = value;
} 
#endif

LogEInPort::~LogEInPort()
{
   //printf("LogEInport destructor\n");

}

#endif
