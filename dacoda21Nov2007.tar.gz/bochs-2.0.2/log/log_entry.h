/**
 * Log Entry. All log entry classes inherit from it
 * Author: Daniela
 * Date: 11/21/2005
 * Last update: 05/25/2006
 */
#ifndef __LOG_ENTRY_H
#define __LOG_ENTRY_H
#include <iostream>
#include "config.h"


class LogEntry
{
  protected:
    static Bit64u idNumberGenerator;
    Bit64u tick; // tick in Bochs that log event occurred.
    Bit64u idNumber; // id number of an event.
    static void setIdNumberGenerator(Bit64u value);

  public:
    LogEntry();
    Bit64u getIdNumber();
    void setIdNumber(Bit64u number);
    Bit64u getTick(); // get the tick associated to the log entry
    void setTick(Bit64u tick); // set the tick associated with log entry
    virtual ~LogEntry() {};
};

class LogEntrySortCriterion {

  public:
    bool operator() (LogEntry *log1, LogEntry *log2) const {
      return (log1->getIdNumber() < log2->getIdNumber());
    }
};

#endif
