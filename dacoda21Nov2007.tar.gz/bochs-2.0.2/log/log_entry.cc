/**
 * Log Entry. All log entry classes inherit from it
 * Author: Daniela
 * Date: 11/21/2005
 * Last update: 03/05/2007
 */

#include "config.h"
#if BX_LOG_REPLAY

#include <iostream>
#include "log_entry.h"

Bit64u LogEntry::idNumberGenerator = 0;

LogEntry::LogEntry()
{
  //printf("Log entry constructor.\n");
}

Bit64u LogEntry::getIdNumber() {
  return idNumber;
}
                                                                                    
void LogEntry::setIdNumber(Bit64u number) {
  idNumber = number;
}

Bit64u LogEntry::getTick()
{
  return tick;
}

void LogEntry::setTick(Bit64u tick)
{
  this->tick = tick;
  
}

void LogEntry::setIdNumberGenerator(Bit64u value) {
  idNumberGenerator = value;
}

#endif
