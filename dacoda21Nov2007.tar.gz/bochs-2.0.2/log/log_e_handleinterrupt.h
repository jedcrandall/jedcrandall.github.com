/**
 * Log entry for handling interrupt events.
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 05/01/2006
 * Last update: 
 */
#ifndef __LOG_E_HANDLEINTERRUPT_H
#define __LOG_E_HANDLEINTERRUPT_H

#include <iostream>
using namespace std;

#include "log_entry.h"

class LogEHandleInterrupt : public LogEntry
{
  public:
    LogEHandleInterrupt();
    LogEHandleInterrupt(LogEHandleInterrupt *logEntry); 
    ~LogEHandleInterrupt();

};
#endif
