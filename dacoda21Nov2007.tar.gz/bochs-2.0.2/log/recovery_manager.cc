/**
 * Manages the recovery of a run.
 * Implements the sigleton pattern
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 11/03/2006
 * Last update: 03/05/2007 
 */
#include "config.h"

#if BX_LOG_REPLAY && BX_LOG_RECOVERY

#include "recovery_manager.h"
//#include "bochs.h"
#include <signal.h>
#include <fstream>
using namespace std;

// just for debug
extern ofstream devFile;


/**
 * Static members
 */
int RecoveryManager::replayerWait = 1;
RecoveryManager* RecoveryManager::instance = 0;
bool RecoveryManager::recoveryMode = false;
bool RecoveryManager::recoveryOn = false;
bool RecoveryManager::recovering = false;
bool RecoveryManager::startRecoverableCheckpoint = false;  
int  RecoveryManager::maliciousNetTransportId = 0;
bool RecoveryManager::semiReplayFinished = false; 

// for USENIX
int RecoveryManager::clientPktTotal = 0; 
int RecoveryManager::clientPktLogged = 0;
int RecoveryManager::clientPktReplay = 0;
int RecoveryManager::clientPktSemiReplay = 0;
int RecoveryManager::pipeDescriptor[2];

extern int GLOBALSexecMode;
extern int logMode;
extern int replayMode; 
/**
 * Constructor
 */
RecoveryManager::RecoveryManager() 
{
  cout << "RecoveryManager created.\n";
  IPAddress *s = new IPAddress(169, 237, 7, 34); // angara.cs.ucdavis.edu
  IPAddress *d = new IPAddress(169, 237, 7, 163);
  client = new LogicalEndToEndTransport(s, d, 10, 80);
  //maliciousNetTransport = potomac;

/*  // create pipe
   if (pipe(pipeDescriptor) < 0) {
    cout << "RecoveryManager::RecoveryManager: Pipe could not be created\n";
    exit(1);
  }*/
  
  //attackExpressions = new list<Expression*>;

} 

/**
 * Creates a singleton instance of this class.
 */
RecoveryManager* RecoveryManager::Instance()
{
  if (instance == 0) {
    instance = new RecoveryManager();
  }
  return instance;
}
    

/**
 * Creates the redolog file of the logger process (child process) as an independent copy
 * of its parent's redolog file.
 */
void RecoveryManager::createLoggerProcessRedologFile(int *redologFileDescriptor) {

   cout << "createLoggerProcessRedologFile. PID: " << getpid() << "\n";

   //devFile << "createLoggerProcessRedologFile. PID: " << getpid() << "\n";

  	int newfd = open("/tmp/redolog.redolog.child", O_RDWR | O_CREAT);

	int oldfd = *redologFileDescriptor;
	char buf[4096];
	int r;

	if (newfd < 0)
	{
	  BX_CPU_THIS_PTR panic("Error creating /tmp/redolog.redolog.child");
	  newfd = open("/tmp/redolog.redolog.child", O_RDWR | O_CREAT | O_EXCL);
	}

	lseek(oldfd, 0, SEEK_SET);

	do
	{
	  r = read(oldfd, buf, 4096);
	  if (r > 0)
	    write(newfd, buf, 4096);
	}
	while (r > 0);

	*redologFileDescriptor = newfd;
	close(oldfd);
}

/**
 * Start a recoverable run by taking a checkpoint of the system and initializing a recoverable log/replay
 * session
 */
void RecoveryManager::startRecoverableRun(int *redologFileDescriptor) {

        cout << "startRecoverableRun. PID: " << getpid() << "\n";
        createPipe();
        //devFile << "startRecoverableRun. PID: " << getpid() << "\n";
	int pid;   
	pid = fork();
	
	if (pid == 0) //child or logger process - Phase 1 (Logging)
	{
               LogManager::Instance()->setChildPID(getpid());
		if (redologFileDescriptor != NULL)
		{
                   createLoggerProcessRedologFile(redologFileDescriptor);
		}
                else {
                  cout << "RecoveryManager::startRecoverableRun(): descriptor of redolog file is null\n";
                  exit(1);
                }
                LogManager::startLogSession();
	}
	else //parent or replay/recovery process
	{
                LogManager::Instance()->setChildPID(pid);
		sighandler_t old;
		old = signal(SIGUSR1, stopWaiting);
		// wait for child to exit
		while (replayerWait) sleep(1);
               	replayerWait = 1;
		fflush(stdout);
		signal(SIGUSR1, old);
                setUpRecoveryPhases();
                cout << "Exiting startRecoverableRun ... PID: " << getpid() << "\n";
  
	}


}

/**
 * The parent process (the replayer) divides itself in two process, each of which will be
 * responsible for one of phases 2 and 3 of the whole recovery process which also comprehends 
 * the log phase (Phase 10)
 */
void RecoveryManager::setUpRecoveryPhases() {

       // devFile << "setUpRecoveryPhases. PID: " << getpid() << "\n";
        cout << "setUpRecoveryPhases. PID: " << getpid() << "\n";

        int pid;   

        recoveryOn = true;
	pid = fork();
	
	if (pid == 0) // Process responsible for recovery Phase 2 (DACODA)
	{
          close(/*Instance()->*/pipeDescriptor[0]); // This process writes info to the pipe
          initDACODAPhase();       
	}
	else // Process responsible for recovery Phase 3
	{
                int aux;
                close(/*Instance()->*/pipeDescriptor[1]); // This process reads info from the pipe
		sighandler_t old;
                old = signal(SIGUSR1, stopWaiting);
		// wait for child to exit
		while (replayerWait) sleep(1);
               	replayerWait = 1;
		fflush(stdout);
                signal(SIGUSR1, old);
                int numBytesRead = read(/*Instance()->*/pipeDescriptor[0], &(maliciousNetTransportId), sizeof(int));
                cout << "Recovery phase 3 got this malicious netId: " << maliciousNetTransportId << "\n";

                initRecoveryPhase();
                cout << "Exiting setUpRecoveryPhases... PID: " << getpid() << "\n";
	}
  
}



/**
 * Ends the condition that makes the replayer process wait in the background.
 */
void RecoveryManager::stopWaiting(int signalNumber) {
  cout << "stopWaiting. PID: " << getpid() << "\n";

  replayerWait = 0;
}


/**
 * The process executing this method wakes up its parent process (always a replayer) by
 * killing itself. The SIGUSR handler (stopWaiting) is executed in the waken-up parent
 * process
 */
void RecoveryManager::wakeUpReplayer() {
 
        //devFile << "wakeUpReplayer. PID: " << getpid() << "\n";
        cout << "wakeUpReplayer. PID: " << getpid() << "\n";
	kill(getppid(),SIGUSR1);
	exit(0);
        cout << "Leaving wakeUpReplayer. PID: " << getpid() << "\n";

}

/**
 * Set DACODA analysis tool on
 */
void RecoveryManager::setDACODAOn() {

  //devFile << "SetDACODAOn. PID: " << getpid() << "\n";
  cout << "SetDACODAOn. PID: " << getpid() << "\n";
  BX_CPU_THIS_PTR sexecmode = 1;
  GLOBALSexecMode = 1;
  BX_CPU_THIS_PTR oszapc.Op1Expr = NULL;
  BX_CPU_THIS_PTR oszapc.Op2Expr = NULL;
  cout << "Symbolic execution enabled\n";

}

/**
 * Set DACODA analysis tool off
 */

void RecoveryManager::setDACODAOff() {

  //devFile << "setDACODAOff. PID: " << getpid() << "\n";
  cout << "setDACODAOff. PID: " << getpid() << "\n";
  BX_CPU_THIS_PTR sexecmode = 0;
  GLOBALSexecMode = 0;
  cout << "Symbolic execution disabled.\n";

}

/**
 * Start Phase 2 of recovery. In this phase the run is replayed
 * with DACODA on. DACODA is in charge of finding out the labels of
 * the network packets directly involved with the attack caught by Minos
 */
void RecoveryManager::initDACODAPhase() {

 // devFile << "initDACODAPhase. PID: " << getpid() << "\n";
  cout << "initDACODAPhase. PID: " << getpid() << "\n";
  setDACODAOn();
  LogManager::startReplaySession();
  cout << "Leaving initDACODAPhase. PID: " << getpid() << "\n";

}
    

/**
 * Start Phase 2 of recovery. In this phase the run is replayed
 * with DACODA on. DACODA is in charge of finding out the labels of
 * the network packets directly involved with the attack caught by Minos
 */
void RecoveryManager::finishDACODAPhase() {
  
  //devFile << "finishDACODAPhase. PID: " << getpid() << "\n";
  cout << "finishDACODAPhase. PID: " << getpid() << "\n";
  setDACODAOff();
}


/**
 * Start Phase 3 of recovery. In this phase we replay the run while
 * not writing into main memory any bytes coming from network packets from
 * the malicious source detected in Phase 2.
 */
void RecoveryManager::initRecoveryPhase() {

 // devFile << "initRecoveryPhase. PID: " << getpid() << "\n";
  cout << "initRecoveryPhase. PID: " << getpid() << "\n";
  recovering = true;
  LogManager::startReplaySession(); // replay recovering
  cout << "Exiting initRecovery phase... PID: " << getpid() << "\n";

}


/**
 * This method is called when Minos catches an attack. It triggers all recovery procedures.
 */
void RecoveryManager::recover() {

  
 // devFile << "recover. PID: " << getpid() << "\n";
  cout << "recover. PID: " << getpid() << "\n";
  // Executed by the process in logging mode
  if (LogManager::isLogMode()) { 
    LogManager::finishLogSession();
    wakeUpReplayer();
  } // Executed by process in charge of Recovery Phase 2
  else if (GLOBALSexecMode) {
    set<int> *setIds = extractSetNetTransportId(&attackExpressions);
    maliciousNetTransportId = extractMaliciousNetTransportId(setIds);
    cout << "recover: malicious net transport id: " << maliciousNetTransportId << "\n";
    // communicate malicious net transport id via pipe
    /*LogicalEndToEndTransport *netT = findNetTransport(maliciousNetTransportId);
    if (netT != NULL) {
      netT->print();
    }
    else {
      cout << "No net transport exists with Id: " << maliciousNetTransportId << "\n";
    }*/
    write(/*Instance()->*/pipeDescriptor[1], &(maliciousNetTransportId), sizeof(int));
    cout << "Wrote into pipe " << maliciousNetTransportId  << "\n";
    finishDACODAPhase();
    wakeUpReplayer(); // and die
  } 
  else if (isRecovering()) {
      initRecoveryPhase();
  } 
  else {
    cout << "Recovery cannot be initiated or continued. System is not in log nor DACODA nor recoveringContinuing execution in normal mode. mode.\n";
    exit(1);
  }
}

/**
 * Extracts network communication information (IP source and destiny, source port and destiny)
 * from the newly arrived ethernet frame. If the logical end-to-end transport is new, insert it
 * in the list of LogicalEndToEnd transport
 */
void RecoveryManager::extractLogicalEndToEndTransport(unsigned char *ethFrame) {
   
    //cout << "Inside  extractLogicalEndToEndTransport\n";

    int Offset;

    if (ethFrame[0xF])
    {
      Offset = 0x18;
    }
    else
    {
      Offset = 0x1a;
    }
	
    IPAddress *ipSource = new IPAddress(ethFrame[Offset], ethFrame[Offset + 1], 
                                   ethFrame[Offset + 2], ethFrame[Offset + 3]);
    IPAddress *ipDestiny = new IPAddress(ethFrame[Offset + 4], ethFrame[Offset + 5], 
                                   ethFrame[Offset + 6], ethFrame[Offset + 7]);  
    Bit16u portSource = (Bit16u) ethFrame[Offset + 8]*256+ ethFrame[Offset + 9];
    Bit16u portDestiny = (Bit16u) ethFrame[Offset + 10]*256+ethFrame[Offset + 11];

     LogicalEndToEndTransport *netTransport = getLogicalEndToEndTransport(ipSource, ipDestiny, 
                                             portSource, portDestiny);
   
     // just for USENIX experiments
 
    if (netTransport->equal(client)) {
      // cout << "Angara pkt\n";
       if ((recoveryMode) && ((logMode) || (!replayMode && !LogManager::isSemiReplayMode()))) {
         //cout << "Angara normal mode ou com log\n";
         clientPktTotal++;
       }
       if (logMode) {
         //cout << "Angara pkt logged\n";
         clientPktLogged++;
       }
       if (replayMode && isRecovering()) {
         //cout << "Angara pkt replay/recovering\n";
         clientPktReplay++;
       }
       if (LogManager::isSemiReplayMode()) {
         //cout << "Angara pkt semireplay\n";
         clientPktSemiReplay++; 
       }
     }
      setCurrentLogicalEndToEndTransport(netTransport);
    //cout << "Current Net Transport ID: " << netTransport->getId() << "\n";
}

/**
 * Adds to the list of logical end to end transport a new entry.
 */
void RecoveryManager::addLogicalEndToEndTransport(LogicalEndToEndTransport *netTransport) {
  
  netTransports.push_back(netTransport);
}

/**
 * Traverse the list of logical end-to-end transports to find whether or not there is an object 
 * with same attributes as passed as a parameter. If the object is found, return it. 
 * Otherwise return create the new object, insert it in the list and return it.
 */
LogicalEndToEndTransport *RecoveryManager::getLogicalEndToEndTransport(IPAddress *ipS, 
                                                               IPAddress *ipD, Bit16u portS, Bit16u portD) {

  // cout << "Inside getLogicalEndToEndTransport. Lista size: " << netTransports.size() <<  "\n";
   LogicalEndToEndTransport *netTransport = NULL;
   if (netTransports.empty()) { // list empty, just insert new element
      netTransport = new LogicalEndToEndTransport(ipS, ipD, portS, portD); 
      addLogicalEndToEndTransport(netTransport); 
   }
   else {  // Check if this already in the list
     list<LogicalEndToEndTransport*>::iterator it = netTransports.begin();
     while (it != netTransports.end()) {   
        if ((*it)->equal(ipS, ipD, portS, portD)) {
         netTransport = *it;
       }
       it++;
     }
     if (netTransport == NULL) { // New element
       netTransport = new LogicalEndToEndTransport(ipS, ipD, portS, portD); 
       addLogicalEndToEndTransport(netTransport); 
     }
   }
   
   return netTransport;
}

    
/**
 * Returns the current logical end to end transport communicating with our system
 */
void RecoveryManager::setCurrentLogicalEndToEndTransport(LogicalEndToEndTransport *netTransport) {

  currentNetTransport = netTransport;
}

/**
 *  Returns the ID of the current logical end to end transport communicating with our system
 */
int RecoveryManager::getCurrentLogicalEndToEndTransportId() {

  if (currentNetTransport != NULL) {
    return (currentNetTransport->getId());
  } 
  else {
    return -1;
  } 
}

void  RecoveryManager::setRecoveryOn(bool value) {
  
  recoveryOn = value;
}

bool  RecoveryManager::isRecoveryOn() {
  return recoveryOn;
}

void  RecoveryManager::setRecoveryMode(bool mode) {
  
  recoveryMode = mode;
}

bool  RecoveryManager::isRecoveryMode() {

  return recoveryMode;
}

void  RecoveryManager::setRecovering(bool value) {
  recovering = value;
}

bool  RecoveryManager::isRecovering() {
  return recovering;
}

   
LogicalEndToEndTransport *RecoveryManager::getCurrentLogicalEndToEndTransport() {
  return currentNetTransport;
}

/**
 * Searches in the list of netTransports for the netTransport with the id passes
 * as a parameter. If the object exists returns it. Otherwise return NULL.
 */
LogicalEndToEndTransport *RecoveryManager::findNetTransport(int id) {

  LogicalEndToEndTransport *netTransport;
  list<LogicalEndToEndTransport*>::iterator it = netTransports.begin();
 
//  cout << "Id: " << id << " findNetTransport\n"; 
  //cout << "Attack - Memory\n";
  while (it != netTransports.end()) {
    //cout << "entrou no while\n";
    netTransport = *it;
    if (netTransport->getId() == id) {
     // cout << "Igual-> Id: " << id << " netId: " << netTransport->getId() << "\n";
      //cout << "netTransport->getId()=>"; 
      //netTransport->print();
      return netTransport;
    } 
    it++;
  }
  return NULL; 
}

int RecoveryManager::getMaliciousNetTransportId() {

  return maliciousNetTransportId;
}
   
void RecoveryManager::setMaliciousNetTransportId(int value) {

  maliciousNetTransportId = value;
}

   
/**
 * From the list of expressions passed as a parameter generates a set of all net transport
 * id's associated with each expression through its labels 
 */

set<int> *RecoveryManager::extractSetNetTransportId(list<Expression*> *exps) {

  list<Expression*> *labels = new list<Expression*>;
  list<Expression*>::iterator it;
  list<Expression*>::iterator it2;
  Expression *exp;
  Label *label;
  set<int> *setId = new set<int>;

   cout << "Inside extractSetNetTransportId. Size of exps: " << exps->size() << "\n";
   it = exps->begin();
   while (it != exps->end()) {
     exp = *it;
     exp->getLabels(labels);
     cout << "Expression type: " << exp->Type << ". Depth: " << exp->MyDepth << ". Number of labels found: " 
     << labels->size() << "\n";
     if (labels != NULL) {
      it2 = labels->begin();
     // cout << "Antes de entrar no while\n";
      while (it2 != labels->end()) {
       // cout << "Entrou no while\n";
        label = (Label*)(*it2);
        //devFile << "Label Found #: " << label->GetNumber() << " netId: " 
        //<< label->getNetTransportId() << "\n";
        int labelNetId = label->getNetTransportId();
        //cout << "Vou chamar findNetTransport with Id: " << labelNetId << "\n";
        LogicalEndToEndTransport *netT = findNetTransport(labelNetId);
        if (netT != NULL) {
          //netT->print();
          setId->insert(netT->getId());
          //cout << "retornando setId";
         // return setId;
        }
        it2++;
      }
    }
    else {
      cout << "RecoveryManager::extractSetNetTransportId: The attack expression has no associated label\n";
      exit(1);
    }
   it++;
  }

  //devFile << "extractSetNetTransportId: Inspecionando o set ids a ser retornado: ";
  set<int>::iterator it3 = setId->begin();
  while(it3 != setId->end()) {
    int i = *it3;
  //  devFile << i;
    it3++;
  }
  //devFile << "\n";
  return setId;

}
 
/**
 * Returns the malicious net transport id from the set of net transport
 * id's passed as a parameter
 * Note: the semantic of this method needs to be understood better.
 * I would hope to find a set with just one element. But, what if a have
 * a set with more than one element? How to distinguish the malicious connection?
 */
int  RecoveryManager::extractMaliciousNetTransportId(set<int> *setId) {

  int maliciousId;

  set<int>::iterator it = setId->begin();
  while (it != setId->end()) {
    maliciousId = (*it);
    return maliciousId;
  }
  return 0;
}

 /**
 * Add an expression to the list of attack expressions
 */
 void RecoveryManager::addAttackExpression(Expression *exp) {

 // cout << "Inside addAttackExpression ";
  attackExpressions.push_back(exp);
  //cout << "size of list: " << attackExpressions.size() << "\n";

}
    
/**
 * Add all expressions from the list passed as a parameter to
 * the list of attack expressions
 */
void RecoveryManager::addListAttackExpressions(list<Expression*> *exps) {

 Expression *exp;

 list<Expression*>::iterator it = exps->begin();

 while (it != exps->end()) {
   exp = *it;
   attackExpressions.push_back(exp);
   it++;  
 }

}

void RecoveryManager::addSetNetTransportId(set<int> *setIds) {

  set<int>::iterator it = setIds->begin();
  while (it != setIds->end()) {
    int i = *it;
    maliciousNetTransportIds.insert(i);
    it++;
  }
}

/**
 * In this phase we do not process any event in the log file except network packet
 * from non-malicious connections. We continue not to send any packets to the outside 
 * world.
 */
void RecoveryManager::startSemiReplayPhase() {

   cout << "RecoveryManager::startSemiReplayPhase\n";
   //devFile << "RecoveryManager::startSemiReplayPhase\n";
   recoveryOn = false;
   recovering =false;
   LogManager::setSemiReplayMode(true);  
}


void RecoveryManager::finishSemiReplayPhase() {

  cout << "Ending semi-replay mode at tick " << bx_pc_system.time_ticks() << "\n";
  devFile << "Ending semi-replay mode at tick " << bx_pc_system.time_ticks() << "\n";
  LogManager::setSemiReplayMode(false);
  LogManager::Instance()->closeLogFile(READ_MODE);

  // just for USENIX experiments 
  printClientStat();

 /* cout << "Client packets total: " << clientPktTotal << "\n";
  cout << "Client packets during log: " << clientPktLogged << "\n";
  cout << "Client packets during replay: " << clientPktReplay << "\n";
  cout << "Client packets during semi-replay: " << clientPktSemiReplay << "\n";*/
  semiReplayFinished = true;

}
 
void RecoveryManager::setStartRecoverableCheckpoint(bool value) {

  startRecoverableCheckpoint = value;

}
    
bool RecoveryManager::isStartRecoverableCheckpoint() {

  return startRecoverableCheckpoint;
}

/**
 * Resets the malicious net transport Id so that the system has
 * no information about malicious net transport id's and accepts all
 * network packets.
 */
void RecoveryManager::resetMaliciousNetTransportId() {

  maliciousNetTransportId = -1;
}

/**
 * True if semi-replay phase happened but is finished
 */
bool RecoveryManager::isSemiReplayFinished() {
  
  return semiReplayFinished;
}

RecoveryManager::~RecoveryManager() {

}

void RecoveryManager::createPipe() {

 // create pipe
   if (pipe(pipeDescriptor) < 0) {
    cout << "RecoveryManager::RecoveryManager: Pipe could not be created\n";
    exit(1);
   }
}

void RecoveryManager::printClientStat() {
  //devFile << "Client packets total: " << clientPktTotal << "\n";
  //devFile << "Client packets during log: " << clientPktLogged << "\n";
  //devFile << "Client packets during replay: " << clientPktReplay << "\n";
  //devFile << "Client packets during semi-replay: " << clientPktSemiReplay << "\n";

}

#endif
