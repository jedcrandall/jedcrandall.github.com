/**
 * Log entry for in port events.
 * Author: Daniela
 * Date: 11/21/2005
 * Last update: 11/16/2006
 */
#ifndef __LOG_E_INPORT_H
#define __LOG_E_INPORT_H

#include <iostream>
#include <bitset>
using namespace std;

#include "log_entry.h"
#include "config.h"

#define STORAGE_REGISTER 0 // bytes read from port should be stored in register
#define STORAGE_MEM 1 // bytes read from port should be stored in memory
#define NUM_FLAGS 8 // we encode certain atributes as a 1 bit flag: integrity, num bytes, 
                    // and numBitsRegMemAddr

class LogEInPort : public LogEntry
{
  private:
    unsigned numBytes; // number of bytes read from port
    Bit32u bytes; // bytes read from buffer
    unsigned storageType;
    bx_address memAddr; // in case bytes should be stored in memory
    Bit8u integrity; // Minos integrity for the bytes
    Bit16u portAddr; // port address
    unsigned numBitsRegWithMemAddr;
#if BX_LOG_RECOVERY
    int netTransportId; // For NE2k inports, ID of the logical end to end transport
#endif
/**
 * We encode the following attributes as a one bite value: numBytes, storageType and integrity.
 * This encode has the goal of reducing the number of data written in the log file.
 * In the flags bitset each one of the bits has the following meaning:
 * 
 * Bit0: if set, numBytes = 1
 * Bit1: if set, numBytes = 2
 * Bit2: if set, numBytes = 4
 * Bit3: if set, storageType = STORAGE_MEM, if not set, storageType = STORAGE_REGISTER
 * For Bits 4, 5 and 6 the encoding should be interpreted as follows (Bit6 Bit5 Bit4):
 * 000: regWithAddr = 8
 * 001: regWithAdd = 16
 * 010: regWithAdd = 32
 * 100: regWithAdd = 64
 * Bit7: if set, integrity = 0xFF, if not set integrity = 0

 */
    //bitset<NUM_FLAGS> flags;
    bool checkFlags(bitset<NUM_FLAGS> flagsReceived);

  protected:
    enum Flags { numBytes1, numBytes2, numBytes4, storage, Bits16, Bits32, Bits64, integ  };

  public:
    LogEInPort();
    LogEInPort(LogEInPort *logEntry);
    void setNumBytes(unsigned num);
    unsigned getNumBytes();
    void setBytes(Bit32u buffer);
    Bit32u getBytes();
    void setStorageType(unsigned type);
    unsigned getStorageType();
    void setMemAddr(bx_address addr);
    bx_address getMemAddr();
    void setIntegrity(Bit8u integ);
    Bit8u getIntegrity();
    void setPortAddr(Bit16u addr);
    Bit16u getPortAddr();
    void setNumBitsRegWithMemAddr(unsigned numBits);
    unsigned getNumBitsRegWithMemAddr();
    Bit8u getFlags();
    void setFlags(Bit8u value);
#if BX_LOG_RECOVERY
    int getNetTransportId();
    void setNetTransportId(int value); 
#endif

    ~LogEInPort();
};
#endif
