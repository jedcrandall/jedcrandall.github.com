/* Log manager for in interrupt events.
 * Author: Daniela
 * Date: 11/23/2005
 * Last update: 05/10/2006
 */
#ifndef __LOG_M_INTERRUPT_H
#define __LOG_M_INTERRUPT_H

#include <iostream>
using namespace std;

#include "log_manager.h"
#include "log_e_interrupt.h"
#include "bochs.h"

#define LOG_IRQ_LINE 1000 // Irq line for logged interrupt events


class LogMInterrupt : public LogManager
{
  private:
    static LogMInterrupt* instance;

  protected:
     LogMInterrupt();

  public:
    static LogMInterrupt* Instance();
    static LogEInterrupt *readLoggedInterrupt(ifstream *logIn);
    static void writeLogEntry(LogEInterrupt *logEntry, ofstream *logFile);
    static void timerHandler(LogEInterrupt *logE);
    ~LogMInterrupt();
};

#endif
