/**
 * TCP Translator
 * Translates TCP sequence numbers, ack numbers and checksum
 * for recovery process 
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 01/22/2007
 * Last update: 03/05/2007 
 */
#if BX_LOG_RECOVERY

#include "tcp_translator.h"
//#include "bochs.h"
//#include <signal.h>
#include <fstream>
using namespace std;

// just for debug
extern ofstream devFile;

/**
 * Static members
 */
TCPTranslator* TCPTranslator::instance = 0;

/**
 * Constructor
 */
TCPTranslator::TCPTranslator() 
{
  cout << "TCPTranslator created.\n";
 } 

/**
 * Creates a singleton instance of this class.
 */
TCPTranslator* TCPTranslator::Instance()
{
  if (instance == 0) {
    instance = new TCPTranslator();
  }
  return instance;
}


bool TCPTranslator::hasActiveConnections() {

  if (!connections.empty()) {
    return true;
  } 
  else {
    return false;
  }
}

void TCPTranslator::processTCPSegment(TCPSegment *tcpSeg) {

  if (tcpSeg->getReceived()) {
    processTCPSegmentReceived(tcpSeg);
  }
  else {
    processTCPSegmentSent(tcpSeg);
  }
}

void TCPTranslator::processTCPSegmentReceived(TCPSegment *tcpSeg) {

  devFile << "processTCPSegmentReceived\n";
  if ((tcpSeg->getSYN()) && (!tcpSeg->getACK())) { // SYN
    processSYNReceived(tcpSeg);
  }
  else if ((tcpSeg->getSYN()) && (tcpSeg->getACK())) { // SYN ACK
    processSYNACKReceived(tcpSeg);
  }
  else if ((!tcpSeg->getSYN()) && (tcpSeg->getACK())) { // ACK
    processACKReceived(tcpSeg);
  }
  else if (tcpSeg->getFIN()) { // FIN
    processFINReceived(tcpSeg);
  }
  else if (tcpSeg->getRST()) { // RST
    processRSTReceived(tcpSeg);
  }
}
    
void TCPTranslator::processSYNReceived(TCPSegment *tcpSeg) {

  devFile << "processSYNReceived nao faco nada\n";
 /* TCPConnection *connection = findConnection(tcpSeg);
  if (connection == NULL) {
    connection = new TCPConnection(tcpSeg->getSrcIP(), tcpSeg->getDestIP(),
                                   tcpSeg->getSrcPort(), tcpSeg->getDestPort());
    connection->setClientInitiated(true);
    addConnection(connection);
  }
  connection->setState(SYN_SENT);
  connection->setClientISN((tcpSeg->getSequenceNumber())->toBit32u());*/
 
}

void TCPTranslator::processSYNACKReceived(TCPSegment *tcpSeg) {

   devFile << "Process SYNACK received \n";
    TCPConnection *connection = findConnection(tcpSeg);
  // if there is no connection associated, this means that this connection started before
  // TCPTranslator was invoked, so it is safe, we don't need to translate
  if (connection != NULL) {
      connection->setOldServerISN((tcpSeg->getACKNumber())->toBit32u() - 1);
      connection->setState(SYN_ACK);
      connection->computeOffset();
      translateReceived(tcpSeg, connection);
  }
     
}

void TCPTranslator::processACKReceived(TCPSegment *tcpSeg) {

  TCPConnection *connection = findConnection(tcpSeg);
  // if there is no connection associated, this means that this connection started before
  // TCPTranslator was invoked, so it is safe, we don't need to translate
  if (connection != NULL) {
    switch(connection->getState()) {      
      case SYN_ACK: { // process first ack from client
        devFile << "First ACK received from client\n";
        connection->setOldServerISN((tcpSeg->getACKNumber())->toBit32u() - 1);
        connection->setState(ESTABLISHED);
        connection->computeOffset();
        translateReceived(tcpSeg, connection);
      }

      case ESTABLISHED: {
        devFile << "ACK received from client while in state ESTABLISHED\n";
        translateReceived(tcpSeg, connection);
      }

      case LAST_ACK: {
        devFile << "Last ACK received from client.\n";
        translateReceived(tcpSeg, connection);
        removeConnection(connection);
      }
   
      default : {
        devFile << "Strange state in TCPTranslator::processACKReceived: " << connection->getState() << "\n";
        translateReceived(tcpSeg, connection);
      }
    } 
       
  } // if (connection != NULL)

}

void TCPTranslator::processFINReceived(TCPSegment *tcpSeg) {

  TCPConnection *connection = findConnection(tcpSeg);
  // if there is no connection associated, this means that this connection started before
  // TCPTranslator was invoked, so it is safe, we don't need to translate
  if (connection != NULL) {
    if(connection->getState() == ESTABLISHED) {
        devFile << "FIN received at state ESTABLISHED\n";
        connection->setState(CLOSE_WAIT);
        translateReceived(tcpSeg, connection);
    }
    else if (connection->getState() == FIN_WAIT) {
      devFile << "FIN received at state FIN_WAIT\n";
      connection->setState(TIME_WAIT);
      translateReceived(tcpSeg, connection);
    }
    else {
      devFile << "Strange state in  TCPTranslator::processFINReceived: " << connection->getState() << "\n";
      translateReceived(tcpSeg, connection);
    }
  }

}

void TCPTranslator::processRSTReceived(TCPSegment *tcpSeg) {

  TCPConnection *connection = findConnection(tcpSeg);
  // if there is no connection associated, this means that this connection started before
  // TCPTranslator was invoked, so it is safe, we don't need to translate
  if (connection != NULL) {
    devFile << "Receiving RST from client at state " << connection->getState() << ". Vai fechar a conexao\n";
    translateReceived(tcpSeg, connection);
    removeConnection(connection);
  }

}


void TCPTranslator::translateReceived(TCPSegment *tcpSeg, TCPConnection *conn) {

  devFile << "Translate received\n";
  Bit32u ackNumber = (tcpSeg->getACKNumber())->toBit32u();
  devFile << "ack number: " << ackNumber << "\n";
  Bit32u oldServerISN = conn->getOldServerISN();
  devFile << "old server ISN: " << oldServerISN << "\n";
  Bit32u newServerISN = conn->getNewServerISN();
  devFile << "new server ISN: " << newServerISN << "\n";
  Bit32u offset = conn->getOffset();
  devFile << "offset: " << offset << "\n";


  if (oldServerISN > newServerISN) {
     devFile << "oldServerISN > newServerISN ackNumber -= offset: \n";
     ackNumber -= offset;
     devFile << "Ack number now is: " << ackNumber << "\n";
  }
  else if (oldServerISN < newServerISN) {
    devFile << "oldServerISN < newServerISN ackNumber += offset: \n";
    ackNumber += offset;
  }
  tcpSeg->setACKNumber(ackNumber);
  tcpSeg->updateChecksum();
}

void TCPTranslator::translateSent(TCPSegment *tcpSeg, TCPConnection *conn) {

  devFile << "Translate sent\n";
  Bit32u seqNumber = (tcpSeg->getSequenceNumber())->toBit32u();
  Bit32u oldServerISN = conn->getOldServerISN();
  Bit32u newServerISN = conn->getNewServerISN();
  Bit32u offset = conn->getOffset();

  if (oldServerISN > newServerISN) {
    seqNumber += offset;
  }
  else if (oldServerISN < newServerISN) {
    seqNumber -= offset;
  }
  tcpSeg->setSequenceNumber(seqNumber);
  tcpSeg->updateChecksum();
}


void TCPTranslator::processTCPSegmentSent(TCPSegment *tcpSeg) {

 devFile << "processTCPSegmentSent\n";
  if ((tcpSeg->getSYN()) && (!tcpSeg->getACK())) { // SYN
    processSYNSent(tcpSeg);
  }
  else if ((tcpSeg->getSYN()) && (tcpSeg->getACK())) { // SYN ACK
    processSYNACKSent(tcpSeg);
  }
  else if (tcpSeg->getACK()) {
    processACKSent(tcpSeg);
  }
  else if (tcpSeg->getFIN()) {
    processFINSent(tcpSeg);
  }
  else if(tcpSeg->getRST()) {
    processRSTSent(tcpSeg);
  }
  else {
    cout << "Error in TCPTranslator::processTCPSegmentSent: segment could not be processed\n";
    exit(1);
  }
}

void TCPTranslator::processSYNSent(TCPSegment *tcpSeg) {

  // Don't need to worry about translation because a SYN from server starts at semi-replay
  // and semi-replay packets are never sent

  // We only create new connections for SYN's or SYNACK's sent by server
  // during semireplay phase
  if (LogManager::isSemiReplayMode()) {
    devFile << "SYN sent by server during replay mode \n";
    TCPConnection *connection = findConnection(tcpSeg);
    if (connection == NULL) {
      connection = new TCPConnection(tcpSeg->getSrcIP(), tcpSeg->getDestIP(),
                                   tcpSeg->getSrcPort(), tcpSeg->getDestPort());
      addConnection(connection);
    }
    connection->setClientInitiated(false);
    connection->setState(SYN_SENT);
    connection->setNewServerISN((tcpSeg->getSequenceNumber())->toBit32u());
  }
}

void TCPTranslator::processSYNACKSent(TCPSegment *tcpSeg) {

  // We only create new connections for SYN's or SYNACK's sent by server
  // during semireplay phase
  if (LogManager::isSemiReplayMode()) {
    devFile << "SYN ACK sent during replay mode\n";
    //We don't need to worry about translating because during semireplay packets are not sent
    TCPConnection *connection = findConnection(tcpSeg);
    if (connection == NULL) {
        connection = new TCPConnection(tcpSeg->getSrcIP(), tcpSeg->getDestIP(),
                                   tcpSeg->getSrcPort(), tcpSeg->getDestPort());
        connection->setClientInitiated(true);
        addConnection(connection);
    }
    connection->setNewServerISN((tcpSeg->getSequenceNumber())->toBit32u());
    connection->setState(SYN_ACK);
 }
}

void TCPTranslator::processACKSent(TCPSegment *tcpSeg) {

   TCPConnection *connection = findConnection(tcpSeg);
  // if there is no connection associated, this means that this connection started before
  // TCPTranslator was invoked, so it is safe, we don't need to translate
  if (connection != NULL) {
    if (connection->getState() == SYN_ACK) {
      devFile << "First ack sent by server \n";
      connection->setState(ESTABLISHED);
      translateSent(tcpSeg, connection);
    }
    else if (connection->getState() == TIME_WAIT) {
       devFile << "ACK sent to client at state TIME_WAIT. Conexao sera removida \n";
       translateSent(tcpSeg, connection);
       removeConnection(connection);
    }
    else {
        devFile << "ACK sent to client at state: " << connection->getState() << "\n";
        translateSent(tcpSeg, connection);
    }       
  } // if (connection != NULL)

}

void TCPTranslator::processFINSent(TCPSegment *tcpSeg) {

  TCPConnection *connection = findConnection(tcpSeg);
  // if there is no connection associated, this means that this connection started before
  // TCPTranslator was invoked, so it is safe, we don't need to translate
  if (connection != NULL) {
    if(connection->getState() == ESTABLISHED) {
        devFile << "Processing FIN sent while in state ESTABLISHED\n";
        connection->setState(FIN_WAIT);
        translateSent(tcpSeg, connection);
    }
    else if (connection->getState() == CLOSE_WAIT) {
      devFile << "Processing FIN sent while in state CLOSE_WAIT\n";
      connection->setState(LAST_ACK);
      translateSent(tcpSeg, connection);
    }
    else {
      devFile << "Strange initial state in  TCPTranslator::processFINSent: " << connection->getState() << "\n";
      translateSent(tcpSeg, connection);
    }
  }

}

void TCPTranslator::processRSTSent(TCPSegment *tcpSeg) {

  TCPConnection *connection = findConnection(tcpSeg);
  // if there is no connection associated, this means that this connection started before
  // TCPTranslator was invoked, so it is safe, we don't need to translate
  if (connection != NULL) {
    devFile << "Processing RST sent while in state : " << connection->getState() << "\n";
    translateSent(tcpSeg, connection);
    removeConnection(connection);
  }


}

/**
 * Adds a new connection to the list of connections
 */
void TCPTranslator::addConnection(TCPConnection *connection) {
 
  devFile << "Adding connection\n"; 
  connections.push_back(connection);
}

/**
 * Remove a connection from the list
 */
void TCPTranslator::removeConnection(TCPConnection *connection) {

    list<TCPConnection*>::iterator it = connections.begin();
    while (it != connections.end()) {   
        if ((*it)->equal(connection)) {
          connections.erase(it);
          devFile << "Removing connection\n";
          return;
        }
        it++;
    }
    cout << "Error in  TCPConnection::removeConnection: could not remove connection: \n";
    exit(1);

} 

/**
 * Traverse the list of connections to find whether or not there is a connection 
 * with same attributes as passed as a parameter. If the object is found, return it. 
 * Otherwise return null.
 */

TCPConnection *TCPTranslator::findConnection(TCPSegment *tcpSeg) {

  
   TCPConnection *connection = NULL;
   if (connections.empty()) { // list empty, just insert new element
     return NULL;      
   }
   else {  // Check if this already in the list
     list<TCPConnection*>::iterator it = connections.begin();
     while (it != connections.end()) {   
        if ((*it)->equal(tcpSeg->getSrcIP(), tcpSeg->getDestIP(), tcpSeg->getSrcPort(), tcpSeg->getDestPort())) {
          connection = *it;
          devFile << "Found connection: ";
          connection->print();
          return connection;
        }
        it++;
     }
   }
   return connection;
}

TCPTranslator::~TCPTranslator() {

}




#endif
