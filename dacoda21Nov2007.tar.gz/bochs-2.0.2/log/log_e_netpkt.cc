/**
 * Log entry for the arrival of a network packet.
 *
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 05/02/2005
 * Last update: 03/05/2007 
 */

#include "config.h"
#if BX_LOG_REPLAY

#include <iostream>
using namespace std;

#include "log_e_netpkt.h"

LogENetPkt::LogENetPkt()
{
   //printf("LogENetPkt constructor\n");
    bufferLen = 0;
    idNumber = idNumberGenerator++;

}

LogENetPkt::LogENetPkt(LogENetPkt *logEntry) 
{
  setTick(logEntry->getTick());
  setBufferLen(logEntry->getBufferLen());
  setBuffer(logEntry->getBuffer());
} 

void LogENetPkt::setBufferLen(unsigned value) {
  bufferLen = value;
}  

unsigned LogENetPkt::getBufferLen() {
  return bufferLen;
}

/**
 * Buffer length must be set first, otherwise this
 * method will not produce the intended results.
 */
void LogENetPkt::setBuffer(unsigned char *buf) {
 
  unsigned len = getBufferLen();
  if (len > 0) { 
    memcpy(buffer, buf, len);
  }
  else {
    cout << "LogENetPkt::setBuffer: trying to set buffer with buffer len: " <<  len << "\n";
    exit(1);
  }
}
    

unsigned char *LogENetPkt::getBuffer() {
  return buffer;
}    

LogENetPkt::~LogENetPkt()
{
   //printf("LogENetPkt destructor\n");

}

#endif
