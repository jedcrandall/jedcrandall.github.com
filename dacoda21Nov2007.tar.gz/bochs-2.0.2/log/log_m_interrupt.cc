/* Log manager for in interrupt events.
 * Author: Daniela
 * Date: 11/23/2005
 * Last update: 03/05/2007
 */
#include "config.h"

#if BX_LOG_REPLAY

#include "log_m_interrupt.h"
#include "log_e_interrupt.h"

extern bx_pic_c *thePic;
extern int logMode;
extern int replayMode; 

LogMInterrupt* LogMInterrupt::instance = 0;

// Daniela - just for debugging
#include <iostream>
#include <fstream>
ofstream inteFile; 
extern ofstream devFile;

LogMInterrupt::LogMInterrupt()
{
   printf("LogMInterrupt constructor\n");
}

/**
 * Creates a singleton instance of this class.
 */
LogMInterrupt* LogMInterrupt::Instance()
{
  if (instance == 0) {
    instance = new LogMInterrupt();
  }
  return instance;
}


/**
 * Treat an interrupt event 
 */
void LogMInterrupt::timerHandler(LogEInterrupt *log)
{

#if BX_LOG_RECOVERY
   // Remove event from list of logEntries without processing it
   if (LogManager::isSemiReplayMode()) {
     LogEInterrupt *logEntry = (LogEInterrupt*) LogManager::Instance()->getCurrentLogEntry();
     delete logEntry;
     return;
   }
#endif
  if (replayMode) {
   /* if ((bx_pc_system.time_ticks() >= TICK_MIN) && (bx_pc_system.time_ticks() <= TICK_MAX)) {
        inteFile << "Current entry tick: " << log->getTick() << " Raise: " << log->getRaise() << 
        " Irq_no: " << log->getIRQNum() << "\n";
      }*/
    if (log->getRaise() == 1 ) {
      //if ((bx_pc_system.time_ticks() >= TICK_MIN) && (bx_pc_system.time_ticks() <= TICK_MAX)) 
        //inteFile << "Raise == 1, calling raise_irq\n";
      DEV_pic_raise_irq(LOG_IRQ_LINE);  
    } 
    else if (log->getRaise() == 0){
      //if ((bx_pc_system.time_ticks() >= TICK_MIN) && (bx_pc_system.time_ticks() <= TICK_MAX)) 
        //inteFile << "Raise == 0, calling lower irq\n";
      DEV_pic_lower_irq(LOG_IRQ_LINE);  
    }
    else {
      cout << "LogMInterrupt::timerInterruptHandler: wrong value for raise field: " << log->getRaise() << "\n";
      exit(1);
    }
  }
}


LogEInterrupt *LogMInterrupt::readLoggedInterrupt(ifstream *logIn)
{
  LogEInterrupt *logE;
                               
  logE = new LogEInterrupt();
   
  Bit8u flagsValue;
  (*logIn).read((char *) &flagsValue, sizeof(Bit8u)); 
  //devFile << (unsigned)flagsValue << endl;
  //cout << "Flags value: " << flagsValue << " (unsigned):  " << (unsigned)flagsValue << "\n";  
  logE->setFlags(flagsValue-33); 
  return logE;
}


/**
 * Write the LogEInterrupt passed as a parameter in the log file 
 * also passed as a parameter
 */
void LogMInterrupt::writeLogEntry(LogEInterrupt *logEntry, ofstream *logFile)
{
   Bit8u flagsValue = logEntry->getFlags() + 33;

   //devFile << (unsigned) flagsValue << " ";//endl;
   (*logFile).write((char *) &flagsValue, sizeof(Bit8u));

}

LogMInterrupt::~LogMInterrupt()
{
   //printf("LogMInterrupt destructor\n");
}

#endif
