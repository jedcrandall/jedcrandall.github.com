/**
 * Log manager for handling interrupt events.
 * Author: Daniela Alvim Seabra de Oliveira
 * Date: 08/05/2006
 * Last update: 03/05/2007 
 */
#include "config.h"

#if BX_LOG_REPLAY

#include "log_m_handleinterrupt.h"
#include "log_e_handleinterrupt.h"

//extern int logMode;
extern int replayMode; 

LogMHandleInterrupt* LogMHandleInterrupt::instance = 0;
bool LogMHandleInterrupt::isAsyncEventHandled = true;
bool LogMHandleInterrupt::isInterruptHandled = false;

LogMHandleInterrupt::LogMHandleInterrupt()
{
   printf("LogMHandleInterrupt constructor\n");
}

/**
 * Creates a singleton instance of this class.
 */
LogMHandleInterrupt* LogMHandleInterrupt::Instance()
{
  if (instance == 0) {
    instance = new LogMHandleInterrupt();
  }
  return instance;
}


/**
 * Treat the handling of an interrupt event 
 */
void LogMHandleInterrupt::timerHandler()
{
  LogEHandleInterrupt *logEntry = (LogEHandleInterrupt*) LogManager::Instance()->getCurrentLogEntry();
  if (replayMode) {
    /* if (LogManager::isSemiReplayMode()) {
     cout << "Treating handle interrupt event\n";
     }*/
    //cout << "Interrupt treated at " << bx_pc_system.time_ticks() << "\n";  
   // LogEHandleInterrupt *logEntry = (LogEHandleInterrupt*) LogManager::Instance()->getCurrentLogEntry();
    isAsyncEventHandled = true;
  /*if (replayMode) {
    LogManager::Instance()->prepareNextInterruptEvent();
  }*/
  }
  delete logEntry;
}



void LogMHandleInterrupt::setIsAsyncEventHandled(bool value) {
  isAsyncEventHandled = value;
}
    

bool LogMHandleInterrupt::getIsAsyncEventHandled() {
  return isAsyncEventHandled;
}

void LogMHandleInterrupt::setIsInterruptHandled(bool value) {
  isInterruptHandled = value;
}
    

bool LogMHandleInterrupt::getIsInterruptHandled() {
  return isInterruptHandled;
}


LogMHandleInterrupt::~LogMHandleInterrupt()
{
   //printf("LogMHandleInterrupt destructor\n");
}

#endif
