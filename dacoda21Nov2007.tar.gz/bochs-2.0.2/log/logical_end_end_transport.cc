/**
 * Represents a logical end to end transport which can be a TCP connection or
 * a logical UDP transport. 
 * Date: 11/10/2006
 * Last update: 03/05/2007 
 */
#include "config.h"

#if BX_LOG_REPLAY

#include "logical_end_end_transport.h"
#include "bochs.h"
#include <fstream>
using namespace std;

// just for debug
extern ofstream devFile;


/**
 * Static members
 */
int LogicalEndToEndTransport::idNumberGenerator = 1;


/**
 * Constructor
 */
LogicalEndToEndTransport::LogicalEndToEndTransport(IPAddress *ipS, IPAddress *ipD, Bit16u portS, Bit16u portD) {
  
  id = idNumberGenerator;
  ipSource = ipS;
  ipDestiny = ipD;
  portSource = portS;
  portDestiny = portD; 
  idNumberGenerator++;

}
    
int LogicalEndToEndTransport::getId() {
  
  return id;
}
    

/**
 * Returns true is the information passed as a parameter corresponds to this object and
 * false otherwise
 */
bool LogicalEndToEndTransport::equal(IPAddress *ipS, IPAddress *ipD, Bit16u portS, Bit16u portD) {

  if ((ipSource->equal(ipS)) && (ipDestiny->equal(ipD)) /*&& (portSource == portS)*/ && (portDestiny == portD)) {
    return true;
  }
  else {
    return false;
  }
}

bool LogicalEndToEndTransport::equal(LogicalEndToEndTransport *object) {

  return (this->equal(object->getIPAddressSource(), object->getIPAddressDestiny(),
      object->getPortSource(), object->getPortDestiny()));
}

 
IPAddress *LogicalEndToEndTransport::getIPAddressSource() {
  return ipSource;
}
    
IPAddress *LogicalEndToEndTransport::getIPAddressDestiny() {
  return ipDestiny;
}
    

Bit16u LogicalEndToEndTransport::getPortSource() {
  return portSource;
}
    

Bit16u LogicalEndToEndTransport::getPortDestiny() {
  return portDestiny;
}

void LogicalEndToEndTransport::print() {
  ipSource->print();
  devFile << " to ";
  ipDestiny->print();
  devFile << " " << portSource << " " << portDestiny << "\n";
}
/**
 * Destructor
 */   
LogicalEndToEndTransport::~LogicalEndToEndTransport() {

}


/**
 * Class IPAdress
 */

/**
 * Constructor
 */
IPAddress::IPAddress(Bit8u p1, Bit8u p2, Bit8u p3, Bit8u p4) {

  part1 = p1;
  part2 = p2;
  part3 = p3;
  part4 = p4;
}

/**
 * Return an integer representing the part of an IP address passed as a parameter
 */
Bit8u IPAddress::getPart(Bit8u num) {

  switch(num) {

    case 1:
      return part1;
      
    case 2:
      return part2;
   
    case 3:
      return part3;

    case 4:
      return part4;

  }
}
/**
 *  Returns true if the IPAdress passed as a parameter is equal to
 * the IPAddress object invoking this method.
 */
bool IPAddress::equal(IPAddress *ipA) {

  if ( (part1 == ipA->getPart(1)) && (part2 == ipA->getPart(2)) &&
       (part3 == ipA->getPart(3)) && part4 == ipA->getPart(4) ) {
    return true;
  } 
  else {
    return false;
  }
}

void IPAddress::print() {
  
  devFile << (unsigned) part1 << "." << (unsigned) part2 << "." << (unsigned )part3 
  << "." << (unsigned) part4;
}

/**
 * Convert the IP address to a Bit33u number
 *
 */
Bit32u IPAddress::toULong() {
  
  return (Bit32u) ((part1 * 16772216) + (part2 * 65536) + (part3 * 256) + part4);

} 
/**
 *  Destructor
 */
IPAddress::~IPAddress() {


}
#endif
