/////////////////////////////////////////////////////////////////////////
// $Id: data_xfer8.cc,v 1.14 2002/10/25 18:26:27 sshwarts Exp $
/////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2001  MandrakeSoft S.A.
//
//    MandrakeSoft S.A.
//    43, rue d'Aboukir
//    75002 Paris - France
//    http://www.linux-mandrake.com/
//    http://www.mandrakesoft.com/
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA






#define NEED_CPU_REG_SHORTCUTS 1
#include "bochs.h"
#define LOG_THIS BX_CPU_THIS_PTR


  void
BX_CPU_C::MOV_RLIb(bxInstruction_c *i)
{
  BX_CPU_THIS_PTR gen_reg[i->b1() & 0x03].word.byte.rl = i->Ib();
  //BX_WRITE_8BIT_REG_INTEGRITY(i->b1() & 0x03, IMMEDIATE_INTEGRITY);
  BX_WRITE_32BIT_REG_INTEGRITY(i->b1() & 0x03, IMMEDIATE_INTEGRITY);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  	TheLabels.WriteSymbolicRegister(i->b1() & 0x03, 0, NULL);
#endif
}

  void
BX_CPU_C::MOV_RHIb(bxInstruction_c *i)
{
  BX_CPU_THIS_PTR gen_reg[i->b1() & 0x03].word.byte.rh = i->Ib();
  //BX_WRITE_8BIT_REG_INTEGRITY(i->b1() & 0x03, IMMEDIATE_INTEGRITY);
  BX_WRITE_32BIT_REG_INTEGRITY(i->b1() & 0x03, IMMEDIATE_INTEGRITY);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  	TheLabels.WriteSymbolicRegister(i->b1() & 0x03, 1, NULL);
#endif
}


  void
BX_CPU_C::MOV_EEbGb(bxInstruction_c *i)
{
  Bit8u op2;
  Bit8u op2_integrity;

  op2 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
#if BX_DEBUGGER
  Expression *Eop2;
  if (BX_CPU_THIS_PTR sexecmode)
  	Eop2 = MakeACopyOf(TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1));
#endif

  op2_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());

/*  // This is where the high integrity thing is written
    if ((RMAddr(i) & 0xFFFFFF00) == 0xbfffe800)
    	//if (op2_integrity)
		//if (op2 == 0x08 || op2 == 0x05 || op2 == 0xcc || op2 == 0xf4)
		if (op2 == 0x08 || op2 == 0x13 || op2 == 0x8d || op2 == 0xe0)
			printf("Reg is %d, op2 is 0x%02x @ integ %d\n", i->nnn(), op2, op2_integrity);*/

#if BX_DEBUGGER
	if (BX_CPU_THIS_PTR sexecmode)
	{
		if (BX_CPU_THIS_PTR RMAddr_expression != NULL)
		{
			Expression *Etemp = NULL;
			Etemp = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Eop2);
			//if (Eop2 != NULL) delete Eop2;
			Eop2 = Etemp;
		}

	}
#endif

  write_virtual_byte(i->seg(), RMAddr(i), &op2, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
	write_virtual_expression(i->seg(), RMAddr(i), Eop2);
#endif
}

  void
BX_CPU_C::MOV_EGbGb(bxInstruction_c *i)
{
  Bit8u op2;
  Bit8u op2_integrity;

  op2 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
#if BX_DEBUGGER
  Expression *Eop2;
  if (BX_CPU_THIS_PTR sexecmode)
  	Eop2 = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
#endif
  op2_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());

  BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), op2);
  BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, MakeACopyOf(Eop2));
#endif

}


  void
BX_CPU_C::MOV_GbEEb(bxInstruction_c *i)
{
  Bit8u op2;
  Bit8u op2_integrity;

  read_virtual_byte(i->seg(), RMAddr(i), &op2, &op2_integrity);
#if BX_DEBUGGER
  Expression *Eop2;
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Eop2);
	if (BX_CPU_THIS_PTR RMAddr_expression != NULL)
	{
		Eop2 = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Eop2);
	}

  }
#endif


  BX_WRITE_8BIT_REGx(i->nnn(), i->extend8bitL(), op2);
  BX_WRITE_8BIT_REG_INTEGRITY(i->nnn(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  	TheLabels.WriteSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1, MakeACopyOf(Eop2));
#endif
}

  void
BX_CPU_C::MOV_GbEGb(bxInstruction_c *i)
{
  Bit8u op2;
  Bit8u op2_integrity;

  op2 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
#if BX_DEBUGGER
  Expression *Eop2;
  if (BX_CPU_THIS_PTR sexecmode)
  	Eop2 = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
#endif
  op2_integrity = BX_READ_8BIT_INTEGRITY(i->rm());

  BX_WRITE_8BIT_REGx(i->nnn(), i->extend8bitL(), op2);
  BX_WRITE_8BIT_REG_INTEGRITY(i->nnn(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  	TheLabels.WriteSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1, MakeACopyOf(Eop2));
#endif
}



  void
BX_CPU_C::MOV_ALOb(bxInstruction_c *i)
{
  Bit8u  temp_8;
  bx_address addr;
  Bit8u temp_8_integrity;
#if BX_DEBUGGER
  Expression *Etemp8;
#endif

  addr = i->Id();

  /* read from memory address */
  if (!BX_NULL_SEG_REG(i->seg())) {
    BX_CPU_THIS_PTR RMAddr_integrity = 0xFF;
    read_virtual_byte(i->seg(), addr, &temp_8, &temp_8_integrity);
    /*if (addr != 0xFF)
    	temp_8_integrity = 0x00;*/
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  	read_virtual_expression(i->seg(), addr, &Etemp8);
#endif
  }
  else {
    BX_CPU_THIS_PTR RMAddr_integrity = 0xFF;
    read_virtual_byte(BX_SEG_REG_DS, addr, &temp_8, &temp_8_integrity);
    /*if (addr != 0xFF)
    	temp_8_integrity = 0x00;*/
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  	read_virtual_expression(BX_SEG_REG_DS, addr, &Etemp8);
#endif
    }


  /* write to register */
  AL = temp_8;
  //LVAL_EAX_INTEGRITY = temp_8_integrity;
  BX_WRITE_8BIT_REG_INTEGRITY(0, /*0*/ temp_8_integrity);
  //BX_WRITE_32BIT_REG_INTEGRITY(0, /*0*/ temp_8_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  	TheLabels.WriteSymbolicRegister(0, 0, MakeACopyOf(Etemp8));
#endif

}


  void
BX_CPU_C::MOV_ObAL(bxInstruction_c *i)
{
  Bit8u  temp_8;
  bx_address addr;
  Bit8u temp_8_integrity;
#if BX_DEBUGGER
  Expression *Etemp8;
#endif

  addr = i->Id();

  /* read from register */
  temp_8 = AL;
  temp_8_integrity = BX_READ_8BIT_INTEGRITY(0);//EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  	Etemp8 = TheLabels.ReadSymbolicRegister(0, 0);
#endif

  /* write to memory address */
  if (!BX_NULL_SEG_REG(i->seg())) {
    write_virtual_byte(i->seg(), addr, &temp_8, &temp_8_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  	write_virtual_expression(i->seg(), addr, MakeACopyOf(Etemp8));
#endif
    }
  else {
    write_virtual_byte(BX_SEG_REG_DS, addr, &temp_8, &temp_8_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  	write_virtual_expression(BX_SEG_REG_DS, addr, MakeACopyOf(Etemp8));
#endif
    }
}


  void
BX_CPU_C::MOV_EbIb(bxInstruction_c *i)
{
  Bit8u op2;
  Bit8u op2_integrity;

  op2 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY; /**/ /* Here's the bad boy right here */

  /* now write op2 back to destination */
  if (i->modC0()) {
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), op2);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, NULL);
#endif
    }
  else {
    //op2_integrity = 0;
    write_virtual_byte(i->seg(), RMAddr(i), &op2, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  	write_virtual_expression(i->seg(), RMAddr(i), NULL);
#endif
    }
}



  void
BX_CPU_C::XLAT(bxInstruction_c *i)
{
  Bit32u offset_32;
  Bit8u  al;
  Bit8u al_integrity;
  Expression *EBXExpr = NULL;
  Expression *ALExpr = NULL;
  Expression *OffsetExpr = NULL;


#if BX_CPU_LEVEL >= 3
  if (i->as32L()) {
    offset_32 = EBX + AL;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	EBXExpr = (Expression *) MakeNewQuadReg(3);
	ALExpr = TheLabels.ReadSymbolicRegister(0, 0);
	OffsetExpr = (Expression *) new Operation(EBXExpr, ALExpr, "ADDEBXALFORXLAT");
	//if (EBXExpr != NULL) delete EBXExpr;
  }
#endif
    }
  else
#endif /* BX_CPU_LEVEL >= 3 */
    {
    offset_32 = BX + AL;
    }

  if (!BX_NULL_SEG_REG(i->seg())) {
    BX_CPU_THIS_PTR RMAddr_integrity = low_water_mark(al_integrity,  EBX_INTEGRITY, INTEG_BYTE, INTEG_DOUBLE);
    read_virtual_byte(i->seg(), offset_32, &al, &al_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), offset_32, &ALExpr);
	ALExpr = (Expression *) new Lookup(OffsetExpr, ALExpr);
  }
#endif
    }
  else {
    BX_CPU_THIS_PTR RMAddr_integrity = low_water_mark(al_integrity,  EBX_INTEGRITY, INTEG_BYTE, INTEG_DOUBLE);
    read_virtual_byte(BX_SEG_REG_DS, offset_32, &al, &al_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(BX_SEG_REG_DS, offset_32, &ALExpr);
	ALExpr = (Expression *) new Lookup(OffsetExpr, ALExpr);
  }
#endif
    }
  AL = al;
  //LVAL_EAX_INTEGRITY = al_integrity;
  BX_WRITE_8BIT_REG_INTEGRITY(0, al_integrity);
  //BX_WRITE_32BIT_REG_INTEGRITY(0, al_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(0, 0, ALExpr);
  }
#endif
}

  void
BX_CPU_C::XCHG_EbGb(bxInstruction_c *i)
{
  Bit8u op2, op1;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op2Expr = NULL;
  Expression *Op1Expr = NULL;

  /* op2 is a register, op2_addr is an index of a register */
  op2 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op2_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	Op2Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif
  /* op1 is a register or memory reference */
  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), op2);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, MakeACopyOf(Op2Expr));
  }
#endif
    }
  else {
    /* pointer, segment address pair */
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
	if (BX_CPU_THIS_PTR RMAddr_expression != NULL)
	{
		Op1Expr = (Expression *) new Lookup(BX_CPU_THIS_PTR RMAddr_expression, Op1Expr);
	}
  }
#endif
    Write_RMW_virtual_byte(op2, op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	//if (Op1Expr != NULL)
	//	BX_PANIC(("Don't know how to RMW write an expression"));
	write_virtual_expression(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
    }

  BX_WRITE_8BIT_REGx(i->nnn(), i->extend8bitL(), op1);
  BX_WRITE_8BIT_REG_INTEGRITY(i->nnn(), op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	TheLabels.WriteSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1, MakeACopyOf(Op1Expr));
  }
#endif

}
