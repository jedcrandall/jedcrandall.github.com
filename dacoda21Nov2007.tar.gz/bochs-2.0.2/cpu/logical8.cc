/////////////////////////////////////////////////////////////////////////
// $Id: logical8.cc,v 1.21 2002/10/25 18:26:28 sshwarts Exp $
/////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2001  MandrakeSoft S.A.
//
//    MandrakeSoft S.A.
//    43, rue d'Aboukir
//    75002 Paris - France
//    http://www.linux-mandrake.com/
//    http://www.mandrakesoft.com/
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA






#define NEED_CPU_REG_SHORTCUTS 1
#include "bochs.h"
#define LOG_THIS BX_CPU_THIS_PTR



  void
BX_CPU_C::XOR_EbGb(bxInstruction_c *i)
{
  Bit8u op2, op1, result;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op2 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op2_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    result = op1 ^ op2;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XOR_EbGb");
  }
#endif
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), result);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, LogicalExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    result = op1 ^ op2;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XOR_EbGb");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
    Write_RMW_virtual_byte(result, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	write_virtual_expression(i->seg(), RMAddr(i), LogicalExpr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_8(op1, op2, result, BX_INSTR_XOR8);
}

  void
BX_CPU_C::XOR_GbEb(bxInstruction_c *i)
{
  Bit8u op1, op2, result;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op1 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op1_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op2 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op2_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    }
  else {
    read_virtual_byte(i->seg(), RMAddr(i), &op2, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op2Expr);
  }
#endif
    }

  result = op1 ^ op2;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != Op2Expr)
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XOR_GbEb");
	else
		LogicalExpr = NULL;
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

  BX_WRITE_8BIT_REGx(i->nnn(), i->extend8bitL(), result);
  BX_WRITE_8BIT_REG_INTEGRITY(i->nnn(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1, LogicalExpr);
  }
#endif

  SET_FLAGS_OSZAPC_8(op1, op2, result, BX_INSTR_XOR8);
}


  void
BX_CPU_C::XOR_ALIb(bxInstruction_c *i)
{
  Bit8u op1, op2, sum;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op1 = AL;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(0, 0);
  }
#endif
  op2 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) new Constant(i->Ib());
  }
#endif

  sum = op1 ^ op2;
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XOR_ALIb");
	else
	{
		LogicalExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif

  AL = sum;
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(0, 0, LogicalExpr);
  }
#endif

  SET_FLAGS_OSZAPC_8(op1, op2, sum, BX_INSTR_XOR8);
}


  void
BX_CPU_C::XOR_EbIb(bxInstruction_c *i)
{
  Bit8u op2, op1, result;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op2 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) new Constant(i->Ib());
  }
#endif

  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    result = op1 ^ op2;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XOR_EbIb");
	else
	{
		LogicalExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), result);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, LogicalExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    result = op1 ^ op2;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XOR_EbIb");
	else
	{
		LogicalExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif
    Write_RMW_virtual_byte(result, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	write_virtual_expression(i->seg(), RMAddr(i), LogicalExpr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_8(op1, op2, result, BX_INSTR_XOR8);
}



  void
BX_CPU_C::OR_EbIb(bxInstruction_c *i)
{
  Bit8u op2, op1, result;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op2 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) new Constant(i->Ib());
  }
#endif

  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    result = op1 | op2;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "OR_EbIb");
	else
	{
		LogicalExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), result);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, LogicalExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    result = op1 | op2;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "OR_EbIb");
	else
	{
		LogicalExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif
    Write_RMW_virtual_byte(result, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	write_virtual_expression(i->seg(), RMAddr(i), LogicalExpr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_8(op1, op2, result, BX_INSTR_OR8);
}


  void
BX_CPU_C::NOT_Eb(bxInstruction_c *i)
{
  Bit8u op1_8, result_8;
  Bit8u result_integrity;
  Bit8u op1_integrity;
  Expression *Op1Expr, *NotExpr;

  if (i->modC0()) {
    op1_8 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    result_8 = ~op1_8;
    result_integrity = op1_integrity;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	NotExpr = (Expression *) new Operation(Op1Expr, NULL, "NOT_Eb");
  }
#endif
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), result_8);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, NotExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1_8, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    result_8 = ~op1_8;
    result_integrity = op1_integrity;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	NotExpr = (Expression *) new Operation(Op1Expr, NULL, "NOT_Eb");
  }
#endif
    Write_RMW_virtual_byte(result_8, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	write_virtual_expression(i->seg(), RMAddr(i), NotExpr);
  }
#endif
    }
}


  void
BX_CPU_C::OR_EbGb(bxInstruction_c *i)
{
  Bit8u op2, op1, result;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op2 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op2_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    result = op1 | op2;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "OR_EbGb");
  }
#endif
    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), result);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, LogicalExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    result = op1 | op2;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "OR_EbGb");
  }
#endif
    Write_RMW_virtual_byte(result, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	write_virtual_expression(i->seg(), RMAddr(i), LogicalExpr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_8(op1, op2, result, BX_INSTR_OR8);
}


  void
BX_CPU_C::OR_GbEb(bxInstruction_c *i)
{
  Bit8u op1, op2, result;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op1 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op1_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op2 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op2_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    }
  else {
    read_virtual_byte(i->seg(), RMAddr(i), &op2, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op2Expr);
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmOr8(result, op1, op2, flags32);
  setEFlagsOSZAPC(flags32);
#else
  result = op1 | op2;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "OR_GbEb");
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

  BX_WRITE_8BIT_REGx(i->nnn(), i->extend8bitL(), result);
  BX_WRITE_8BIT_REG_INTEGRITY(i->nnn(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1, LogicalExpr);
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_8(op1, op2, result, BX_INSTR_OR8);
#endif
}


  void
BX_CPU_C::OR_ALIb(bxInstruction_c *i)
{
  Bit8u op1, op2, result;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op1 = AL;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(0, 0);
  }
#endif
  op2 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) new Constant(i->Ib());
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmOr8(result, op1, op2, flags32);
  setEFlagsOSZAPC(flags32);
#else
  result = op1 | op2;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "OR_ALIb");
	else
	{
		LogicalExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

  AL = result;
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(0, 0, LogicalExpr);
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_8(op1, op2, result, BX_INSTR_OR8);
#endif
}



  void
BX_CPU_C::AND_EbGb(bxInstruction_c *i)
{
  Bit8u op2, op1, result;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op2 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op2_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmAnd8(result, op1, op2, flags32);
    setEFlagsOSZAPC(flags32);
#else
    result = op1 & op2;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "AND_EbGb");
  }
#endif

    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), result);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, LogicalExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmAnd8(result, op1, op2, flags32);
    setEFlagsOSZAPC(flags32);
#else
    result = op1 & op2;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "AND_EbGb");
  }
#endif

    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

    Write_RMW_virtual_byte(result, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	write_virtual_expression(i->seg(), RMAddr(i), LogicalExpr);
  }
#endif
    }

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_8(op1, op2, result, BX_INSTR_AND8);
#endif
}


  void
BX_CPU_C::AND_GbEb(bxInstruction_c *i)
{
  Bit8u op1, op2, result;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op1 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
  op1_integrity = BX_READ_8BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op2 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op2_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    }
  else {
    read_virtual_byte(i->seg(), RMAddr(i), &op2, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op2Expr);
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmAnd8(result, op1, op2, flags32);
  setEFlagsOSZAPC(flags32);
#else
  result = op1 & op2;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "AND_GbEb");
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

  BX_WRITE_8BIT_REGx(i->nnn(), i->extend8bitL(), result);
  BX_WRITE_8BIT_REG_INTEGRITY(i->nnn(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1, LogicalExpr);
  }
#endif


#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_8(op1, op2, result, BX_INSTR_AND8);
#endif
}


  void
BX_CPU_C::AND_ALIb(bxInstruction_c *i)
{
  Bit8u op1, op2, result;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;


  op1 = AL;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(0, 0);
  }
#endif
  op2 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) new Constant(i->Ib());
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmAnd8(result, op1, op2, flags32);
  setEFlagsOSZAPC(flags32);
#else
  result = op1 & op2;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "AND_ALIb");
	else
	{
		LogicalExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

  AL = result;
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(0, 0, LogicalExpr);
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_8(op1, op2, result, BX_INSTR_AND8);
#endif
}




  void
BX_CPU_C::AND_EbIb(bxInstruction_c *i)
{
  Bit8u op2, op1, result;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *LogicalExpr;

  op2 = i->Ib();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) new Constant(i->Ib());
  }
#endif

  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
    op1_integrity = BX_READ_8BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmAnd8(result, op1, op2, flags32);
    setEFlagsOSZAPC(flags32);
#else
    result = op1 & op2;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "AND_EbIb");
	else
	{
		LogicalExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif

    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

    BX_WRITE_8BIT_REGx(i->rm(), i->extend8bitL(), result);
    BX_WRITE_8BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1, LogicalExpr);
  }
#endif
    }
  else {
    read_RMW_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmAnd8(result, op1, op2, flags32);
    setEFlagsOSZAPC(flags32);
#else
    result = op1 & op2;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (Op1Expr != NULL)
		LogicalExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "AND_EbIb");
	else
	{
		LogicalExpr = NULL;
		//delete Op2Expr;
	}
  }
#endif

    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_BYTE, INTEG_BYTE);

    Write_RMW_virtual_byte(result, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	write_virtual_expression(i->seg(), RMAddr(i), LogicalExpr);
  }
#endif
    }

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_8(op1, op2, result, BX_INSTR_AND8);
#endif
}


  void
BX_CPU_C::TEST_EbGb(bxInstruction_c *i)
{
  Bit8u op2, op1;
  Bit8u op1_integrity;
  Expression *Op1Expr;
  Expression *Op2Expr;

  op2 = BX_READ_8BIT_REGx(i->nnn(),i->extend8bitL());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = TheLabels.ReadSymbolicRegister(i->nnn() % 4, i->nnn() < 4 ? 0 : 1);
  }
#endif

  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
  }
#endif
    }
  else {
    read_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmTest8(op1, op2, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit8u result;
  result = op1 & op2;

  SET_FLAGS_OSZAPC_8_WITHEXPR(op1, op2, result, BX_INSTR_TEST8, Op1Expr, Op2Expr);
#endif
}


  void
BX_CPU_C::TEST_ALIb(bxInstruction_c *i)
{
  Bit8u op2, op1;
  Expression *Op1Expr;
  Expression *Op2Expr;

  op1 = AL;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(0, 0);
  }
#endif
  op2 = i->Ib();
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	//if (Op1Expr != NULL)
	//	Op2Expr = (Expression *) new Constant(i->Ib());
	//else
		Op2Expr = NULL;
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmTest8(op1, op2, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit8u result;
  result = op1 & op2;

  SET_FLAGS_OSZAPC_8_WITHEXPR(op1, op2, result, BX_INSTR_TEST8, Op1Expr, Op2Expr);
  //SET_FLAGS_OSZAPC_8(op1, op2, result, BX_INSTR_TEST8);
#endif
}



  void
BX_CPU_C::TEST_EbIb(bxInstruction_c *i)
{
  Bit8u op2, op1;
  Bit8u op1_integrity;
  Expression *Op1Expr;
  Expression *Op2Expr;

  op2 = i->Ib();

  if (i->modC0()) {
    op1 = BX_READ_8BIT_REGx(i->rm(),i->extend8bitL());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = TheLabels.ReadSymbolicRegister(i->rm() % 4, i->rm() < 4 ? 0 : 1);
	//Op1Expr = (Expression *) new Label(123);
  }
#endif
    }
  else {
    read_virtual_byte(i->seg(), RMAddr(i), &op1, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	read_virtual_expression(i->seg(), RMAddr(i), &Op1Expr);
  }
#endif
    }
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	//if (Op1Expr != NULL)
	//	Op2Expr = (Expression *) new Constant(i->Ib());
	//else
		Op2Expr = NULL;
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmTest8(op1, op2, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit8u result;
  result = op1 & op2;

  SET_FLAGS_OSZAPC_8_WITHEXPR(op1, op2, result, BX_INSTR_TEST8, Op1Expr, Op2Expr);
  //SET_FLAGS_OSZAPC_8(op1, op2, result, BX_INSTR_TEST8);
#endif
}
