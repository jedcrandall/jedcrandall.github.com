/////////////////////////////////////////////////////////////////////////
// $Id: stack32.cc,v 1.16 2002/09/24 00:44:56 kevinlawton Exp $
/////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2001  MandrakeSoft S.A.
//
//    MandrakeSoft S.A.
//    43, rue d'Aboukir
//    75002 Paris - France
//    http://www.linux-mandrake.com/
//    http://www.mandrakesoft.com/
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA





#define NEED_CPU_REG_SHORTCUTS 1
#include "bochs.h"
#define LOG_THIS BX_CPU_THIS_PTR

#if BX_USE_CPU_SMF
#define this (BX_CPU(0))
#endif


#if BX_SUPPORT_X86_64==0
// Make life easier for merging 64&32-bit code.
#define RBP EBP
#endif



  void
BX_CPU_C::POP_Ed(bxInstruction_c *i)
{
  Bit32u val32;
  Bit8u val32_integrity;
  Expression *Expr32[4];

  pop_32(&val32, &val32_integrity, &(Expr32[0]));

  if (i->modC0()) {
    BX_WRITE_32BIT_REGZ(i->rm(), val32);
    BX_WRITE_32BIT_REG_INTEGRITY(i->rm(), val32_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->rm(), 0, MakeACopyOf(Expr32[0]));
	TheLabels.WriteSymbolicRegister(i->rm(), 1, MakeACopyOf(Expr32[1]));
	TheLabels.WriteSymbolicRegister(i->rm(), 2, MakeACopyOf(Expr32[2]));
	TheLabels.WriteSymbolicRegister(i->rm(), 3, MakeACopyOf(Expr32[3]));
  }
#endif
    //if ((i->rm() == 5) && (val32_integrity != 0xFF)) BX_PANIC(("Yah"));
    }
  else {
    // Note: there is one little weirdism here.  When 32bit addressing
    // is used, it is possible to use ESP in the modrm addressing.
    // If used, the value of ESP after the pop is used to calculate
    // the address.
    if (i->as32L() && (!i->modC0()) && (i->rm()==4) && (i->sibBase()==4)) {
      // call method on BX_CPU_C object
      BX_CPU_CALL_METHOD (i->ResolveModrm, (i));
      }
    write_virtual_dword(i->seg(), RMAddr(i), &val32, &val32_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(i->seg(), RMAddr(i), MakeACopyOf(Expr32[0]));
  	write_virtual_expression(i->seg(), RMAddr(i) + 1, MakeACopyOf(Expr32[1]));
  	write_virtual_expression(i->seg(), RMAddr(i) + 2, MakeACopyOf(Expr32[2]));
  	write_virtual_expression(i->seg(), RMAddr(i) + 3, MakeACopyOf(Expr32[3]));
  }
#endif
    }
}

  void
BX_CPU_C::PUSH_ERX(bxInstruction_c *i)
{
  //if (BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].reg_integrity != 0xFF)
  //{
  //	printf("Darn it %d\n", i->opcodeReg());
//	BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].reg_integrity = 0xFF;
  //}
  Expression *Expr32[4];
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	Expr32[0] = MakeACopyOf(TheLabels.ReadSymbolicRegister(i->opcodeReg(), 0));
	Expr32[1] = MakeACopyOf(TheLabels.ReadSymbolicRegister(i->opcodeReg(), 1));
	Expr32[2] = MakeACopyOf(TheLabels.ReadSymbolicRegister(i->opcodeReg(), 2));
	Expr32[3] = MakeACopyOf(TheLabels.ReadSymbolicRegister(i->opcodeReg(), 3));
  }
#endif

  push_32(BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].dword.erx, BX_READ_32BIT_INTEGRITY(i->opcodeReg()), &(Expr32[0]));
  /*BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].reg_integrity);*/
}

  void
BX_CPU_C::POP_ERX(bxInstruction_c *i)
{
  Bit32u erx;
  Bit8u erx_integrity;
  Expression *Expr32[4];

  pop_32(&erx, &erx_integrity, &(Expr32[0]));
  BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].dword.erx = erx;
  //BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].reg_integrity = erx_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(i->opcodeReg(), erx_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(i->opcodeReg(), 0, MakeACopyOf(Expr32[0]));
	TheLabels.WriteSymbolicRegister(i->opcodeReg(), 1, MakeACopyOf(Expr32[1]));
	TheLabels.WriteSymbolicRegister(i->opcodeReg(), 2, MakeACopyOf(Expr32[2]));
	TheLabels.WriteSymbolicRegister(i->opcodeReg(), 3, MakeACopyOf(Expr32[3]));
  }
#endif
}


  void
BX_CPU_C::PUSH_CS(bxInstruction_c *i)
{
  Expression *NullExpr[4] = {NULL, NULL, NULL, NULL};
  if (i->os32L())
    push_32(BX_CPU_THIS_PTR sregs[BX_SEG_REG_CS].selector.value, BX_CPU_THIS_PTR sregs[BX_SEG_REG_CS].segreg_integrity, &(NullExpr[0]));
  else
    push_16(BX_CPU_THIS_PTR sregs[BX_SEG_REG_CS].selector.value, BX_CPU_THIS_PTR sregs[BX_SEG_REG_CS].segreg_integrity, &(NullExpr[0]));
}
  void
BX_CPU_C::PUSH_DS(bxInstruction_c *i)
{
  Expression *NullExpr[4] = {NULL, NULL, NULL, NULL};
  if (i->os32L())
    push_32(BX_CPU_THIS_PTR sregs[BX_SEG_REG_DS].selector.value, BX_CPU_THIS_PTR sregs[BX_SEG_REG_DS].segreg_integrity, &(NullExpr[0]));
  else
    push_16(BX_CPU_THIS_PTR sregs[BX_SEG_REG_DS].selector.value, BX_CPU_THIS_PTR sregs[BX_SEG_REG_DS].segreg_integrity, &(NullExpr[0]));
}
  void
BX_CPU_C::PUSH_ES(bxInstruction_c *i)
{
  Expression *NullExpr[4] = {NULL, NULL, NULL, NULL};
  if (i->os32L())
    push_32(BX_CPU_THIS_PTR sregs[BX_SEG_REG_ES].selector.value, BX_CPU_THIS_PTR sregs[BX_SEG_REG_ES].segreg_integrity, &(NullExpr[0]));
  else
    push_16(BX_CPU_THIS_PTR sregs[BX_SEG_REG_ES].selector.value, BX_CPU_THIS_PTR sregs[BX_SEG_REG_ES].segreg_integrity, &(NullExpr[0]));
}
  void
BX_CPU_C::PUSH_FS(bxInstruction_c *i)
{
  Expression *NullExpr[4] = {NULL, NULL, NULL, NULL};
BailBigRSP("push_fs");
  if (i->os32L())
    push_32(BX_CPU_THIS_PTR sregs[BX_SEG_REG_FS].selector.value, BX_CPU_THIS_PTR sregs[BX_SEG_REG_FS].segreg_integrity, &(NullExpr[0]));
  else
    push_16(BX_CPU_THIS_PTR sregs[BX_SEG_REG_FS].selector.value, BX_CPU_THIS_PTR sregs[BX_SEG_REG_FS].segreg_integrity, &(NullExpr[0]));
}
  void
BX_CPU_C::PUSH_GS(bxInstruction_c *i)
{
  Expression *NullExpr[4] = {NULL, NULL, NULL, NULL};
BailBigRSP("push_gs");
  if (i->os32L())
    push_32(BX_CPU_THIS_PTR sregs[BX_SEG_REG_GS].selector.value, BX_CPU_THIS_PTR sregs[BX_SEG_REG_GS].segreg_integrity, &(NullExpr[0]));
  else
    push_16(BX_CPU_THIS_PTR sregs[BX_SEG_REG_GS].selector.value, BX_CPU_THIS_PTR sregs[BX_SEG_REG_GS].segreg_integrity, &(NullExpr[0]));
}
  void
BX_CPU_C::PUSH_SS(bxInstruction_c *i)
{
  Expression *NullExpr[4] = {NULL, NULL, NULL, NULL};
  if (i->os32L())
    push_32(BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].selector.value, BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].segreg_integrity, &(NullExpr[0]));
  else
    push_16(BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].selector.value, BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].segreg_integrity, &(NullExpr[0]));
}


  void
BX_CPU_C::POP_DS(bxInstruction_c *i)
{
  Expression *ExprIgnored[4];

  if (i->os32L()) {
    Bit32u ds;
    Bit8u ds_integrity;
    pop_32(&ds, &ds_integrity, &(ExprIgnored[0]));
    load_seg_reg(&BX_CPU_THIS_PTR sregs[BX_SEG_REG_DS], (Bit16u) ds);
    BX_CPU_THIS_PTR sregs[BX_SEG_REG_DS].segreg_integrity = ds_integrity;
    }
  else {
    Bit16u ds;
    Bit8u ds_integrity;
    pop_16(&ds, &ds_integrity, &(ExprIgnored[0]));
    load_seg_reg(&BX_CPU_THIS_PTR sregs[BX_SEG_REG_DS], ds);
    BX_CPU_THIS_PTR sregs[BX_SEG_REG_DS].segreg_integrity = ds_integrity;
    }
}
  void
BX_CPU_C::POP_ES(bxInstruction_c *i)
{
  Expression *ExprIgnored[4];

  if (i->os32L()) {
    Bit32u es;
    Bit8u es_integrity;
    pop_32(&es, &es_integrity, &(ExprIgnored[0]));
    load_seg_reg(&BX_CPU_THIS_PTR sregs[BX_SEG_REG_ES], (Bit16u) es);
    BX_CPU_THIS_PTR sregs[BX_SEG_REG_ES].segreg_integrity = es_integrity;
    }
  else {
    Bit16u es;
    Bit8u es_integrity;
    pop_16(&es, &es_integrity, &(ExprIgnored[0]));
    load_seg_reg(&BX_CPU_THIS_PTR sregs[BX_SEG_REG_ES], es);
    BX_CPU_THIS_PTR sregs[BX_SEG_REG_ES].segreg_integrity = es_integrity;
    }
}
  void
BX_CPU_C::POP_FS(bxInstruction_c *i)
{
  Expression *ExprIgnored[4];

BailBigRSP("pop_fs");
  if (i->os32L()) {
    Bit32u fs;
    Bit8u fs_integrity;
    pop_32(&fs, &fs_integrity, &(ExprIgnored[0]));
    load_seg_reg(&BX_CPU_THIS_PTR sregs[BX_SEG_REG_FS], (Bit16u) fs);
    BX_CPU_THIS_PTR sregs[BX_SEG_REG_FS].segreg_integrity = fs_integrity;
    }
  else {
    Bit16u fs;
    Bit8u fs_integrity;
    pop_16(&fs, &fs_integrity, &(ExprIgnored[0]));
    load_seg_reg(&BX_CPU_THIS_PTR sregs[BX_SEG_REG_FS], fs);
    BX_CPU_THIS_PTR sregs[BX_SEG_REG_FS].segreg_integrity = fs_integrity;
    }
}
  void
BX_CPU_C::POP_GS(bxInstruction_c *i)
{
  Expression *ExprIgnored[4];

BailBigRSP("pop_gs");
  if (i->os32L()) {
    Bit32u gs;
    Bit8u gs_integrity;
    pop_32(&gs, &gs_integrity, &(ExprIgnored[0]));
    load_seg_reg(&BX_CPU_THIS_PTR sregs[BX_SEG_REG_GS], (Bit16u) gs);
    BX_CPU_THIS_PTR sregs[BX_SEG_REG_GS].segreg_integrity = gs_integrity;
    }
  else {
    Bit16u gs;
    Bit8u gs_integrity;
    pop_16(&gs, &gs_integrity, &(ExprIgnored[0]));
    load_seg_reg(&BX_CPU_THIS_PTR sregs[BX_SEG_REG_GS], gs);
    BX_CPU_THIS_PTR sregs[BX_SEG_REG_GS].segreg_integrity = gs_integrity;
    }
}
  void
BX_CPU_C::POP_SS(bxInstruction_c *i)
{
  Expression *ExprIgnored[4];

  if (i->os32L()) {
    Bit32u ss;
    Bit8u ss_integrity;
    pop_32(&ss, &ss_integrity, &(ExprIgnored[0]));
    load_seg_reg(&BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS], (Bit16u) ss);
    BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].segreg_integrity = ss_integrity;
    }
  else {
    Bit16u ss;
    Bit8u ss_integrity;
    pop_16(&ss, &ss_integrity, &(ExprIgnored[0]));
    load_seg_reg(&BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS], ss);
    BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].segreg_integrity = ss_integrity;
    }

  // POP SS inhibits interrupts, debug exceptions and single-step
  // trap exceptions until the execution boundary following the
  // next instruction is reached.
  // Same code as MOV_SwEw()
  BX_CPU_THIS_PTR inhibit_mask |=
    BX_INHIBIT_INTERRUPTS | BX_INHIBIT_DEBUG;
  BX_CPU_THIS_PTR async_event = 1;
}


  void
BX_CPU_C::PUSHAD32(bxInstruction_c *i)
{
#if BX_CPU_LEVEL < 2
  BX_PANIC(("PUSHAD: not supported on an 8086"));
#else
  Bit32u temp_ESP;
  Bit32u esp;
  Bit8u esp_integrity;
  Expression *EAXExpr[4], *ECXExpr[4], *EDXExpr[4], *EBXExpr[4];
  Expression *ESPExpr[4], *EBPExpr[4], *ESIExpr[4], *EDIExpr[4];

  if (BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache.u.segment.d_b)
    temp_ESP = ESP;
  else
    temp_ESP = SP;


    if (protected_mode()) {
      if ( !can_push(&BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache, temp_ESP, 32) ) {
        BX_PANIC(("PUSHAD(): stack doesn't have enough room!"));
        exception(BX_SS_EXCEPTION, 0, 0);
        return;
        }
      }
    else {
      if (temp_ESP < 32)
        BX_PANIC(("pushad: eSP < 32"));
      }

    esp = ESP;
    esp_integrity = ESP_INTEGRITY;

#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	EAXExpr[0] = MakeACopyOf(TheLabels.ReadSymbolicRegister(0, 0));
	EAXExpr[1] = MakeACopyOf(TheLabels.ReadSymbolicRegister(0, 1));
	EAXExpr[2] = MakeACopyOf(TheLabels.ReadSymbolicRegister(0, 2));
	EAXExpr[3] = MakeACopyOf(TheLabels.ReadSymbolicRegister(0, 3));
	ECXExpr[0] = MakeACopyOf(TheLabels.ReadSymbolicRegister(1, 0));
	ECXExpr[1] = MakeACopyOf(TheLabels.ReadSymbolicRegister(1, 1));
	ECXExpr[2] = MakeACopyOf(TheLabels.ReadSymbolicRegister(1, 2));
	ECXExpr[3] = MakeACopyOf(TheLabels.ReadSymbolicRegister(1, 3));
	EDXExpr[0] = MakeACopyOf(TheLabels.ReadSymbolicRegister(2, 0));
	EDXExpr[1] = MakeACopyOf(TheLabels.ReadSymbolicRegister(2, 1));
	EDXExpr[2] = MakeACopyOf(TheLabels.ReadSymbolicRegister(2, 2));
	EDXExpr[3] = MakeACopyOf(TheLabels.ReadSymbolicRegister(2, 3));
	EBXExpr[0] = MakeACopyOf(TheLabels.ReadSymbolicRegister(3, 0));
	EBXExpr[1] = MakeACopyOf(TheLabels.ReadSymbolicRegister(3, 1));
	EBXExpr[2] = MakeACopyOf(TheLabels.ReadSymbolicRegister(3, 2));
	EBXExpr[3] = MakeACopyOf(TheLabels.ReadSymbolicRegister(3, 3));
	ESPExpr[0] = MakeACopyOf(TheLabels.ReadSymbolicRegister(4, 0));
	ESPExpr[1] = MakeACopyOf(TheLabels.ReadSymbolicRegister(4, 1));
	ESPExpr[2] = MakeACopyOf(TheLabels.ReadSymbolicRegister(4, 2));
	ESPExpr[3] = MakeACopyOf(TheLabels.ReadSymbolicRegister(4, 3));
	EBPExpr[0] = MakeACopyOf(TheLabels.ReadSymbolicRegister(5, 0));
	EBPExpr[1] = MakeACopyOf(TheLabels.ReadSymbolicRegister(5, 1));
	EBPExpr[2] = MakeACopyOf(TheLabels.ReadSymbolicRegister(5, 2));
	EBPExpr[3] = MakeACopyOf(TheLabels.ReadSymbolicRegister(5, 3));
	ESIExpr[0] = MakeACopyOf(TheLabels.ReadSymbolicRegister(6, 0));
	ESIExpr[1] = MakeACopyOf(TheLabels.ReadSymbolicRegister(6, 1));
	ESIExpr[2] = MakeACopyOf(TheLabels.ReadSymbolicRegister(6, 2));
	ESIExpr[3] = MakeACopyOf(TheLabels.ReadSymbolicRegister(6, 3));
	EDIExpr[0] = MakeACopyOf(TheLabels.ReadSymbolicRegister(7, 0));
	EDIExpr[1] = MakeACopyOf(TheLabels.ReadSymbolicRegister(7, 1));
	EDIExpr[2] = MakeACopyOf(TheLabels.ReadSymbolicRegister(7, 2));
	EDIExpr[3] = MakeACopyOf(TheLabels.ReadSymbolicRegister(7, 3));
  }
#endif


    /* ??? optimize this by using virtual write, all checks passed */
    push_32(EAX, EAX_INTEGRITY, &(EAXExpr[0]));
    push_32(ECX, ECX_INTEGRITY, &(ECXExpr[0]));
    push_32(EDX, EDX_INTEGRITY, &(EDXExpr[0]));
    push_32(EBX, EBX_INTEGRITY, &(EBXExpr[0]));
    push_32(esp, esp_integrity, &(ESPExpr[0]));
    push_32(EBP, EBP_INTEGRITY, &(EBPExpr[0]));
    push_32(ESI, ESI_INTEGRITY, &(ESIExpr[0]));
    push_32(EDI, EDI_INTEGRITY, &(EDIExpr[0]));
#endif
}

  void
BX_CPU_C::POPAD32(bxInstruction_c *i)
{
#if BX_CPU_LEVEL < 2
  BX_PANIC(("POPAD not supported on an 8086"));
#else /* 286+ */
    Bit32u edi, esi, ebp, etmp, ebx, edx, ecx, eax;
    Bit8u edi_integrity, esi_integrity, ebp_integrity, etmp_integrity, ebx_integrity, edx_integrity, ecx_integrity, eax_integrity;
  Expression *EAXExpr[4], *ECXExpr[4], *EDXExpr[4], *EBXExpr[4];
  Expression *ESPExpr[4], *EBPExpr[4], *ESIExpr[4], *EDIExpr[4];


    if (protected_mode()) {
      if ( !can_pop(32) ) {
        BX_PANIC(("pop_ad: not enough bytes on stack"));
        exception(BX_SS_EXCEPTION, 0, 0);
        return;
        }
      }

    /* ??? optimize this */
    pop_32(&edi, &edi_integrity, &(EDIExpr[0]));
    pop_32(&esi, &esi_integrity, &(ESIExpr[0]));
    pop_32(&ebp, &ebp_integrity, &(EBPExpr[0]));
    pop_32(&etmp, &etmp_integrity, &(ESPExpr[0])); /* value for ESP discarded */
    pop_32(&ebx, &ebx_integrity, &(EBXExpr[0]));
    pop_32(&edx, &edx_integrity, &(EDXExpr[0]));
    pop_32(&ecx, &ecx_integrity, &(ECXExpr[0]));
    pop_32(&eax, &eax_integrity, &(EAXExpr[0]));

    EDI = edi;
    ESI = esi;
    EBP = ebp;
    EBX = ebx;
    EDX = edx;
    ECX = ecx;
    EAX = eax;

    LVAL_EDI_INTEGRITY = edi_integrity;
    LVAL_ESI_INTEGRITY = esi_integrity;
    LVAL_EBP_INTEGRITY = ebp_integrity;
    LVAL_EBX_INTEGRITY = ebx_integrity;
    LVAL_EDX_INTEGRITY = edx_integrity;
    LVAL_ECX_INTEGRITY = ecx_integrity;
    //LVAL_EAX_INTEGRITY = eax_integrity;
    BX_WRITE_32BIT_REG_INTEGRITY(0, eax_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(0, 0, MakeACopyOf(EAXExpr[0]));
	TheLabels.WriteSymbolicRegister(0, 1, MakeACopyOf(EAXExpr[1]));
	TheLabels.WriteSymbolicRegister(0, 2, MakeACopyOf(EAXExpr[2]));
	TheLabels.WriteSymbolicRegister(0, 3, MakeACopyOf(EAXExpr[3]));
	TheLabels.WriteSymbolicRegister(1, 0, MakeACopyOf(ECXExpr[0]));
	TheLabels.WriteSymbolicRegister(1, 1, MakeACopyOf(ECXExpr[1]));
	TheLabels.WriteSymbolicRegister(1, 2, MakeACopyOf(ECXExpr[2]));
	TheLabels.WriteSymbolicRegister(1, 3, MakeACopyOf(ECXExpr[3]));
	TheLabels.WriteSymbolicRegister(2, 0, MakeACopyOf(EDXExpr[0]));
	TheLabels.WriteSymbolicRegister(2, 1, MakeACopyOf(EDXExpr[1]));
	TheLabels.WriteSymbolicRegister(2, 2, MakeACopyOf(EDXExpr[2]));
	TheLabels.WriteSymbolicRegister(2, 3, MakeACopyOf(EDXExpr[3]));
	TheLabels.WriteSymbolicRegister(3, 0, MakeACopyOf(EBXExpr[0]));
	TheLabels.WriteSymbolicRegister(3, 1, MakeACopyOf(EBXExpr[1]));
	TheLabels.WriteSymbolicRegister(3, 2, MakeACopyOf(EBXExpr[2]));
	TheLabels.WriteSymbolicRegister(3, 3, MakeACopyOf(EBXExpr[3]));
	TheLabels.WriteSymbolicRegister(4, 0, MakeACopyOf(ESPExpr[0]));
	TheLabels.WriteSymbolicRegister(4, 1, MakeACopyOf(ESPExpr[1]));
	TheLabels.WriteSymbolicRegister(4, 2, MakeACopyOf(ESPExpr[2]));
	TheLabels.WriteSymbolicRegister(4, 3, MakeACopyOf(ESPExpr[3]));
	TheLabels.WriteSymbolicRegister(5, 0, MakeACopyOf(EBPExpr[0]));
	TheLabels.WriteSymbolicRegister(5, 1, MakeACopyOf(EBPExpr[1]));
	TheLabels.WriteSymbolicRegister(5, 2, MakeACopyOf(EBPExpr[2]));
	TheLabels.WriteSymbolicRegister(5, 3, MakeACopyOf(EBPExpr[3]));
	TheLabels.WriteSymbolicRegister(6, 0, MakeACopyOf(ESIExpr[0]));
	TheLabels.WriteSymbolicRegister(6, 1, MakeACopyOf(ESIExpr[1]));
	TheLabels.WriteSymbolicRegister(6, 2, MakeACopyOf(ESIExpr[2]));
	TheLabels.WriteSymbolicRegister(6, 3, MakeACopyOf(ESIExpr[3]));
	TheLabels.WriteSymbolicRegister(7, 0, MakeACopyOf(EDIExpr[0]));
	TheLabels.WriteSymbolicRegister(7, 1, MakeACopyOf(EDIExpr[1]));
	TheLabels.WriteSymbolicRegister(7, 2, MakeACopyOf(EDIExpr[2]));
	TheLabels.WriteSymbolicRegister(7, 3, MakeACopyOf(EDIExpr[3]));
  }
#endif

#endif
}

  void
BX_CPU_C::PUSH_Id(bxInstruction_c *i)
{
#if BX_CPU_LEVEL < 2
  BX_PANIC(("PUSH_Iv: not supported on 8086!"));
#else

    Bit32u imm32;
    Expression *NullExpr[4] = {NULL, NULL, NULL, NULL};

    imm32 = i->Id();

    push_32(imm32, 0xFF, &(NullExpr[0]));
#endif
}

  void
BX_CPU_C::PUSH_Ed(bxInstruction_c *i)
{
    Bit32u op1_32;
    Bit8u op1_integrity;
    Expression *Op1Expr[4];

    /* op1_32 is a register or memory reference */
    if (i->modC0()) {
      op1_32 = BX_READ_32BIT_REG(i->rm());
      op1_integrity = BX_READ_32BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	Op1Expr[0] = MakeACopyOf(TheLabels.ReadSymbolicRegister(i->rm(), 0));
	Op1Expr[1] = MakeACopyOf(TheLabels.ReadSymbolicRegister(i->rm(), 1));
	Op1Expr[2] = MakeACopyOf(TheLabels.ReadSymbolicRegister(i->rm(), 2));
	Op1Expr[3] = MakeACopyOf(TheLabels.ReadSymbolicRegister(i->rm(), 3));
  }
#endif
      }
    else {
      /* pointer, segment address pair */
      read_virtual_dword(i->seg(), RMAddr(i), &op1_32, &op1_integrity);
      //if (op1_integrity != 0xFF) printf("EIP is %08x\n", EIP);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(i->seg(), RMAddr(i), &(Op1Expr[0]));
  	read_virtual_expression(i->seg(), RMAddr(i) + 1, &(Op1Expr[1]));
  	read_virtual_expression(i->seg(), RMAddr(i) + 2, &(Op1Expr[2]));
  	read_virtual_expression(i->seg(), RMAddr(i) + 3, &(Op1Expr[3]));
  	Op1Expr[0] = MakeACopyOf(Op1Expr[0]);
  	Op1Expr[1] = MakeACopyOf(Op1Expr[1]);
  	Op1Expr[2] = MakeACopyOf(Op1Expr[2]);
  	Op1Expr[3] = MakeACopyOf(Op1Expr[3]);
  }
#endif
     }

    push_32(op1_32, op1_integrity, &(Op1Expr[0]));
}


  void
BX_CPU_C::ENTER_IwIb(bxInstruction_c *i)
{
#if BX_CPU_LEVEL < 2
  BX_PANIC(("ENTER_IwIb: not supported by 8086!"));
#else
  Bit32u frame_ptr32;
  Bit16u frame_ptr16;
  Bit8u frame_ptr32_integrity;
  Bit8u frame_ptr16_integrity;
  Bit8u level;
  static Bit8u first_time = 1;
  Expression *NullExpr[4] = {NULL, NULL, NULL, NULL};
  Expression *Expr32[4];

  level = i->Ib2();

  invalidate_prefetch_q();

  level %= 32;
/* ??? */
  if (first_time && level>0) {
    BX_ERROR(("enter() with level > 0. The emulation of this instruction may not be complete.  This warning will be printed only once per bochs run."));
    first_time = 0;
  }
//if (BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache.u.segment.d_b && i->os32L()==0) {
//  BX_INFO(("enter(): stacksize!=opsize: I'm unsure of the code for this"));
//  BX_PANIC(("         The Intel manuals are a mess on this one!"));
//  }

  if ( protected_mode() ) {
    Bit32u bytes_to_push, temp_ESP;

    if (level == 0) {
      if (i->os32L())
        bytes_to_push = 4 + i->Iw();
      else
        bytes_to_push = 2 + i->Iw();
      }
    else { /* level > 0 */
      if (i->os32L())
        bytes_to_push = 4 + (level-1)*4 + 4 + i->Iw();
      else
        bytes_to_push = 2 + (level-1)*2 + 2 + i->Iw();
      }
    if (BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache.u.segment.d_b)
      temp_ESP = ESP;
    else
      temp_ESP = SP;
    if ( !can_push(&BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache, temp_ESP, bytes_to_push) ) {
      BX_PANIC(("ENTER: not enough room on stack!"));
      exception(BX_SS_EXCEPTION, 0, 0);
      }
    }

  if (i->os32L())
    push_32(EBP, EBP_INTEGRITY, &(NullExpr[0]));
  else
    push_16(BP, EBP_INTEGRITY, &(NullExpr[0]));

  // can just do frame_ptr32 = ESP for either case ???
  if (BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache.u.segment.d_b)
    frame_ptr32 = ESP;
  else
    frame_ptr32 = SP;

  if (level > 0) {
    /* do level-1 times */
    while (--level) {
      if (i->os32L()) {
        Bit32u temp32;
  Bit8u temp32_integrity;

        if (BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache.u.segment.d_b) { /* 32bit stacksize */
          EBP -= 4;
    BX_CPU_THIS_PTR RMAddr_integrity = EBP_INTEGRITY;
          read_virtual_dword(BX_SEG_REG_SS, EBP, &temp32, &temp32_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(BX_SEG_REG_SS, EBP, &(Expr32[0]));
  	read_virtual_expression(BX_SEG_REG_SS, EBP + 1, &(Expr32[1]));
  	read_virtual_expression(BX_SEG_REG_SS, EBP + 2, &(Expr32[2]));
  	read_virtual_expression(BX_SEG_REG_SS, EBP + 3, &(Expr32[3]));
  }
#endif
          ESP -= 4;
          write_virtual_dword(BX_SEG_REG_SS, ESP, &temp32, &temp32_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(BX_SEG_REG_SS, ESP, MakeACopyOf(Expr32[0]));
  	write_virtual_expression(BX_SEG_REG_SS, ESP + 1, MakeACopyOf(Expr32[1]));
  	write_virtual_expression(BX_SEG_REG_SS, ESP + 2, MakeACopyOf(Expr32[2]));
  	write_virtual_expression(BX_SEG_REG_SS, ESP + 3, MakeACopyOf(Expr32[3]));
  }
#endif
          }
        else { /* 16bit stacksize */
          BP -= 4;
    BX_CPU_THIS_PTR RMAddr_integrity = EBP_INTEGRITY;
          read_virtual_dword(BX_SEG_REG_SS, BP, &temp32, &temp32_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(BX_SEG_REG_SS, BP, &(Expr32[0]));
  	read_virtual_expression(BX_SEG_REG_SS, BP + 1, &(Expr32[1]));
  	read_virtual_expression(BX_SEG_REG_SS, BP + 2, &(Expr32[2]));
  	read_virtual_expression(BX_SEG_REG_SS, BP + 3, &(Expr32[3]));
  }
#endif
          SP -= 4;
          write_virtual_dword(BX_SEG_REG_SS, SP, &temp32, &temp32_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(BX_SEG_REG_SS, SP, MakeACopyOf(Expr32[0]));
  	write_virtual_expression(BX_SEG_REG_SS, SP + 1, MakeACopyOf(Expr32[1]));
  	write_virtual_expression(BX_SEG_REG_SS, SP + 2, MakeACopyOf(Expr32[2]));
  	write_virtual_expression(BX_SEG_REG_SS, SP + 3, MakeACopyOf(Expr32[3]));
  }
#endif
          }
        }
      else { /* 16bit opsize */
        Bit16u temp16;
        Bit8u temp16_integrity;

        if (BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache.u.segment.d_b) { /* 32bit stacksize */
          EBP -= 2;
    BX_CPU_THIS_PTR RMAddr_integrity = EBP_INTEGRITY;
          read_virtual_word(BX_SEG_REG_SS, EBP, &temp16, &temp16_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(BX_SEG_REG_SS, EBP, &(Expr32[0]));
  	read_virtual_expression(BX_SEG_REG_SS, EBP + 1, &(Expr32[1]));
  }
#endif
          ESP -= 2;
          write_virtual_word(BX_SEG_REG_SS, ESP, &temp16, &temp16_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(BX_SEG_REG_SS, ESP, MakeACopyOf(Expr32[0]));
  	write_virtual_expression(BX_SEG_REG_SS, ESP + 1, MakeACopyOf(Expr32[1]));
  }
#endif
          }
        else { /* 16bit stacksize */
          BP -= 2;
    BX_CPU_THIS_PTR RMAddr_integrity = EBP_INTEGRITY;
          read_virtual_word(BX_SEG_REG_SS, BP, &temp16, &temp16_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	read_virtual_expression(BX_SEG_REG_SS, BP, &(Expr32[0]));
  	read_virtual_expression(BX_SEG_REG_SS, BP + 1, &(Expr32[1]));
  }
#endif
          SP -= 2;
          write_virtual_word(BX_SEG_REG_SS, SP, &temp16, &temp16_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(BX_SEG_REG_SS, SP, MakeACopyOf(Expr32[0]));
  	write_virtual_expression(BX_SEG_REG_SS, SP + 1, MakeACopyOf(Expr32[1]));
  	write_virtual_expression(BX_SEG_REG_SS, SP + 2, MakeACopyOf(Expr32[2]));
  	write_virtual_expression(BX_SEG_REG_SS, SP + 3, MakeACopyOf(Expr32[3]));
  }
#endif
          }
        }
      } /* while (--level) */

    /* push(frame pointer) */
    if (i->os32L()) {
      if (BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache.u.segment.d_b) { /* 32bit stacksize */
        ESP -= 4;
        write_virtual_dword(BX_SEG_REG_SS, ESP, &frame_ptr32, &frame_ptr32_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(BX_SEG_REG_SS, ESP, NULL);
  	write_virtual_expression(BX_SEG_REG_SS, ESP + 1, NULL);
  	write_virtual_expression(BX_SEG_REG_SS, ESP + 2, NULL);
  	write_virtual_expression(BX_SEG_REG_SS, ESP + 3, NULL);
  }
#endif
        }
      else {
        SP -= 4;
        write_virtual_dword(BX_SEG_REG_SS, SP, &frame_ptr32, &frame_ptr32_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(BX_SEG_REG_SS, SP, NULL);
  	write_virtual_expression(BX_SEG_REG_SS, SP + 1, NULL);
  	write_virtual_expression(BX_SEG_REG_SS, SP + 2, NULL);
  	write_virtual_expression(BX_SEG_REG_SS, SP + 3, NULL);
  }
#endif
        }
      }
    else { /* 16bit opsize */
      if (BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache.u.segment.d_b) { /* 32bit stacksize */
        frame_ptr16 = frame_ptr32;
        ESP -= 2;
        write_virtual_word(BX_SEG_REG_SS, ESP, &frame_ptr16, &frame_ptr16_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(BX_SEG_REG_SS, ESP, NULL);
  	write_virtual_expression(BX_SEG_REG_SS, ESP + 1, NULL);
  }
#endif
        }
      else {
        frame_ptr16 = frame_ptr32;
        SP -= 2;
        write_virtual_word(BX_SEG_REG_SS, SP, &frame_ptr16, &frame_ptr16_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	write_virtual_expression(BX_SEG_REG_SS, SP, NULL);
  	write_virtual_expression(BX_SEG_REG_SS, SP + 1, NULL);
  }
#endif
        }
      }
    } /* if (level > 0) ... */

  if (i->os32L())
    RBP = frame_ptr32;
  else
    BP = frame_ptr32;

  if (BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache.u.segment.d_b) { /* 32bit stacksize */
    ESP = ESP - i->Iw();
    }
  else { /* 16bit stack */
    SP = SP - i->Iw();
    }
#endif
}

  void
BX_CPU_C::LEAVE(bxInstruction_c *i)
{
#if BX_CPU_LEVEL < 2
  BX_PANIC(("LEAVE: not supported by 8086!"));
#else
  Bit32u temp_EBP;


  invalidate_prefetch_q();

#if BX_CPU_LEVEL >= 3
  if (BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache.u.segment.d_b)
    temp_EBP = EBP;
  else
#endif
    temp_EBP = BP;

  if ( protected_mode() ) {
    if (BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache.u.segment.c_ed) { /* expand up */
      if (temp_EBP <= BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache.u.segment.limit_scaled) {
        BX_PANIC(("LEAVE: BP > BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].limit"));
        exception(BX_SS_EXCEPTION, 0, 0);
        return;
        }
      }
    else { /* normal */
      if (temp_EBP > BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache.u.segment.limit_scaled) {
        BX_PANIC(("LEAVE: BP > BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].limit"));
        exception(BX_SS_EXCEPTION, 0, 0);
        return;
        }
      }
    }


  // delete frame
#if BX_CPU_LEVEL >= 3
  if (BX_CPU_THIS_PTR sregs[BX_SEG_REG_SS].cache.u.segment.d_b)
  {
    ESP = EBP;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(4, 0, MakeACopyOf(TheLabels.ReadSymbolicRegister(5, 0)));
	TheLabels.WriteSymbolicRegister(4, 1, MakeACopyOf(TheLabels.ReadSymbolicRegister(5, 1)));
	TheLabels.WriteSymbolicRegister(4, 2, MakeACopyOf(TheLabels.ReadSymbolicRegister(5, 2)));
	TheLabels.WriteSymbolicRegister(4, 3, MakeACopyOf(TheLabels.ReadSymbolicRegister(5, 3)));
  }
#endif
  }
  else
#endif
  {
    SP = BP;
    LVAL_ESP_INTEGRITY = EBP_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(4, 0, MakeACopyOf(TheLabels.ReadSymbolicRegister(5, 0)));
	TheLabels.WriteSymbolicRegister(4, 1, MakeACopyOf(TheLabels.ReadSymbolicRegister(5, 1)));
  }
#endif
  }


  // restore frame pointer
#if BX_CPU_LEVEL >= 3
  if (i->os32L()) {
    Bit32u temp32;
    Bit8u temp32_integrity;
    Expression *TempExpr[4];

    pop_32(&temp32, &temp32_integrity, &(TempExpr[0]));
    RBP = temp32;
    LVAL_EBP_INTEGRITY = temp32_integrity;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(5, 0, MakeACopyOf(TempExpr[0]));
	TheLabels.WriteSymbolicRegister(5, 1, MakeACopyOf(TempExpr[1]));
	TheLabels.WriteSymbolicRegister(5, 2, MakeACopyOf(TempExpr[2]));
	TheLabels.WriteSymbolicRegister(5, 3, MakeACopyOf(TempExpr[3]));
  }
#endif
    }
  else
#endif
    {
    Bit16u temp16;
    Bit8u temp16_integrity;
    Expression *TempExpr[2];

    pop_16(&temp16, &temp16_integrity, &(TempExpr[0]));
    BP = temp16;
    LVAL_EBP_INTEGRITY = temp16_integrity;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	TheLabels.WriteSymbolicRegister(5, 0, MakeACopyOf(TempExpr[0]));
	TheLabels.WriteSymbolicRegister(5, 1, MakeACopyOf(TempExpr[1]));
  }
#endif
    }
#endif
}
