/////////////////////////////////////////////////////////////////////////
// $Id: arith16.cc,v 1.28 2002/10/25 18:26:26 sshwarts Exp $
/////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2001  MandrakeSoft S.A.
//
//    MandrakeSoft S.A.
//    43, rue d'Aboukir
//    75002 Paris - France
//    http://www.linux-mandrake.com/
//    http://www.mandrakesoft.com/
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA





#define NEED_CPU_REG_SHORTCUTS 1
#include "bochs.h"
#define LOG_THIS BX_CPU_THIS_PTR


  void
BX_CPU_C::INC_RX(bxInstruction_c *i)
{
  Expression *RegExpr;
#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmInc16(BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].word.rx, flags32);
  setEFlagsOSZAP(flags32);
#else
  Bit16u rx;
  rx = ++ BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].word.rx;

#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	RegExpr = (Expression *) MakeNewDoubleReg(i->opcodeReg());
	RegExpr = (Expression *) new Operation(RegExpr, NULL, "INC_RX");
	WriteSymbolicDoubleRegister(i->opcodeReg(), RegExpr);
  }
#endif


  SET_FLAGS_OSZAP_16(0, 0, rx, BX_INSTR_INC16);
#endif
}

  void
BX_CPU_C::DEC_RX(bxInstruction_c *i)
{
  Expression *RegExpr;
#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmDec16(BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].word.rx, flags32);
  setEFlagsOSZAP(flags32);
#else
  Bit16u rx;

  rx = -- BX_CPU_THIS_PTR gen_reg[i->opcodeReg()].word.rx;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	RegExpr = (Expression *) MakeNewDoubleReg(i->opcodeReg());
	RegExpr = (Expression *) new Operation(RegExpr, NULL, "DEC_RX");
	WriteSymbolicDoubleRegister(i->opcodeReg(), RegExpr);
  }
#endif

  SET_FLAGS_OSZAP_16(0, 0, rx, BX_INSTR_DEC16);
#endif
}


  void
BX_CPU_C::ADD_EwGw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16, sum_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op2_16 = BX_READ_16BIT_REG(i->nnn());
  op2_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    sum_16 = op1_16 + op2_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_EwGw");
  }
#endif
    BX_WRITE_16BIT_REG(i->rm(), sum_16);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    sum_16 = op1_16 + op2_16;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_EwGw");
  }
#endif
    Write_RMW_virtual_word(sum_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_16(op1_16, op2_16, sum_16, BX_INSTR_ADD16);
}


  void
BX_CPU_C::ADD_GwEEw(bxInstruction_c *i)
{
  Bit16u op1_16, op2_16, sum_16;
  unsigned nnn = i->nnn();
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op1_16 = BX_READ_16BIT_REG(nnn);
  op1_integrity = BX_READ_16BIT_INTEGRITY(nnn);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(nnn);
  }
#endif

  read_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmAdd16(sum_16, op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  sum_16 = op1_16 + op2_16;
#endif

#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_GwEEw");
  }
#endif

  BX_WRITE_16BIT_REG(nnn, sum_16);
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
  BX_WRITE_16BIT_REG_INTEGRITY(nnn, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(nnn, SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_16(op1_16, op2_16, sum_16, BX_INSTR_ADD16);
#endif
}

  void
BX_CPU_C::ADD_GwEGw(bxInstruction_c *i)
{
  Bit16u op1_16, op2_16, sum_16;
  unsigned nnn = i->nnn();
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op1_16 = BX_READ_16BIT_REG(nnn);
  op1_integrity = BX_READ_16BIT_INTEGRITY(nnn);
  op2_16 = BX_READ_16BIT_REG(i->rm());
  op2_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(nnn);
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmAdd16(sum_16, op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  sum_16 = op1_16 + op2_16;
#endif
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_GwEGw");
  }
#endif

  BX_WRITE_16BIT_REG(nnn, sum_16);
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
  BX_WRITE_16BIT_REG_INTEGRITY(nnn, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(nnn, SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif


#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_16(op1_16, op2_16, sum_16, BX_INSTR_ADD16);
#endif
}


  void
BX_CPU_C::ADD_AXIw(bxInstruction_c *i)
{
  Bit16u op1_16, op2_16, sum_16;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op1_16 = AX;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(0);
  }
#endif
  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  }
#endif

  sum_16 = op1_16 + op2_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_AXIw");
	else
		SumExpr = NULL;
  }
#endif

  AX = sum_16;

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(0, SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

  SET_FLAGS_OSZAPC_16(op1_16, op2_16, sum_16, BX_INSTR_ADD16);
}

  void
BX_CPU_C::ADC_EwGw(bxInstruction_c *i)
{
  bx_bool temp_CF;
  Bit16u op2_16, op1_16, sum_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  temp_CF = getB_CF();

  op2_16 = BX_READ_16BIT_REG(i->nnn());
  op2_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    sum_16 = op1_16 + op2_16 + temp_CF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_EwGw");
  }
#endif
    BX_WRITE_16BIT_REG(i->rm(), sum_16);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    sum_16 = op1_16 + op2_16 + temp_CF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_EwGw");
  }
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
    Write_RMW_virtual_word(sum_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_16_CF(op1_16, op2_16, sum_16, BX_INSTR_ADC16,
                         temp_CF);
}


  void
BX_CPU_C::ADC_GwEw(bxInstruction_c *i)
{
  bx_bool temp_CF;
  Bit16u op1_16, op2_16, sum_16;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  temp_CF = getB_CF();


  op1_16 = BX_READ_16BIT_REG(i->nnn());
  op1_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op2_16 = BX_READ_16BIT_REG(i->rm());
    op2_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
    }

  sum_16 = op1_16 + op2_16 + temp_CF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_GwEw");
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);

  BX_WRITE_16BIT_REG(i->nnn(), sum_16);
  BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->nnn(), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

  SET_FLAGS_OSZAPC_16_CF(op1_16, op2_16, sum_16, BX_INSTR_ADC16,
                         temp_CF);
}


  void
BX_CPU_C::ADC_AXIw(bxInstruction_c *i)
{
  bx_bool temp_CF;
  Bit16u op1_16, op2_16, sum_16;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  temp_CF = getB_CF();

  op1_16 = AX;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(0);
  }
#endif
  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  }
#endif

  sum_16 = op1_16 + op2_16 + temp_CF;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_AXIw");
	else
		SumExpr = NULL;
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);

  AX = sum_16;
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(0, SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

  SET_FLAGS_OSZAPC_16_CF(op1_16, op2_16, sum_16, BX_INSTR_ADC16,
                         temp_CF);
}




  void
BX_CPU_C::SBB_EwGw(bxInstruction_c *i)
{
  bx_bool temp_CF;
  Bit16u op2_16, op1_16, diff_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  temp_CF = getB_CF();

  op2_16 = BX_READ_16BIT_REG(i->nnn());
  op2_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    diff_16 = op1_16 - (op2_16 + temp_CF);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_EwGw");
  }
#endif
    BX_WRITE_16BIT_REG(i->rm(), diff_16);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    diff_16 = op1_16 - (op2_16 + temp_CF);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_EwGw");
  }
#endif
    Write_RMW_virtual_word(diff_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_16_CF(op1_16, op2_16, diff_16, BX_INSTR_SBB16,
                         temp_CF);
}


  void
BX_CPU_C::SBB_GwEw(bxInstruction_c *i)
{
  bx_bool temp_CF;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  temp_CF = getB_CF();

  Bit16u op1_16, op2_16, diff_16;

  op1_16 = BX_READ_16BIT_REG(i->nnn());
  op1_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op2_16 = BX_READ_16BIT_REG(i->rm());
    op2_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
    }

  diff_16 = op1_16 - (op2_16 + temp_CF);
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_GwEw");
  }
#endif

  BX_WRITE_16BIT_REG(i->nnn(), diff_16);
  BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->nnn(), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

  SET_FLAGS_OSZAPC_16_CF(op1_16, op2_16, diff_16, BX_INSTR_SBB16,
                         temp_CF);
}


  void
BX_CPU_C::SBB_AXIw(bxInstruction_c *i)
{
  bx_bool temp_CF;
  Bit16u op1_16, op2_16, diff_16;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  temp_CF = getB_CF();

  op1_16 = AX;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(0);
  }
#endif
  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  }
#endif

  diff_16 = op1_16 - (op2_16 + temp_CF);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_AXIw");
	else
		DiffExpr = NULL;
  }
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);

  AX = diff_16;
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(0, DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

  SET_FLAGS_OSZAPC_16_CF(op1_16, op2_16, diff_16, BX_INSTR_SBB16,
                         temp_CF);
}



  void
BX_CPU_C::SBB_EwIw(bxInstruction_c *i)
{
  bx_bool temp_CF;
  Bit16u op2_16, op1_16, diff_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  temp_CF = getB_CF();

  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    diff_16 = op1_16 - (op2_16 + temp_CF);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_EwIw");
	else
		DiffExpr = NULL;
  }
#endif
    BX_WRITE_16BIT_REG(i->rm(), diff_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    diff_16 = op1_16 - (op2_16 + temp_CF);
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SBB_EwIw");
	else
		DiffExpr = NULL;
  }
#endif
    Write_RMW_virtual_word(diff_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_16_CF(op1_16, op2_16, diff_16, BX_INSTR_SBB16,
                         temp_CF);
}


  void
BX_CPU_C::SUB_EwGw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16, diff_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  op2_16 = BX_READ_16BIT_REG(i->nnn());
  op2_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmSub16(diff_16, op1_16, op2_16, flags32);
    setEFlagsOSZAPC(flags32);
#else
    diff_16 = op1_16 - op2_16;
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_EwGw");
  }
#endif
    BX_WRITE_16BIT_REG(i->rm(), diff_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmSub16(diff_16, op1_16, op2_16, flags32);
    setEFlagsOSZAPC(flags32);
#else
    diff_16 = op1_16 - op2_16;
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_EwGw");
  }
#endif
    Write_RMW_virtual_word(diff_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_16(op1_16, op2_16, diff_16, BX_INSTR_SUB16);
#endif
}


  void
BX_CPU_C::SUB_GwEw(bxInstruction_c *i)
{
  Bit16u op1_16, op2_16, diff_16;
  unsigned nnn = i->nnn();
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  op1_16 = BX_READ_16BIT_REG(nnn);
  op1_integrity = BX_READ_16BIT_INTEGRITY(nnn);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(nnn);
  }
#endif

  if (i->modC0()) {
    op2_16 = BX_READ_16BIT_REG(i->rm());
    op2_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmSub16(diff_16, op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  diff_16 = op1_16 - op2_16;
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_GwEw");
  }
#endif
  BX_WRITE_16BIT_REG(nnn, diff_16);
  BX_WRITE_16BIT_REG_INTEGRITY(nnn, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(nnn, DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_16(op1_16, op2_16, diff_16, BX_INSTR_SUB16);
#endif
}

  void
BX_CPU_C::SUB_AXIw(bxInstruction_c *i)
{
  Bit16u op1_16, op2_16, diff_16;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;

  op1_16 = AX;
  op1_integrity = EAX_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(0);
  }
#endif
  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  }
#endif


#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmSub16(diff_16, op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  diff_16 = op1_16 - op2_16;
#endif

  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_AXIw");
	else
		DiffExpr = NULL;
  }
#endif

  AX = diff_16;
  //LVAL_EAX_INTEGRITY = result_integrity;
  BX_WRITE_32BIT_REG_INTEGRITY(0, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(0, DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_16(op1_16, op2_16, diff_16, BX_INSTR_SUB16);
#endif
}


  void
BX_CPU_C::CMP_EwGw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16;
  Bit8u op1_integrity;
  Expression *Op1Expr, *Op2Expr;

  op2_16 = BX_READ_16BIT_REG(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmCmp16(op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit16u diff_16;
  diff_16 = op1_16 - op2_16;

  SET_FLAGS_OSZAPC_16_WITHEXPR(op1_16, op2_16, diff_16, BX_INSTR_CMP16, Op1Expr, Op2Expr);
#endif
}


  void
BX_CPU_C::CMP_GwEw(bxInstruction_c *i)
{
  Bit16u op1_16, op2_16;
  Bit8u op2_integrity;
  Expression *Op1Expr, *Op2Expr;

  op1_16 = BX_READ_16BIT_REG(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif
  if (i->modC0()) {
    op2_16 = BX_READ_16BIT_REG(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_word(i->seg(), RMAddr(i), &op2_16, &op2_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmCmp16(op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit16u diff_16;
  diff_16 = op1_16 - op2_16;

  SET_FLAGS_OSZAPC_16_WITHEXPR(op1_16, op2_16, diff_16, BX_INSTR_CMP16, Op1Expr, Op2Expr);
#endif
}


  void
BX_CPU_C::CMP_AXIw(bxInstruction_c *i)
{
  Bit16u op1_16, op2_16;
  Expression *Op1Expr, *Op2Expr;

  op1_16 = AX;
  op2_16 = i->Iw();
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(0);
	Op2Expr = NULL;
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmCmp16(op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit16u diff_16;
  diff_16 = op1_16 - op2_16;

  SET_FLAGS_OSZAPC_16_WITHEXPR(op1_16, op2_16, diff_16, BX_INSTR_CMP16, Op1Expr, Op2Expr);
#endif
}


  void
BX_CPU_C::CBW(bxInstruction_c *i)
{
  /* CBW: no flags are effected */

  AX = (Bit8s) AL;
}

  void
BX_CPU_C::CWD(bxInstruction_c *i)
{
  /* CWD: no flags are affected */

  if (AX & 0x8000) {
    DX = 0xFFFF;
    }
  else {
    DX = 0x0000;
    }
}


  void
BX_CPU_C::XADD_EwGw(bxInstruction_c *i)
{
#if (BX_CPU_LEVEL >= 4) || (BX_CPU_LEVEL_HACKED >= 4)

  Bit16u op2_16, op1_16, sum_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  /* XADD dst(r/m), src(r)
   * temp <-- src + dst         | sum = op2 + op1
   * src  <-- dst               | op2 = op1
   * dst  <-- tmp               | op1 = sum
   */

  op2_16 = BX_READ_16BIT_REG(i->nnn());
  op2_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    sum_16 = op1_16 + op2_16;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XADD_EwGw");
  }
#endif
    // and write destination into source
    // Note: if both op1 & op2 are registers, the last one written
    //       should be the sum, as op1 & op2 may be the same register.
    //       For example:  XADD AL, AL
    BX_WRITE_16BIT_REG(i->nnn(), op1_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->nnn(), Op1Expr);
  }
#endif
    BX_WRITE_16BIT_REG(i->rm(), sum_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), SumExpr);
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    sum_16 = op1_16 + op2_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "XADD_EwGw");
  }
#endif
    Write_RMW_virtual_word(sum_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), SumExpr);
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    /* and write destination into source */
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
    BX_WRITE_16BIT_REG(i->nnn(), op1_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->nnn(), op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->nnn(), Op1Expr);
  }
#endif
    }

  SET_FLAGS_OSZAPC_16(op1_16, op2_16, sum_16, BX_INSTR_XADD16);
#else
  BX_PANIC(("XADD_EvGv: not supported on < 80486"));
#endif
}



  void
BX_CPU_C::ADD_EEwIw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16, sum_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  }
#endif

  read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmAdd16(sum_16, op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  sum_16 = op1_16 + op2_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_EEwIw");
	else
		SumExpr = NULL;
  }
#endif
#endif
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
  Write_RMW_virtual_word(sum_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_16(op1_16, op2_16, sum_16, BX_INSTR_ADD16);
#endif
}

  void
BX_CPU_C::ADD_EGwIw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16, sum_16;
  Bit8u op1_integrity, op2_integrity, result_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  }
#endif

  op1_16 = BX_READ_16BIT_REG(i->rm());
  op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmAdd16(sum_16, op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  sum_16 = op1_16 + op2_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADD_EGwIw");
	else
		SumExpr = NULL;
  }
#endif
#endif
  result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
  BX_WRITE_16BIT_REG(i->rm(), sum_16);
  BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_16(op1_16, op2_16, sum_16, BX_INSTR_ADD16);
#endif
}

  void
BX_CPU_C::ADC_EwIw(bxInstruction_c *i)
{
  bx_bool temp_CF;
  Bit16u op2_16, op1_16, sum_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *SumExpr;

  temp_CF = getB_CF();

  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    sum_16 = op1_16 + op2_16 + temp_CF;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_EwIw");
	else
		SumExpr = NULL;
  }
#endif
    BX_WRITE_16BIT_REG(i->rm(), sum_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    sum_16 = op1_16 + op2_16 + temp_CF;
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		SumExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "ADC_EwIw");
	else
		SumExpr = NULL;
  }
#endif
    Write_RMW_virtual_word(sum_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), SumExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_16_CF(op1_16, op2_16, sum_16, BX_INSTR_ADC16,
                         temp_CF);
}


  void
BX_CPU_C::SUB_EwIw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16, diff_16;
  Bit8u result_integrity;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr, *DiffExpr;


  op2_16 = i->Iw();
  op2_integrity = IMMEDIATE_INTEGRITY;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleConstant(i->Iw(), Op2Expr);
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmSub16(diff_16, op1_16, op2_16, flags32);
    setEFlagsOSZAPC(flags32);
#else
    diff_16 = op1_16 - op2_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_EwIw");
	else
		DiffExpr = NULL;
  }
#endif
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
    BX_WRITE_16BIT_REG(i->rm(), diff_16);
    BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmSub16(diff_16, op1_16, op2_16, flags32);
    setEFlagsOSZAPC(flags32);
#else
    diff_16 = op1_16 - op2_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	if (!EffectivelyNull(Op1Expr))
		DiffExpr = (Expression *) new Operation(Op1Expr, Op2Expr, "SUB_EwIw");
	else
		DiffExpr = NULL;
  }
#endif
#endif
    result_integrity = low_water_mark(op1_integrity, op2_integrity, INTEG_WORD, INTEG_WORD);
    Write_RMW_virtual_word(diff_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), DiffExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
	//if (Op2Expr != NULL) delete Op2Expr;
  }
#endif
    }

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAPC_16(op1_16, op2_16, diff_16, BX_INSTR_SUB16);
#endif
}

  void
BX_CPU_C::CMP_EwIw(bxInstruction_c *i)
{
  Bit16u op2_16, op1_16;
  Bit8u op1_integrity;
  Expression *Op1Expr, *Op2Expr;
  
  op2_16 = i->Iw();
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = NULL;
  }
#endif

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    }
  else {
    read_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    }

#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  Bit32u flags32;

  asmCmp16(op1_16, op2_16, flags32);
  setEFlagsOSZAPC(flags32);
#else
  Bit16u diff_16;
  diff_16 = op1_16 - op2_16;

  SET_FLAGS_OSZAPC_16_WITHEXPR(op1_16, op2_16, diff_16, BX_INSTR_CMP16, Op1Expr, Op2Expr);
#endif
}



  void
BX_CPU_C::NEG_Ew(bxInstruction_c *i)
{
  Bit16u op1_16, diff_16;
  Bit8u result_integrity = 0xFF;
  Bit8u op1_integrity;
  Expression *Op1Expr, *ResultExpr;


  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    diff_16 = 0 - op1_16;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	ResultExpr = (Expression *) new Operation(Op1Expr, NULL, "NEG_Ew");
  }
#endif

    BX_WRITE_16BIT_REG(i->rm(), diff_16);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), ResultExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    diff_16 = 0 - op1_16;
    result_integrity = op1_integrity;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	ResultExpr = (Expression *) new Operation(Op1Expr, NULL, "NEG_Ew");
  }
#endif
    Write_RMW_virtual_word(diff_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), ResultExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
  }
#endif
    }

  SET_FLAGS_OSZAPC_16(op1_16, 0, diff_16, BX_INSTR_NEG16);
}


  void
BX_CPU_C::INC_Ew(bxInstruction_c *i)
{
  Bit16u op1_16;
  Bit8u result_integrity = 0xFF;
  Bit8u op1_integrity;
  Expression *Op1Expr, *ResultExpr;

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    op1_16++;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	ResultExpr = (Expression *) new Operation(Op1Expr, NULL, "INC_Ew");
  }
#endif
    BX_WRITE_16BIT_REG(i->rm(), op1_16);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), ResultExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    op1_16++;
    result_integrity = op1_integrity;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	ResultExpr = (Expression *) new Operation(Op1Expr, NULL, "INC_Ew");
  }
#endif
    Write_RMW_virtual_word(op1_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), ResultExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
  }
#endif
    }

  SET_FLAGS_OSZAP_16(0, 0, op1_16, BX_INSTR_INC16);
}


  void
BX_CPU_C::DEC_Ew(bxInstruction_c *i)
{
  Bit16u op1_16;
  Bit8u result_integrity = 0xFF;
  Bit8u op1_integrity;
  Expression *Op1Expr, *ResultExpr;
  
  if (i->modC0()) {
#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmDec16(BX_CPU_THIS_PTR gen_reg[i->rm()].word.rx, flags32);
    setEFlagsOSZAP(flags32);
#else
    op1_16 = BX_READ_16BIT_REG(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    op1_16--;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	ResultExpr = (Expression *) new Operation(Op1Expr, NULL, "DEC_Ew");
  }
#endif
    BX_WRITE_16BIT_REG(i->rm(), op1_16);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), ResultExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
  }
#endif
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
#if (defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
    Bit32u flags32;

    asmDec16(op1_16, flags32);
    setEFlagsOSZAP(flags32);
  	printf("SupportHostsAsms is set\n");
#else
    op1_16--;
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	ResultExpr = (Expression *) new Operation(Op1Expr, NULL, "DEC_Ew");
  }
#endif
#endif
    result_integrity = op1_integrity;
    Write_RMW_virtual_word(op1_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), ResultExpr);
	//if (Op1Expr != NULL) delete Op1Expr;
  }
#endif
    }

#if !(defined(__i386__) && defined(__GNUC__) && BX_SupportHostAsms)
  SET_FLAGS_OSZAP_16(0, 0, op1_16, BX_INSTR_DEC16);
#endif
}


  void
BX_CPU_C::CMPXCHG_EwGw(bxInstruction_c *i)
{
#if (BX_CPU_LEVEL >= 4) || (BX_CPU_LEVEL_HACKED >= 4)

  Bit16u op2_16, op1_16, diff_16;
  Bit8u result_integrity = 0xFF;
  Bit8u op1_integrity, op2_integrity;
  Expression *Op1Expr, *Op2Expr;

  if (i->modC0()) {
    op1_16 = BX_READ_16BIT_REG(i->rm());
    op1_integrity = BX_READ_16BIT_INTEGRITY(i->rm());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op1Expr = (Expression *) MakeNewDoubleReg(i->rm());
  }
#endif
    }
  else {
    read_RMW_virtual_word(i->seg(), RMAddr(i), &op1_16, &op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	MakeNewDoubleMem(i->seg(), RMAddr(i), Op1Expr);
  }
#endif
    }

#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(0);
  }
#endif

  diff_16 = AX - op1_16;

  SET_FLAGS_OSZAPC_16_WITHEXPR(AX, op1_16, diff_16, BX_INSTR_CMP16, Op1Expr, Op2Expr);

  if (diff_16 == 0) {  // if accumulator == dest
    // ZF = 1
    set_ZF(1);
    // dest <-- src
    op2_16 = BX_READ_16BIT_REG(i->nnn());
    op2_integrity = BX_READ_16BIT_INTEGRITY(i->nnn());
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	Op2Expr = (Expression *) MakeNewDoubleReg(i->nnn());
  }
#endif

    result_integrity = op2_integrity;
    if (i->modC0()) {
      BX_WRITE_16BIT_REG(i->rm(), op2_16);
      BX_WRITE_16BIT_REG_INTEGRITY(i->rm(), result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(i->rm(), Op2Expr);
  }
#endif
      }
    else {
      Write_RMW_virtual_word(op2_16, result_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
  	WriteSymbolicDoubleMem(i->seg(), RMAddr(i), Op2Expr);
  }
#endif
      }
    }
  else {
    // ZF = 0
    set_ZF(0);
    // accumulator <-- dest
    AX = op1_16;
    //LVAL_EAX_INTEGRITY = op1_integrity;
    BX_WRITE_32BIT_REG_INTEGRITY(0, op1_integrity);
#if BX_DEBUGGER
  if (BX_CPU_THIS_PTR sexecmode)
  {
	WriteSymbolicDoubleRegister(0, Op1Expr);
  }
#endif
    }

#else
  BX_PANIC(("CMPXCHG_EwGw:"));
#endif
}
