#ifndef lint
static char const 
yyrcsid[] = "$FreeBSD: src/usr.bin/yacc/skeleton.c,v 1.28 2000/01/17 02:04:06 bde Exp $";
#endif
#include <stdlib.h>
#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define YYLEX yylex()
#define YYEMPTY -1
#define yyclearin (yychar=(YYEMPTY))
#define yyerrok (yyerrflag=0)
#define YYRECOVERING() (yyerrflag!=0)
static int yygrowstack();
#define yyparse bxparse
#define yylex bxlex
#define yyerror bxerror
#define yychar bxchar
#define yyval bxval
#define yylval bxlval
#define yydebug bxdebug
#define yynerrs bxnerrs
#define yyerrflag bxerrflag
#define yyss bxss
#define yyssp bxssp
#define yyvs bxvs
#define yyvsp bxvsp
#define yylhs bxlhs
#define yylen bxlen
#define yydefred bxdefred
#define yydgoto bxdgoto
#define yysindex bxsindex
#define yyrindex bxrindex
#define yygindex bxgindex
#define yytable bxtable
#define yycheck bxcheck
#define yyname bxname
#define yyrule bxrule
#define yysslim bxsslim
#define yystacksize bxstacksize
#define YYPREFIX "bx"
#line 6 "parser.y"
#include <stdio.h>
#include <stdlib.h>
#include "bx_debug.h"

#if BX_DEBUGGER
/*
NOTE: The #if comes from parser.y.  The makefile will add the matching #endif
at the end of parser.c.  I don't know any way to ask yacc to put it at the end.
*/

/* %left '-' '+'*/
/* %left '*' '/'*/
/* %right*/
/* %nonassoc UMINUS*/
#line 23 "parser.y"
typedef union {
  char    *sval;
  Bit32u   uval;
  Bit64u   ulval;
  bx_num_range   uval_range;
  } YYSTYPE;
#line 65 "y.tab.c"
#define YYERRCODE 256
#define BX_TOKEN_CONTINUE 257
#define BX_TOKEN_STEPN 258
#define BX_TOKEN_NEXT_STEP 259
#define BX_TOKEN_SET 260
#define BX_TOKEN_DEBUGGER 261
#define BX_TOKEN_VBREAKPOINT 262
#define BX_TOKEN_LBREAKPOINT 263
#define BX_TOKEN_PBREAKPOINT 264
#define BX_TOKEN_DEL_BREAKPOINT 265
#define BX_TOKEN_INFO 266
#define BX_TOKEN_QUIT 267
#define BX_TOKEN_PROGRAM 268
#define BX_TOKEN_REGISTERS 269
#define BX_TOKEN_LABELS 270
#define BX_TOKEN_FPU 271
#define BX_TOKEN_ALL 272
#define BX_TOKEN_IDT 273
#define BX_TOKEN_GDT 274
#define BX_TOKEN_LDT 275
#define BX_TOKEN_TSS 276
#define BX_TOKEN_DIRTY 277
#define BX_TOKEN_LINUX 278
#define BX_TOKEN_CONTROL_REGS 279
#define BX_TOKEN_EXAMINE 280
#define BX_TOKEN_LABEL 281
#define BX_TOKEN_XFORMAT 282
#define BX_TOKEN_SETPMEM 283
#define BX_TOKEN_SYMBOLNAME 284
#define BX_TOKEN_QUERY 285
#define BX_TOKEN_PENDING 286
#define BX_TOKEN_TAKE 287
#define BX_TOKEN_DMA 288
#define BX_TOKEN_IRQ 289
#define BX_TOKEN_DUMP_CPU 290
#define BX_TOKEN_SET_CPU 291
#define BX_TOKEN_DIS 292
#define BX_TOKEN_ON 293
#define BX_TOKEN_OFF 294
#define BX_TOKEN_DISASSEMBLE 295
#define BX_TOKEN_INSTRUMENT 296
#define BX_TOKEN_START 297
#define BX_TOKEN_STOP 298
#define BX_TOKEN_RESET 299
#define BX_TOKEN_PRINT 300
#define BX_TOKEN_LOADER 301
#define BX_TOKEN_STRING 302
#define BX_TOKEN_DOIT 303
#define BX_TOKEN_CRC 304
#define BX_TOKEN_TRACEON 305
#define BX_TOKEN_TRACEOFF 306
#define BX_TOKEN_PTIME 307
#define BX_TOKEN_TIMEBP_ABSOLUTE 308
#define BX_TOKEN_TIMEBP 309
#define BX_TOKEN_RECORD 310
#define BX_TOKEN_PLAYBACK 311
#define BX_TOKEN_MODEBP 312
#define BX_TOKEN_PRINT_STACK 313
#define BX_TOKEN_WATCH 314
#define BX_TOKEN_UNWATCH 315
#define BX_TOKEN_READ 316
#define BX_TOKEN_WRITE 317
#define BX_TOKEN_SHOW 318
#define BX_TOKEN_SYMBOL 319
#define BX_TOKEN_GLOBAL 320
#define BX_TOKEN_WHERE 321
#define BX_TOKEN_PRINT_STRING 322
#define BX_TOKEN_DIFF_MEMORY 323
#define BX_TOKEN_SYNC_MEMORY 324
#define BX_TOKEN_SYNC_CPU 325
#define BX_TOKEN_FAST_FORWARD 326
#define BX_TOKEN_PHY_2_LOG 327
#define BX_TOKEN_NUMERIC 328
#define BX_TOKEN_LONG_NUMERIC 329
#define BX_TOKEN_INFO_ADDRESS 330
#define BX_TOKEN_NE2000 331
#define BX_TOKEN_PAGE 332
#define BX_TOKEN_CS 333
#define BX_TOKEN_ES 334
#define BX_TOKEN_SS 335
#define BX_TOKEN_DS 336
#define BX_TOKEN_FS 337
#define BX_TOKEN_GS 338
#define BX_TOKEN_ALWAYS_CHECK 339
#define BX_TOKEN_MATHS 340
#define BX_TOKEN_ADD 341
#define BX_TOKEN_SUB 342
#define BX_TOKEN_MUL 343
#define BX_TOKEN_DIV 344
#define BX_TOKEN_V2L 345
#define BX_TOKEN_TRACEREGON 346
#define BX_TOKEN_TRACEREGOFF 347
#define BX_TOKEN_HELP 348
#define BX_TOKEN_SEXECON 349
#define BX_TOKEN_SEXECOFF 350
#define BX_TOKEN_LOGON 351
#define BX_TOKEN_LOGOFF 352
#define BX_TOKEN_REPLAYON 353
#define BX_TOKEN_REPLAYOFF 354
#define BX_TOKEN_RECOVERYON 355
#define BX_TOKEN_RECOVERYOFF 356
#define BX_TOKEN_CTHULHUON 357
#define BX_TOKEN_CTHULHUOFF 358
#define BX_TOKEN_TIMINGON 359
#define BX_TOKEN_TIMINGOFF 360
#define BX_TOKEN_CHEESYCP 361
#define BX_TOKEN_CHEESYEXIT 362
#define BX_TOKEN_CMOSON 363
#define BX_TOKEN_CMOSOFF 364
#define BX_TOKEN_PRINTTIMEON 365
#define BX_TOKEN_PRINTTIMEOFF 366
#define BX_TOKEN_MEATMODEON 367
#define BX_TOKEN_MEATMODEOFF 368
#define BX_TOKEN_UBERDEBUGON 369
#define BX_TOKEN_UBERDEBUGOFF 370
#define BX_TOKEN_SPRINGS 371
#define BX_TOKEN_PREDICATES 372
#define BX_TOKEN_ALLPREDICATES 373
#define BX_TOKEN_SUMMARIZE 374
#define BX_TOKEN_GARBAGE 375
#define BX_TOKEN_TIMINGADDR 376
#define BX_TOKEN_TAKEAGANDERAT 377
#define BX_TOKEN_VTIMINGADDR 378
#define BX_TOKEN_COUNTEXPR 379
#define BX_TOKEN_CLEARSYMBSTOR 380
#define BX_TOKEN_INVERTPRED 381
#define BX_TOKEN_RMINVERTPRED 382
#define BX_TOKEN_LSINVERTPRED 383
#define BX_TOKEN_SETPREDFILT 384
#define BX_TOKEN_CLEARPREDFILT 385
#define BX_TOKEN_ADDPREDFILT 386
#define BX_TOKEN_PREDFILT 387
#define BX_TOKEN_PREDCR3 388
#define BX_TOKEN_TBREAK 389
#define BX_TOKEN_DOUPDATECOUNT 390
#define BX_TOKEN_SETUCERROR 391
#define BX_TOKEN_TIMEDELTA 392
#define BX_TOKEN_PRINTUC 393
#define BX_TOKEN_SPEED 394
#define BX_TOKEN_DATAFORLABELS 395
#define BX_TOKEN_REMOVESKIPPY 396
#define BX_TOKEN_SETEIP 397
#define BX_TOKEN_PUTLABEL 398
#define BX_TOKEN_ADDRSINTEREST 399
#define BX_TOKEN_PRINTCR3 400
#define BX_TOKEN_SIGFROMGAMMA 401
const short bxlhs[] = {                                        -1,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,   91,   91,   91,   91,   91,   91,   91,
   91,   91,   91,    1,    1,    1,    1,    1,    1,   81,
   81,   82,   83,   84,   84,   87,   87,   80,   25,   26,
   27,   28,   29,   30,   31,   32,   33,   34,   35,   36,
   37,   38,   39,   40,   41,   42,   43,   44,   45,   46,
   47,   48,   85,   85,   86,   86,   86,   86,   86,   86,
   86,   86,   88,   88,   88,   89,   90,    5,    6,    6,
    7,    7,    7,    8,    8,    8,    8,    8,    8,    8,
    9,    9,    9,    9,    9,    9,    9,    9,    9,    9,
    9,    9,    9,    9,    9,    9,    2,    2,    4,    4,
    3,    3,    3,   10,   11,   12,   13,   13,   13,   13,
   14,   14,   14,   49,   50,   51,   52,   58,   59,   60,
   61,   62,   63,   64,   65,   66,   67,   68,   69,   70,
   71,   72,   53,   54,   55,   56,   57,   73,   74,   75,
   76,   77,   78,   79,   15,   16,   17,   17,   17,   18,
   19,   20,   20,   20,   20,   21,   22,   23,   24,   24,
   24,   24,   24,   92,   93,   94,   95,   95,
};
const short bxlen[] = {                                         2,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
    1,    0,    1,    2,    3,    3,    3,    3,    3,    3,
    5,    4,    4,    1,    1,    1,    1,    1,    1,    3,
    3,    3,    3,    3,    2,    3,    2,    2,    2,    2,
    2,    2,    2,    2,    2,    2,    2,    2,    2,    2,
    2,    2,    2,    2,    3,    2,    2,    2,    2,    2,
    2,    2,    2,    3,    3,    3,    2,    2,    4,    4,
    4,    4,    3,    4,    5,    2,    3,    2,    2,    3,
    4,    4,    5,    2,    5,    2,    3,    2,    3,    4,
    3,    3,    3,    3,    3,    3,    3,    4,    4,    4,
    4,    3,    3,    3,    5,    7,    0,    1,    0,    1,
    1,    2,    3,    2,    3,    2,    4,    3,    3,    2,
    2,    3,    4,    2,    4,    4,    4,    2,    4,    4,
    2,    2,    2,    4,    4,    3,    3,    3,    3,    3,
    3,    4,    3,    3,    3,    4,    3,    4,    3,    3,
    4,    4,    2,    4,    5,    3,    3,    4,    3,    2,
    3,    3,    3,    3,    3,    3,    3,    4,    5,    5,
    5,    5,    3,    5,    2,    2,    3,    2,
};
const short bxdefred[] = {                                      0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,   93,    0,    1,    2,    3,    4,    5,    6,    7,
    8,    9,   10,   11,   12,   13,   14,   15,   16,   17,
   18,   19,   20,   21,   22,   23,   24,   25,   26,   27,
   28,   29,   30,   31,   32,   33,   34,   35,   36,   37,
   38,   39,   40,   41,   42,   43,   44,   45,   46,   47,
   48,   49,   50,   51,   52,   53,   54,   55,   56,   57,
   58,   59,   60,   61,   62,   63,   64,   65,   66,   67,
   68,   69,   70,   71,   72,   73,   74,   75,   76,   77,
   78,   79,   80,   81,   82,   83,   84,   85,   86,   87,
   88,   89,   90,   91,  158,    0,  159,    0,    0,    0,
  164,    0,  166,    0,  168,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,  196,    0,    0,  200,    0,  201,    0,    0,    0,
    0,  194,  240,    0,  190,    0,    0,    0,    0,    0,
    0,    0,    0,  119,  120,  118,    0,    0,    0,    0,
    0,  115,    0,  143,    0,    0,    0,    0,  147,    0,
    0,  148,    0,  117,    0,    0,  156,    0,   94,    0,
    0,    0,    0,    0,    0,  104,  105,  106,  107,  108,
  109,    0,    0,    0,    0,    0,    0,    0,    0,  255,
  256,    0,  258,  121,  122,  123,  124,  125,  126,  127,
  128,  129,  130,  131,  132,  133,  134,    0,  136,  137,
  138,  139,  140,  141,  142,  204,    0,    0,    0,    0,
    0,    0,    0,    0,  208,    0,    0,  211,  212,  213,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,  233,    0,  160,    0,    0,    0,
    0,  167,  169,    0,  195,  171,  172,  173,  174,  175,
  176,    0,    0,    0,    0,  177,  182,  183,    0,  184,
    0,  198,  199,    0,  202,    0,  236,    0,  237,  239,
  192,    0,  241,  242,  243,  244,  245,  246,  247,    0,
  111,  110,  112,  113,  114,  144,  146,  145,    0,    0,
    0,    0,  116,    0,  153,    0,  157,   95,   96,   97,
   98,   99,  100,    0,    0,    0,  253,    0,    0,    0,
    0,    0,  257,  135,    0,    0,    0,  223,  224,  225,
    0,  227,    0,    0,    0,    0,  216,  217,  218,  219,
  220,  221,    0,    0,  229,  230,    0,    0,    0,    0,
  161,  162,    0,  170,  178,  179,  180,  181,    0,  197,
  203,    0,  238,  193,  248,  149,  151,  150,  152,  154,
    0,    0,  102,  103,    0,    0,    0,    0,    0,  205,
  206,  207,  226,  209,  210,  214,  215,  222,  228,  231,
  232,  234,  163,  165,    0,  185,  235,  155,  101,  249,
  250,  251,  252,  254,    0,  186,
};
const short bxdgoto[] = {                                     103,
  282,    0,  235,  236,  104,  105,  106,  107,  108,  109,
  110,  111,  112,  113,  114,  115,  116,  117,  118,  119,
  120,  121,  122,  123,  124,  125,  126,  127,  128,  129,
  130,  131,  132,  133,  134,  135,  136,  137,  138,  139,
  140,  141,  142,  143,  144,  145,  146,  147,  148,  149,
  150,  151,  152,  153,  154,  155,  156,  157,  158,  159,
  160,  161,  162,  163,  164,  165,  166,  167,  168,  169,
  170,  171,  172,  173,  174,  175,  176,  177,  178,  179,
  180,  181,  182,  183,  184,  185,  186,  187,  188,  189,
  190,  191,  192,  193,  194,
};
const short bxsindex[] = {                                    -10,
    1,   -4, -251,   -3,   -2,   -7, -308, -247,   24,   -6,
   -1, -288, -238, -250,   59,   60, -257, -244, -229, -256,
 -253,   66,   67,   68, -249, -248, -223, -220,    8,    3,
  136,    2,   26, -283,   73, -243,   76, -232, -230, -241,
 -240, -291, -239, -292, -291,   80,   81,   92,   82,   83,
   84,   85,   86,   87,   88,   89,   90,   91,   93,   94,
   95,   96, -221,   98,   99,  100,  101,  102,  103,  104,
  105, -212, -211, -210, -209, -208, -207, -206, -205,  114,
 -203, -202,  117,  118,  119, -198, -197, -196, -195, -194,
 -193, -192, -191, -190, -189, -188, -187, -186, -185,  134,
 -183,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,  137,    0,   97, -228,  106,
    0,  138,    0,  139,    0, -178,  141,  142,  143,  144,
  145,  146,  147, -257, -257, -257, -257,  149,  150,  151,
   -9,    0,    4,  152,    0,    5,    0, -165,  155,    6,
  156,    0,    0,  -56,    0,  157,  158,  159,  160,  161,
  162,  163, -154,    0,    0,    0,  165,  166,  167,  168,
  169,    0,  170,    0,  171,  172, -145, -144,    0, -143,
 -142,    0,  177,    0,   64, -114,    0,  179,    0,  180,
  181,  182,  183,  184,  185,    0,    0,    0,    0,    0,
    0,  140, -226,  186, -131, -129, -128, -127,  148,    0,
    0,  192,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,  193,    0,    0,
    0,    0,    0,    0,    0,    0, -124, -123, -121,  198,
  199,  200, -117,  202,    0, -115, -113,    0,    0,    0,
 -112, -111,  204,  208,  209,  210,  211,  212, -105, -104,
  215,  216, -101, -100,    0,  -99,    0,  -98,  221,  222,
  -95,    0,    0,  224,    0,    0,    0,    0,    0,    0,
    0,  225,  226,  227,  228,    0,    0,    0,  -89,    0,
  230,    0,    0,  231,    0,  -86,    0,  233,    0,    0,
    0,  -84,    0,    0,    0,    0,    0,    0,    0,  235,
    0,    0,    0,    0,    0,    0,    0,    0,  236,  239,
  241,  248,    0,  249,    0,  -68,    0,    0,    0,    0,
    0,    0,    0,  -67,  252,  253,    0,  -63,  -62,  -61,
  -60,  -59,    0,    0,  264,  268,  269,    0,    0,    0,
  272,    0,  273,  274,  277,  278,    0,    0,    0,    0,
    0,    0,  279,  280,    0,    0,  282,  296,  297,  385,
    0,    0,  386,    0,    0,    0,    0,    0,   -5,    0,
    0,  387,    0,    0,    0,    0,    0,    0,    0,    0,
  388,  389,    0,    0,  390,  391,  392,  393,  394,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,   77,    0,    0,    0,    0,    0,
    0,    0,    0,    0,  396,    0,
};
const short bxrindex[] = {                                    407,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,  398,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,  398,  398,  398,  398,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,  399,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,
};
const short bxgindex[] = {                                      0,
  365,    0,    0, -157,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,
};
#define YYTABLESIZE 453
const short bxtable[] = {                                     102,
  370,  382,  205,  225,  496,  197,  201,  203,  227,  284,
  195,  262,  254,  372,  375,  379,  208,  252,  265,  207,
  209,  210,  211,  212,  213,  214,  215,  216,  217,  218,
  219,  220,  198,  222,  206,  264,  266,  230,  231,  228,
  199,  276,  277,  278,  279,  280,  281,  229,  285,  286,
  287,  288,  237,  238,  239,  240,  362,  363,  364,  365,
  270,  271,  272,  273,  349,  350,  415,  416,  232,  233,
  234,  242,  241,  405,  243,  244,  245,  246,  249,  247,
  248,  250,  267,  221,  268,  269,  274,  275,  283,  290,
  291,  294,  295,  296,  297,  298,  299,  300,  301,  302,
  303,  293,  304,  305,  306,  307,  308,  309,  310,  311,
  312,  313,  314,  315,  316,  317,  318,  319,  320,  321,
  322,  323,  324,  325,  326,  327,  328,  329,  330,  331,
  332,  333,  334,  335,  336,  337,  338,  339,  340,  341,
  342,  343,  344,  345,  346,  259,  347,  352,  353,  354,
  355,  356,  357,  358,  359,  360,  361,  348,  366,  367,
  368,  373,  376,  351,  377,  380,  383,  384,  385,  386,
  387,  388,  389,  390,  391,  392,  393,  394,  395,  396,
  397,  398,  399,  400,  401,  402,  403,  406,  407,  408,
  409,  410,  411,  412,  413,  417,  418,  414,  419,  420,
  421,  423,  424,  425,  426,  422,  427,  428,  429,  430,
  431,  432,  433,  437,  434,  435,  436,  438,  439,  440,
  441,  442,  443,  444,  445,  446,  447,  448,  449,  450,
  451,  452,  453,  454,  455,  456,  457,  458,  459,  460,
  461,  462,  463,  464,  465,  466,    1,    2,  467,    3,
  468,    4,    5,    6,    7,    8,    9,  469,  470,  471,
  472,  473,  474,  495,  475,  476,  477,  478,  479,   10,
   11,  381,   12,  480,   13,  223,   14,  481,  482,   15,
   16,  483,  484,  485,   17,   18,  486,  487,  488,  489,
   19,  490,   20,   21,   22,   23,   24,   25,   26,   27,
   28,   29,   30,   31,   32,  491,  492,   33,   34,  251,
   35,   36,   37,   38,   39,   40,   41,  260,  261,   42,
  204,  224,  369,  196,  200,  202,  226,  263,   43,   44,
  253,  371,  374,  378,   45,   46,   47,   48,   49,   50,
   51,   52,   53,   54,   55,   56,   57,   58,   59,   60,
   61,   62,   63,   64,   65,   66,   67,   68,   69,   70,
   71,   72,   73,   74,   75,   76,   77,   78,   79,   80,
   81,   82,   83,   84,   85,   86,   87,   88,   89,   90,
   91,   92,   93,   94,   95,   96,   97,   98,   99,  100,
  101,  404,  255,  292,  493,  494,  497,  498,  499,  500,
  501,  502,  503,  504,  505,  506,   92,  189,  191,  289,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,  256,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,  257,  258,
};
const short bxcheck[] = {                                      10,
   10,   58,   10,   10,   10,   10,   10,   10,   10,  302,
   10,   10,   10,   10,   10,   10,  264,   10,  302,  328,
  268,  269,  270,  271,  272,  273,  274,  275,  276,  277,
  278,  279,  284,   10,   42,   10,  320,  288,  289,  328,
  292,  333,  334,  335,  336,  337,  338,  286,  341,  342,
  343,  344,  297,  298,  299,  300,  214,  215,  216,  217,
  293,  294,  293,  294,  293,  294,  293,  294,   10,   10,
  328,  328,  302,   10,  328,   10,   10,   10,  302,  329,
  329,  302,   10,  331,  328,   10,  328,  328,  328,   10,
   10,   10,   10,   10,   10,   10,   10,   10,   10,   10,
   10,   10,   10,   10,   10,   10,  328,   10,   10,   10,
   10,   10,   10,   10,   10,  328,  328,  328,  328,  328,
  328,  328,  328,   10,  328,  328,   10,   10,   10,  328,
  328,  328,  328,  328,  328,  328,  328,  328,  328,  328,
  328,  328,  328,   10,  328,   10,   10,   10,   10,  328,
   10,   10,   10,   10,   10,   10,   10,   61,   10,   10,
   10,   10,  328,   58,   10,   10,   10,   10,   10,   10,
   10,   10,   10,  328,   10,   10,   10,   10,   10,   10,
   10,   10,  328,  328,  328,  328,   10,  302,   10,   10,
   10,   10,   10,   10,   10,   10,  328,   58,  328,  328,
  328,   10,   10,  328,  328,   58,  328,   10,   10,   10,
  328,   10,  328,   10,  328,  328,  328,   10,   10,   10,
   10,   10,  328,  328,   10,   10,  328,  328,  328,  328,
   10,   10,  328,   10,   10,   10,   10,   10,  328,   10,
   10,  328,   10,  328,   10,   10,  257,  258,   10,  260,
   10,  262,  263,  264,  265,  266,  267,   10,   10,  328,
  328,   10,   10,  269,  328,  328,  328,  328,  328,  280,
  281,  328,  283,   10,  285,  282,  287,   10,   10,  290,
  291,   10,   10,   10,  295,  296,   10,   10,   10,   10,
  301,   10,  303,  304,  305,  306,  307,  308,  309,  310,
  311,  312,  313,  314,  315,   10,   10,  318,  319,  302,
  321,  322,  323,  324,  325,  326,  327,  316,  317,  330,
  328,  328,  332,  328,  328,  328,  328,  302,  339,  340,
  328,  328,  328,  328,  345,  346,  347,  348,  349,  350,
  351,  352,  353,  354,  355,  356,  357,  358,  359,  360,
  361,  362,  363,  364,  365,  366,  367,  368,  369,  370,
  371,  372,  373,  374,  375,  376,  377,  378,  379,  380,
  381,  382,  383,  384,  385,  386,  387,  388,  389,  390,
  391,  392,  393,  394,  395,  396,  397,  398,  399,  400,
  401,  328,  257,  302,   10,   10,   10,   10,   10,   10,
   10,   10,   10,   10,  328,   10,    0,   10,   10,   45,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,  298,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,  316,  317,
};
#define YYFINAL 103
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 401
#if YYDEBUG
const char * const bxname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,"'\\n'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,"'*'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"':'",0,0,"'='",0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
"BX_TOKEN_CONTINUE","BX_TOKEN_STEPN","BX_TOKEN_NEXT_STEP","BX_TOKEN_SET",
"BX_TOKEN_DEBUGGER","BX_TOKEN_VBREAKPOINT","BX_TOKEN_LBREAKPOINT",
"BX_TOKEN_PBREAKPOINT","BX_TOKEN_DEL_BREAKPOINT","BX_TOKEN_INFO",
"BX_TOKEN_QUIT","BX_TOKEN_PROGRAM","BX_TOKEN_REGISTERS","BX_TOKEN_LABELS",
"BX_TOKEN_FPU","BX_TOKEN_ALL","BX_TOKEN_IDT","BX_TOKEN_GDT","BX_TOKEN_LDT",
"BX_TOKEN_TSS","BX_TOKEN_DIRTY","BX_TOKEN_LINUX","BX_TOKEN_CONTROL_REGS",
"BX_TOKEN_EXAMINE","BX_TOKEN_LABEL","BX_TOKEN_XFORMAT","BX_TOKEN_SETPMEM",
"BX_TOKEN_SYMBOLNAME","BX_TOKEN_QUERY","BX_TOKEN_PENDING","BX_TOKEN_TAKE",
"BX_TOKEN_DMA","BX_TOKEN_IRQ","BX_TOKEN_DUMP_CPU","BX_TOKEN_SET_CPU",
"BX_TOKEN_DIS","BX_TOKEN_ON","BX_TOKEN_OFF","BX_TOKEN_DISASSEMBLE",
"BX_TOKEN_INSTRUMENT","BX_TOKEN_START","BX_TOKEN_STOP","BX_TOKEN_RESET",
"BX_TOKEN_PRINT","BX_TOKEN_LOADER","BX_TOKEN_STRING","BX_TOKEN_DOIT",
"BX_TOKEN_CRC","BX_TOKEN_TRACEON","BX_TOKEN_TRACEOFF","BX_TOKEN_PTIME",
"BX_TOKEN_TIMEBP_ABSOLUTE","BX_TOKEN_TIMEBP","BX_TOKEN_RECORD",
"BX_TOKEN_PLAYBACK","BX_TOKEN_MODEBP","BX_TOKEN_PRINT_STACK","BX_TOKEN_WATCH",
"BX_TOKEN_UNWATCH","BX_TOKEN_READ","BX_TOKEN_WRITE","BX_TOKEN_SHOW",
"BX_TOKEN_SYMBOL","BX_TOKEN_GLOBAL","BX_TOKEN_WHERE","BX_TOKEN_PRINT_STRING",
"BX_TOKEN_DIFF_MEMORY","BX_TOKEN_SYNC_MEMORY","BX_TOKEN_SYNC_CPU",
"BX_TOKEN_FAST_FORWARD","BX_TOKEN_PHY_2_LOG","BX_TOKEN_NUMERIC",
"BX_TOKEN_LONG_NUMERIC","BX_TOKEN_INFO_ADDRESS","BX_TOKEN_NE2000",
"BX_TOKEN_PAGE","BX_TOKEN_CS","BX_TOKEN_ES","BX_TOKEN_SS","BX_TOKEN_DS",
"BX_TOKEN_FS","BX_TOKEN_GS","BX_TOKEN_ALWAYS_CHECK","BX_TOKEN_MATHS",
"BX_TOKEN_ADD","BX_TOKEN_SUB","BX_TOKEN_MUL","BX_TOKEN_DIV","BX_TOKEN_V2L",
"BX_TOKEN_TRACEREGON","BX_TOKEN_TRACEREGOFF","BX_TOKEN_HELP","BX_TOKEN_SEXECON",
"BX_TOKEN_SEXECOFF","BX_TOKEN_LOGON","BX_TOKEN_LOGOFF","BX_TOKEN_REPLAYON",
"BX_TOKEN_REPLAYOFF","BX_TOKEN_RECOVERYON","BX_TOKEN_RECOVERYOFF",
"BX_TOKEN_CTHULHUON","BX_TOKEN_CTHULHUOFF","BX_TOKEN_TIMINGON",
"BX_TOKEN_TIMINGOFF","BX_TOKEN_CHEESYCP","BX_TOKEN_CHEESYEXIT",
"BX_TOKEN_CMOSON","BX_TOKEN_CMOSOFF","BX_TOKEN_PRINTTIMEON",
"BX_TOKEN_PRINTTIMEOFF","BX_TOKEN_MEATMODEON","BX_TOKEN_MEATMODEOFF",
"BX_TOKEN_UBERDEBUGON","BX_TOKEN_UBERDEBUGOFF","BX_TOKEN_SPRINGS",
"BX_TOKEN_PREDICATES","BX_TOKEN_ALLPREDICATES","BX_TOKEN_SUMMARIZE",
"BX_TOKEN_GARBAGE","BX_TOKEN_TIMINGADDR","BX_TOKEN_TAKEAGANDERAT",
"BX_TOKEN_VTIMINGADDR","BX_TOKEN_COUNTEXPR","BX_TOKEN_CLEARSYMBSTOR",
"BX_TOKEN_INVERTPRED","BX_TOKEN_RMINVERTPRED","BX_TOKEN_LSINVERTPRED",
"BX_TOKEN_SETPREDFILT","BX_TOKEN_CLEARPREDFILT","BX_TOKEN_ADDPREDFILT",
"BX_TOKEN_PREDFILT","BX_TOKEN_PREDCR3","BX_TOKEN_TBREAK",
"BX_TOKEN_DOUPDATECOUNT","BX_TOKEN_SETUCERROR","BX_TOKEN_TIMEDELTA",
"BX_TOKEN_PRINTUC","BX_TOKEN_SPEED","BX_TOKEN_DATAFORLABELS",
"BX_TOKEN_REMOVESKIPPY","BX_TOKEN_SETEIP","BX_TOKEN_PUTLABEL",
"BX_TOKEN_ADDRSINTEREST","BX_TOKEN_PRINTCR3","BX_TOKEN_SIGFROMGAMMA",
};
const char * const bxrule[] = {
"$accept : command",
"command : continue_command",
"command : stepN_command",
"command : set_command",
"command : breakpoint_command",
"command : info_command",
"command : dump_cpu_command",
"command : delete_command",
"command : quit_command",
"command : examine_command",
"command : label_command",
"command : setpmem_command",
"command : query_command",
"command : take_command",
"command : set_cpu_command",
"command : disassemble_command",
"command : instrument_command",
"command : loader_command",
"command : doit_command",
"command : crc_command",
"command : maths_command",
"command : trace_on_command",
"command : trace_off_command",
"command : sexec_on_command",
"command : sexec_off_command",
"command : log_on_command",
"command : log_off_command",
"command : replay_on_command",
"command : replay_off_command",
"command : recovery_on_command",
"command : recovery_off_command",
"command : cthulhu_on_command",
"command : cthulhu_off_command",
"command : timing_on_command",
"command : timing_off_command",
"command : cheesycp_command",
"command : cheesyexit_command",
"command : cmos_on_command",
"command : cmos_off_command",
"command : printtime_on_command",
"command : printtime_off_command",
"command : meatmode_on_command",
"command : meatmode_off_command",
"command : uberdebug_on_command",
"command : uberdebug_off_command",
"command : springs_command",
"command : predicates_command",
"command : allpredicates_command",
"command : summarize_command",
"command : garbage_command",
"command : timingaddr_command",
"command : takeaganderat_command",
"command : vtimingaddr_command",
"command : countexpr_command",
"command : clearsymbstor_command",
"command : invertpred_command",
"command : rminvertpred_command",
"command : lsinvertpred_command",
"command : setpredfilt_command",
"command : clearpredfilt_command",
"command : addpredfilt_command",
"command : predfilt_command",
"command : predcr3_command",
"command : tbreak_command",
"command : doupdatecount_command",
"command : setucerror_command",
"command : timedelta_command",
"command : printuc_command",
"command : speed_command",
"command : dataforlabels_command",
"command : removeskippy_command",
"command : seteip_command",
"command : putlabel_command",
"command : addrsinterest_command",
"command : printcr3_command",
"command : sigfromgamma_command",
"command : ptime_command",
"command : timebp_command",
"command : record_command",
"command : playback_command",
"command : modebp_command",
"command : print_stack_command",
"command : watch_point_command",
"command : show_command",
"command : symbol_command",
"command : where_command",
"command : print_string_command",
"command : cosim_commands",
"command : v2l_command",
"command : trace_reg_on_command",
"command : trace_reg_off_command",
"command : help_command",
"command :",
"command : '\\n'",
"cosim_commands : BX_TOKEN_DIFF_MEMORY '\\n'",
"cosim_commands : BX_TOKEN_SYNC_MEMORY BX_TOKEN_ON '\\n'",
"cosim_commands : BX_TOKEN_SYNC_MEMORY BX_TOKEN_OFF '\\n'",
"cosim_commands : BX_TOKEN_SYNC_CPU BX_TOKEN_ON '\\n'",
"cosim_commands : BX_TOKEN_SYNC_CPU BX_TOKEN_OFF '\\n'",
"cosim_commands : BX_TOKEN_FAST_FORWARD BX_TOKEN_NUMERIC '\\n'",
"cosim_commands : BX_TOKEN_PHY_2_LOG BX_TOKEN_NUMERIC '\\n'",
"cosim_commands : BX_TOKEN_INFO_ADDRESS segment_register ':' BX_TOKEN_NUMERIC '\\n'",
"cosim_commands : BX_TOKEN_ALWAYS_CHECK BX_TOKEN_NUMERIC BX_TOKEN_ON '\\n'",
"cosim_commands : BX_TOKEN_ALWAYS_CHECK BX_TOKEN_NUMERIC BX_TOKEN_OFF '\\n'",
"segment_register : BX_TOKEN_CS",
"segment_register : BX_TOKEN_ES",
"segment_register : BX_TOKEN_SS",
"segment_register : BX_TOKEN_DS",
"segment_register : BX_TOKEN_FS",
"segment_register : BX_TOKEN_GS",
"timebp_command : BX_TOKEN_TIMEBP BX_TOKEN_LONG_NUMERIC '\\n'",
"timebp_command : BX_TOKEN_TIMEBP_ABSOLUTE BX_TOKEN_LONG_NUMERIC '\\n'",
"record_command : BX_TOKEN_RECORD BX_TOKEN_STRING '\\n'",
"playback_command : BX_TOKEN_PLAYBACK BX_TOKEN_STRING '\\n'",
"modebp_command : BX_TOKEN_MODEBP BX_TOKEN_STRING '\\n'",
"modebp_command : BX_TOKEN_MODEBP '\\n'",
"show_command : BX_TOKEN_SHOW BX_TOKEN_STRING '\\n'",
"show_command : BX_TOKEN_SHOW '\\n'",
"ptime_command : BX_TOKEN_PTIME '\\n'",
"trace_on_command : BX_TOKEN_TRACEON '\\n'",
"trace_off_command : BX_TOKEN_TRACEOFF '\\n'",
"sexec_on_command : BX_TOKEN_SEXECON '\\n'",
"sexec_off_command : BX_TOKEN_SEXECOFF '\\n'",
"log_on_command : BX_TOKEN_LOGON '\\n'",
"log_off_command : BX_TOKEN_LOGOFF '\\n'",
"replay_on_command : BX_TOKEN_REPLAYON '\\n'",
"replay_off_command : BX_TOKEN_REPLAYOFF '\\n'",
"recovery_on_command : BX_TOKEN_RECOVERYON '\\n'",
"recovery_off_command : BX_TOKEN_RECOVERYOFF '\\n'",
"cthulhu_on_command : BX_TOKEN_CTHULHUON '\\n'",
"cthulhu_off_command : BX_TOKEN_CTHULHUOFF '\\n'",
"timing_on_command : BX_TOKEN_TIMINGON '\\n'",
"timing_off_command : BX_TOKEN_TIMINGOFF '\\n'",
"cheesycp_command : BX_TOKEN_CHEESYCP '\\n'",
"cheesyexit_command : BX_TOKEN_CHEESYEXIT '\\n'",
"cmos_on_command : BX_TOKEN_CMOSON BX_TOKEN_NUMERIC '\\n'",
"cmos_off_command : BX_TOKEN_CMOSOFF '\\n'",
"printtime_on_command : BX_TOKEN_PRINTTIMEON '\\n'",
"printtime_off_command : BX_TOKEN_PRINTTIMEOFF '\\n'",
"meatmode_on_command : BX_TOKEN_MEATMODEON '\\n'",
"meatmode_off_command : BX_TOKEN_MEATMODEOFF '\\n'",
"uberdebug_on_command : BX_TOKEN_UBERDEBUGON '\\n'",
"uberdebug_off_command : BX_TOKEN_UBERDEBUGOFF '\\n'",
"print_stack_command : BX_TOKEN_PRINT_STACK '\\n'",
"print_stack_command : BX_TOKEN_PRINT_STACK BX_TOKEN_NUMERIC '\\n'",
"watch_point_command : BX_TOKEN_WATCH BX_TOKEN_STOP '\\n'",
"watch_point_command : BX_TOKEN_WATCH BX_TOKEN_CONTINUE '\\n'",
"watch_point_command : BX_TOKEN_WATCH '\\n'",
"watch_point_command : BX_TOKEN_UNWATCH '\\n'",
"watch_point_command : BX_TOKEN_WATCH BX_TOKEN_READ BX_TOKEN_NUMERIC '\\n'",
"watch_point_command : BX_TOKEN_UNWATCH BX_TOKEN_READ BX_TOKEN_NUMERIC '\\n'",
"watch_point_command : BX_TOKEN_WATCH BX_TOKEN_WRITE BX_TOKEN_NUMERIC '\\n'",
"watch_point_command : BX_TOKEN_UNWATCH BX_TOKEN_WRITE BX_TOKEN_NUMERIC '\\n'",
"symbol_command : BX_TOKEN_SYMBOL BX_TOKEN_STRING '\\n'",
"symbol_command : BX_TOKEN_SYMBOL BX_TOKEN_STRING BX_TOKEN_NUMERIC '\\n'",
"symbol_command : BX_TOKEN_SYMBOL BX_TOKEN_GLOBAL BX_TOKEN_STRING BX_TOKEN_NUMERIC '\\n'",
"where_command : BX_TOKEN_WHERE '\\n'",
"print_string_command : BX_TOKEN_PRINT_STRING BX_TOKEN_NUMERIC '\\n'",
"continue_command : BX_TOKEN_CONTINUE '\\n'",
"stepN_command : BX_TOKEN_STEPN '\\n'",
"stepN_command : BX_TOKEN_STEPN BX_TOKEN_NUMERIC '\\n'",
"set_command : BX_TOKEN_SET BX_TOKEN_DIS BX_TOKEN_ON '\\n'",
"set_command : BX_TOKEN_SET BX_TOKEN_DIS BX_TOKEN_OFF '\\n'",
"set_command : BX_TOKEN_SET BX_TOKEN_SYMBOLNAME '=' BX_TOKEN_NUMERIC '\\n'",
"breakpoint_command : BX_TOKEN_VBREAKPOINT '\\n'",
"breakpoint_command : BX_TOKEN_VBREAKPOINT BX_TOKEN_NUMERIC ':' BX_TOKEN_NUMERIC '\\n'",
"breakpoint_command : BX_TOKEN_LBREAKPOINT '\\n'",
"breakpoint_command : BX_TOKEN_LBREAKPOINT BX_TOKEN_NUMERIC '\\n'",
"breakpoint_command : BX_TOKEN_PBREAKPOINT '\\n'",
"breakpoint_command : BX_TOKEN_PBREAKPOINT BX_TOKEN_NUMERIC '\\n'",
"breakpoint_command : BX_TOKEN_PBREAKPOINT '*' BX_TOKEN_NUMERIC '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_PBREAKPOINT '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_PROGRAM '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_REGISTERS '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_LABELS '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_FPU '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_ALL '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_DIRTY '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_IDT optional_numeric_range '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_GDT optional_numeric_range '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_LDT optional_numeric_range '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_TSS optional_numeric_range '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_LINUX '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_CONTROL_REGS '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_NE2000 '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_NE2000 BX_TOKEN_PAGE BX_TOKEN_NUMERIC '\\n'",
"info_command : BX_TOKEN_INFO BX_TOKEN_NE2000 BX_TOKEN_PAGE BX_TOKEN_NUMERIC BX_TOKEN_REGISTERS BX_TOKEN_NUMERIC '\\n'",
"optional_numeric :",
"optional_numeric : BX_TOKEN_NUMERIC",
"optional_numeric_range :",
"optional_numeric_range : numeric_range",
"numeric_range : BX_TOKEN_NUMERIC",
"numeric_range : BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC",
"numeric_range : BX_TOKEN_NUMERIC ':' BX_TOKEN_NUMERIC",
"dump_cpu_command : BX_TOKEN_DUMP_CPU '\\n'",
"delete_command : BX_TOKEN_DEL_BREAKPOINT BX_TOKEN_NUMERIC '\\n'",
"quit_command : BX_TOKEN_QUIT '\\n'",
"examine_command : BX_TOKEN_EXAMINE BX_TOKEN_XFORMAT BX_TOKEN_NUMERIC '\\n'",
"examine_command : BX_TOKEN_EXAMINE BX_TOKEN_XFORMAT '\\n'",
"examine_command : BX_TOKEN_EXAMINE BX_TOKEN_NUMERIC '\\n'",
"examine_command : BX_TOKEN_EXAMINE '\\n'",
"label_command : BX_TOKEN_LABEL '\\n'",
"label_command : BX_TOKEN_LABEL BX_TOKEN_NUMERIC '\\n'",
"label_command : BX_TOKEN_LABEL BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"springs_command : BX_TOKEN_SPRINGS '\\n'",
"predicates_command : BX_TOKEN_PREDICATES BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"allpredicates_command : BX_TOKEN_ALLPREDICATES BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"summarize_command : BX_TOKEN_SUMMARIZE BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"clearsymbstor_command : BX_TOKEN_CLEARSYMBSTOR '\\n'",
"invertpred_command : BX_TOKEN_INVERTPRED BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"rminvertpred_command : BX_TOKEN_RMINVERTPRED BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"lsinvertpred_command : BX_TOKEN_LSINVERTPRED '\\n'",
"setpredfilt_command : BX_TOKEN_SETPREDFILT '\\n'",
"clearpredfilt_command : BX_TOKEN_CLEARPREDFILT '\\n'",
"addpredfilt_command : BX_TOKEN_ADDPREDFILT BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"predfilt_command : BX_TOKEN_PREDFILT BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"predcr3_command : BX_TOKEN_PREDCR3 BX_TOKEN_NUMERIC '\\n'",
"tbreak_command : BX_TOKEN_TBREAK BX_TOKEN_NUMERIC '\\n'",
"doupdatecount_command : BX_TOKEN_DOUPDATECOUNT BX_TOKEN_NUMERIC '\\n'",
"setucerror_command : BX_TOKEN_SETUCERROR BX_TOKEN_NUMERIC '\\n'",
"timedelta_command : BX_TOKEN_TIMEDELTA BX_TOKEN_NUMERIC '\\n'",
"printuc_command : BX_TOKEN_PRINTUC BX_TOKEN_NUMERIC '\\n'",
"speed_command : BX_TOKEN_SPEED BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"garbage_command : BX_TOKEN_GARBAGE BX_TOKEN_NUMERIC '\\n'",
"timingaddr_command : BX_TOKEN_TIMINGADDR BX_TOKEN_NUMERIC '\\n'",
"takeaganderat_command : BX_TOKEN_TAKEAGANDERAT BX_TOKEN_NUMERIC '\\n'",
"vtimingaddr_command : BX_TOKEN_VTIMINGADDR BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"countexpr_command : BX_TOKEN_COUNTEXPR BX_TOKEN_NUMERIC '\\n'",
"dataforlabels_command : BX_TOKEN_DATAFORLABELS BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"removeskippy_command : BX_TOKEN_REMOVESKIPPY BX_TOKEN_NUMERIC '\\n'",
"seteip_command : BX_TOKEN_SETEIP BX_TOKEN_NUMERIC '\\n'",
"putlabel_command : BX_TOKEN_PUTLABEL BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"addrsinterest_command : BX_TOKEN_ADDRSINTEREST BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"printcr3_command : BX_TOKEN_PRINTCR3 '\\n'",
"sigfromgamma_command : BX_TOKEN_SIGFROMGAMMA BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"setpmem_command : BX_TOKEN_SETPMEM BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"query_command : BX_TOKEN_QUERY BX_TOKEN_PENDING '\\n'",
"take_command : BX_TOKEN_TAKE BX_TOKEN_DMA '\\n'",
"take_command : BX_TOKEN_TAKE BX_TOKEN_DMA BX_TOKEN_NUMERIC '\\n'",
"take_command : BX_TOKEN_TAKE BX_TOKEN_IRQ '\\n'",
"set_cpu_command : BX_TOKEN_SET_CPU '\\n'",
"disassemble_command : BX_TOKEN_DISASSEMBLE optional_numeric_range '\\n'",
"instrument_command : BX_TOKEN_INSTRUMENT BX_TOKEN_START '\\n'",
"instrument_command : BX_TOKEN_INSTRUMENT BX_TOKEN_STOP '\\n'",
"instrument_command : BX_TOKEN_INSTRUMENT BX_TOKEN_RESET '\\n'",
"instrument_command : BX_TOKEN_INSTRUMENT BX_TOKEN_PRINT '\\n'",
"loader_command : BX_TOKEN_LOADER BX_TOKEN_STRING '\\n'",
"doit_command : BX_TOKEN_DOIT BX_TOKEN_NUMERIC '\\n'",
"crc_command : BX_TOKEN_CRC BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"maths_command : BX_TOKEN_MATHS BX_TOKEN_ADD BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"maths_command : BX_TOKEN_MATHS BX_TOKEN_SUB BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"maths_command : BX_TOKEN_MATHS BX_TOKEN_MUL BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"maths_command : BX_TOKEN_MATHS BX_TOKEN_DIV BX_TOKEN_NUMERIC BX_TOKEN_NUMERIC '\\n'",
"maths_command : BX_TOKEN_MATHS BX_TOKEN_STRING '\\n'",
"v2l_command : BX_TOKEN_V2L segment_register ':' BX_TOKEN_NUMERIC '\\n'",
"trace_reg_on_command : BX_TOKEN_TRACEREGON '\\n'",
"trace_reg_off_command : BX_TOKEN_TRACEREGOFF '\\n'",
"help_command : BX_TOKEN_HELP BX_TOKEN_STRING '\\n'",
"help_command : BX_TOKEN_HELP '\\n'",
};
#endif
#if YYDEBUG
#include <stdio.h>
#endif
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 10000
#define YYMAXDEPTH 10000
#endif
#endif
#define YYINITSTACKSIZE 200
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short *yyss;
short *yysslim;
YYSTYPE *yyvs;
int yystacksize;
/* allocate initial stack or double stack size, up to YYMAXDEPTH */
static int yygrowstack()
{
    int newsize, i;
    short *newss;
    YYSTYPE *newvs;

    if ((newsize = yystacksize) == 0)
        newsize = YYINITSTACKSIZE;
    else if (newsize >= YYMAXDEPTH)
        return -1;
    else if ((newsize *= 2) > YYMAXDEPTH)
        newsize = YYMAXDEPTH;
    i = yyssp - yyss;
    newss = yyss ? (short *)realloc(yyss, newsize * sizeof *newss) :
      (short *)malloc(newsize * sizeof *newss);
    if (newss == NULL)
        return -1;
    yyss = newss;
    yyssp = newss + i;
    newvs = yyvs ? (YYSTYPE *)realloc(yyvs, newsize * sizeof *newvs) :
      (YYSTYPE *)malloc(newsize * sizeof *newvs);
    if (newvs == NULL)
        return -1;
    yyvs = newvs;
    yyvsp = newvs + i;
    yystacksize = newsize;
    yysslim = yyss + newsize - 1;
    return 0;
}

#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab

#ifndef YYPARSE_PARAM
#if defined(__cplusplus) || __STDC__
#define YYPARSE_PARAM_ARG void
#define YYPARSE_PARAM_DECL
#else	/* ! ANSI-C/C++ */
#define YYPARSE_PARAM_ARG
#define YYPARSE_PARAM_DECL
#endif	/* ANSI-C/C++ */
#else	/* YYPARSE_PARAM */
#ifndef YYPARSE_PARAM_TYPE
#define YYPARSE_PARAM_TYPE void *
#endif
#if defined(__cplusplus) || __STDC__
#define YYPARSE_PARAM_ARG YYPARSE_PARAM_TYPE YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#else	/* ! ANSI-C/C++ */
#define YYPARSE_PARAM_ARG YYPARSE_PARAM
#define YYPARSE_PARAM_DECL YYPARSE_PARAM_TYPE YYPARSE_PARAM;
#endif	/* ANSI-C/C++ */
#endif	/* ! YYPARSE_PARAM */

int
yyparse (YYPARSE_PARAM_ARG)
    YYPARSE_PARAM_DECL
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register const char *yys;

    if ((yys = getenv("YYDEBUG")))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    if (yyss == NULL && yygrowstack()) goto yyoverflow;
    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if ((yyn = yydefred[yystate])) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yysslim && yygrowstack())
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
#if defined(lint) || defined(__GNUC__)
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#if defined(lint) || defined(__GNUC__)
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yysslim && yygrowstack())
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 93:
#line 276 "parser.y"
{
      }
break;
case 94:
#line 282 "parser.y"
{
		bx_dbg_diff_memory();
		free(yyvsp[-1].sval);
	}
break;
case 95:
#line 287 "parser.y"
{
		bx_dbg_sync_memory(1);
		free(yyvsp[-2].sval); free(yyvsp[-1].sval);
	}
break;
case 96:
#line 292 "parser.y"
{
		bx_dbg_sync_memory(0);
		free(yyvsp[-2].sval); free(yyvsp[-1].sval);
	}
break;
case 97:
#line 297 "parser.y"
{
		bx_dbg_sync_cpu(1);
		free(yyvsp[-2].sval); free(yyvsp[-1].sval);
	}
break;
case 98:
#line 302 "parser.y"
{
		bx_dbg_sync_cpu(0);
		free(yyvsp[-2].sval); free(yyvsp[-1].sval);
	}
break;
case 99:
#line 307 "parser.y"
{
		free(yyvsp[-2].sval);
		bx_dbg_fast_forward(yyvsp[-1].uval);
	}
break;
case 100:
#line 312 "parser.y"
{
	}
break;
case 101:
#line 315 "parser.y"
{
		free(yyvsp[-4].sval);
		bx_dbg_info_address(yyvsp[-3].uval, yyvsp[-1].uval);
        }
break;
case 102:
#line 320 "parser.y"
{
        }
break;
case 103:
#line 323 "parser.y"
{
        }
break;
case 104:
#line 328 "parser.y"
{ yyval.uval = 1; }
break;
case 105:
#line 329 "parser.y"
{ yyval.uval = 0; }
break;
case 106:
#line 330 "parser.y"
{ yyval.uval = 2; }
break;
case 107:
#line 331 "parser.y"
{ yyval.uval = 3; }
break;
case 108:
#line 332 "parser.y"
{ yyval.uval = 4; }
break;
case 109:
#line 333 "parser.y"
{ yyval.uval = 5; }
break;
case 110:
#line 338 "parser.y"
{
        bx_dbg_timebp_command(0, yyvsp[-1].ulval);
	free(yyvsp[-2].sval);
	}
break;
case 111:
#line 343 "parser.y"
{
        bx_dbg_timebp_command(1, yyvsp[-1].ulval);
	free(yyvsp[-2].sval);
	}
break;
case 112:
#line 351 "parser.y"
{
          bx_dbg_record_command(yyvsp[-1].sval);
          free(yyvsp[-2].sval); free(yyvsp[-1].sval);
          }
break;
case 113:
#line 359 "parser.y"
{
          bx_dbg_playback_command(yyvsp[-1].sval);
          free(yyvsp[-2].sval); free(yyvsp[-1].sval);
          }
break;
case 114:
#line 367 "parser.y"
{
          bx_dbg_modebp_command(yyvsp[-1].sval);
          free(yyvsp[-2].sval); free(yyvsp[-1].sval);
          }
break;
case 115:
#line 372 "parser.y"
{
          bx_dbg_modebp_command(0);
          free(yyvsp[-1].sval);
          }
break;
case 116:
#line 380 "parser.y"
{
          bx_dbg_show_command(yyvsp[-1].sval);
          free(yyvsp[-2].sval); free(yyvsp[-1].sval);
          }
break;
case 117:
#line 385 "parser.y"
{
          bx_dbg_show_command(0);
          free(yyvsp[-1].sval);
          }
break;
case 118:
#line 393 "parser.y"
{
        bx_dbg_ptime_command();
        free(yyvsp[-1].sval);
	}
break;
case 119:
#line 401 "parser.y"
{
        bx_dbg_trace_on_command();
        free(yyvsp[-1].sval);
	}
break;
case 120:
#line 409 "parser.y"
{
        bx_dbg_trace_off_command();
        free(yyvsp[-1].sval);
	}
break;
case 121:
#line 417 "parser.y"
{
        bx_dbg_sexec_on_command();
        free(yyvsp[-1].sval);
	}
break;
case 122:
#line 425 "parser.y"
{
        bx_dbg_sexec_off_command();
        free(yyvsp[-1].sval);
	}
break;
case 123:
#line 433 "parser.y"
{
        bx_dbg_log_on_command();
        free(yyvsp[-1].sval);
        }
break;
case 124:
#line 441 "parser.y"
{
        bx_dbg_log_off_command();
        free(yyvsp[-1].sval);
        }
break;
case 125:
#line 449 "parser.y"
{
        bx_dbg_replay_on_command();
        free(yyvsp[-1].sval);
        }
break;
case 126:
#line 457 "parser.y"
{
        bx_dbg_replay_off_command();
        free(yyvsp[-1].sval);
        }
break;
case 127:
#line 465 "parser.y"
{
        bx_dbg_recovery_on_command();
        free(yyvsp[-1].sval);
        }
break;
case 128:
#line 473 "parser.y"
{
        bx_dbg_recovery_off_command();
        free(yyvsp[-1].sval);
        }
break;
case 129:
#line 481 "parser.y"
{
        bx_dbg_cthulhu_on_command();
        free(yyvsp[-1].sval);
	}
break;
case 130:
#line 489 "parser.y"
{
        bx_dbg_cthulhu_off_command();
        free(yyvsp[-1].sval);
	}
break;
case 131:
#line 497 "parser.y"
{
        bx_dbg_timing_on_command();
        free(yyvsp[-1].sval);
	}
break;
case 132:
#line 505 "parser.y"
{
        bx_dbg_timing_off_command();
        free(yyvsp[-1].sval);
	}
break;
case 133:
#line 513 "parser.y"
{
        bx_dbg_cheesycp_command();
        free(yyvsp[-1].sval);
	}
break;
case 134:
#line 521 "parser.y"
{
        bx_dbg_cheesyexit_command();
        free(yyvsp[-1].sval);
	}
break;
case 135:
#line 530 "parser.y"
{
        bx_dbg_cmos_on_command(yyvsp[-1].uval);
        free(yyvsp[-2].sval);
	}
break;
case 136:
#line 538 "parser.y"
{
        bx_dbg_cmos_off_command();
        free(yyvsp[-1].sval);
	}
break;
case 137:
#line 546 "parser.y"
{
        bx_dbg_printtime_on_command();
        free(yyvsp[-1].sval);
	}
break;
case 138:
#line 554 "parser.y"
{
        bx_dbg_printtime_off_command();
        free(yyvsp[-1].sval);
	}
break;
case 139:
#line 562 "parser.y"
{
        bx_dbg_meatmode_on_command();
        free(yyvsp[-1].sval);
	}
break;
case 140:
#line 570 "parser.y"
{
        bx_dbg_meatmode_off_command();
        free(yyvsp[-1].sval);
	}
break;
case 141:
#line 578 "parser.y"
{
        bx_dbg_uberdebug_on_command();
        free(yyvsp[-1].sval);
	}
break;
case 142:
#line 586 "parser.y"
{
        bx_dbg_uberdebug_off_command();
        free(yyvsp[-1].sval);
	}
break;
case 143:
#line 597 "parser.y"
{
          bx_dbg_print_stack_command(16);
          free(yyvsp[-1].sval);
	  }
break;
case 144:
#line 602 "parser.y"
{
          bx_dbg_print_stack_command(yyvsp[-1].uval);
          free(yyvsp[-2].sval);
	  }
break;
case 145:
#line 610 "parser.y"
{
          watchpoint_continue = 0;
	  fprintf(stderr, "Will stop on watch points\n");
          free(yyvsp[-2].sval); free(yyvsp[-1].sval);
          }
break;
case 146:
#line 616 "parser.y"
{
          watchpoint_continue = 1;
          fprintf(stderr, "Will not stop on watch points (they will still be logged)\n");
          free(yyvsp[-2].sval); free(yyvsp[-1].sval);
          }
break;
case 147:
#line 622 "parser.y"
{
          bx_dbg_watch(-1, 0);
          free(yyvsp[-1].sval);
          }
break;
case 148:
#line 627 "parser.y"
{
          bx_dbg_unwatch(-1, 0);
          free(yyvsp[-1].sval);
          }
break;
case 149:
#line 632 "parser.y"
{
          bx_dbg_watch(1, yyvsp[-1].uval);
          free(yyvsp[-3].sval); free(yyvsp[-2].sval);
          }
break;
case 150:
#line 637 "parser.y"
{
          bx_dbg_unwatch(1, yyvsp[-1].uval);
          free(yyvsp[-3].sval); free(yyvsp[-2].sval);
          }
break;
case 151:
#line 642 "parser.y"
{
          bx_dbg_watch(0, yyvsp[-1].uval);
          free(yyvsp[-3].sval); free(yyvsp[-2].sval);
          }
break;
case 152:
#line 647 "parser.y"
{
          bx_dbg_unwatch(0, yyvsp[-1].uval);
          free(yyvsp[-3].sval); free(yyvsp[-2].sval);
          }
break;
case 153:
#line 655 "parser.y"
{
	bx_dbg_symbol_command(yyvsp[-1].sval, 0, 0);
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 154:
#line 660 "parser.y"
{
	bx_dbg_symbol_command(yyvsp[-2].sval, 0, yyvsp[-1].uval);
        free(yyvsp[-3].sval); free(yyvsp[-2].sval);
        }
break;
case 155:
#line 665 "parser.y"
{
	bx_dbg_symbol_command(yyvsp[-2].sval, 1, yyvsp[-1].uval);
        free(yyvsp[-4].sval); free(yyvsp[-3].sval); free(yyvsp[-2].sval);
        }
break;
case 156:
#line 673 "parser.y"
{
        bx_dbg_where_command();
        free(yyvsp[-1].sval);
        }
break;
case 157:
#line 681 "parser.y"
{
        bx_dbg_print_string_command(yyvsp[-1].uval);
        free(yyvsp[-2].sval);
        }
break;
case 158:
#line 689 "parser.y"
{
        bx_dbg_continue_command();
        free(yyvsp[-1].sval);
        }
break;
case 159:
#line 697 "parser.y"
{
        bx_dbg_stepN_command(1);
        free(yyvsp[-1].sval);
        }
break;
case 160:
#line 702 "parser.y"
{
        bx_dbg_stepN_command(yyvsp[-1].uval);
        free(yyvsp[-2].sval);
        }
break;
case 161:
#line 710 "parser.y"
{
        bx_dbg_set_command(yyvsp[-3].sval, yyvsp[-2].sval, yyvsp[-1].sval);
        free(yyvsp[-3].sval); free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 162:
#line 715 "parser.y"
{
        bx_dbg_set_command(yyvsp[-3].sval, yyvsp[-2].sval, yyvsp[-1].sval);
        free(yyvsp[-3].sval); free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 163:
#line 720 "parser.y"
{
        bx_dbg_set_symbol_command(yyvsp[-3].sval, yyvsp[-1].uval);
        free(yyvsp[-4].sval); free(yyvsp[-3].sval);
        }
break;
case 164:
#line 728 "parser.y"
{
        bx_dbg_vbreakpoint_command(0, 0, 0);
        free(yyvsp[-1].sval);
        }
break;
case 165:
#line 733 "parser.y"
{
        bx_dbg_vbreakpoint_command(1, yyvsp[-3].uval, yyvsp[-1].uval);
        free(yyvsp[-4].sval);
        }
break;
case 166:
#line 738 "parser.y"
{
        bx_dbg_lbreakpoint_command(0, 0);
        free(yyvsp[-1].sval);
        }
break;
case 167:
#line 743 "parser.y"
{
        bx_dbg_lbreakpoint_command(1, yyvsp[-1].uval);
        free(yyvsp[-2].sval);
        }
break;
case 168:
#line 748 "parser.y"
{
        bx_dbg_pbreakpoint_command(0, 0);
        free(yyvsp[-1].sval);
        }
break;
case 169:
#line 753 "parser.y"
{
        bx_dbg_pbreakpoint_command(1, yyvsp[-1].uval);
        free(yyvsp[-2].sval);
        }
break;
case 170:
#line 758 "parser.y"
{
        bx_dbg_pbreakpoint_command(1, yyvsp[-1].uval);
        free(yyvsp[-3].sval);
        }
break;
case 171:
#line 766 "parser.y"
{
        bx_dbg_info_bpoints_command();
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 172:
#line 771 "parser.y"
{
        bx_dbg_info_program_command();
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 173:
#line 776 "parser.y"
{
        bx_dbg_info_registers_command(BX_INFO_CPU_REGS);
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 174:
#line 781 "parser.y"
{
        bx_dbg_info_labels_command();
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 175:
#line 786 "parser.y"
{
        bx_dbg_info_registers_command(BX_INFO_FPU_REGS);
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 176:
#line 791 "parser.y"
{
        bx_dbg_info_registers_command(BX_INFO_CPU_REGS | BX_INFO_FPU_REGS);
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 177:
#line 796 "parser.y"
{
        bx_dbg_info_dirty_command();
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
	}
break;
case 178:
#line 801 "parser.y"
{
        bx_dbg_info_idt_command(yyvsp[-1].uval_range);
        free(yyvsp[-3].sval); free(yyvsp[-2].sval);
        }
break;
case 179:
#line 806 "parser.y"
{
        bx_dbg_info_gdt_command(yyvsp[-1].uval_range);
        free(yyvsp[-3].sval); free(yyvsp[-2].sval);
        }
break;
case 180:
#line 811 "parser.y"
{
        bx_dbg_info_ldt_command(yyvsp[-1].uval_range);
        free(yyvsp[-3].sval); free(yyvsp[-2].sval);
        }
break;
case 181:
#line 816 "parser.y"
{
        bx_dbg_info_tss_command(yyvsp[-1].uval_range);
        free(yyvsp[-3].sval); free(yyvsp[-2].sval);
        }
break;
case 182:
#line 821 "parser.y"
{
        bx_dbg_info_linux_command();
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 183:
#line 826 "parser.y"
{
        bx_dbg_info_control_regs_command();
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 184:
#line 831 "parser.y"
{
        bx_dbg_info_ne2k(-1, -1);
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 185:
#line 836 "parser.y"
{
        free(yyvsp[-4].sval); free(yyvsp[-3].sval); free(yyvsp[-2].sval);
        bx_dbg_info_ne2k(yyvsp[-1].uval, -1);
        }
break;
case 186:
#line 841 "parser.y"
{
        free(yyvsp[-6].sval); free(yyvsp[-5].sval); free(yyvsp[-4].sval); free(yyvsp[-2].sval);
        bx_dbg_info_ne2k(yyvsp[-3].uval, yyvsp[-1].uval);
        }
break;
case 187:
#line 848 "parser.y"
{ yyval.uval = EMPTY_ARG; }
break;
case 189:
#line 852 "parser.y"
{ yyval.uval_range = make_num_range (EMPTY_ARG, EMPTY_ARG); }
break;
case 191:
#line 857 "parser.y"
{
    yyval.uval_range = make_num_range (yyvsp[0].uval, yyvsp[0].uval);
  }
break;
case 192:
#line 862 "parser.y"
{
    yyval.uval_range = make_num_range (yyvsp[-1].uval, yyvsp[0].uval);
  }
break;
case 193:
#line 867 "parser.y"
{
    yyval.uval_range = make_num_range (yyvsp[-2].uval, yyvsp[0].uval);
  }
break;
case 194:
#line 874 "parser.y"
{
        bx_dbg_dump_cpu_command();
        free(yyvsp[-1].sval);
        }
break;
case 195:
#line 882 "parser.y"
{
        bx_dbg_del_breakpoint_command(yyvsp[-1].uval);
        free(yyvsp[-2].sval);
        }
break;
case 196:
#line 890 "parser.y"
{
	  bx_dbg_quit_command();
	  free(yyvsp[-1].sval);
        }
break;
case 197:
#line 899 "parser.y"
{
        bx_dbg_examine_command(yyvsp[-3].sval, yyvsp[-2].sval,1, yyvsp[-1].uval,1, 0);
#if BX_NUM_SIMULATORS >= 2
        bx_dbg_examine_command(yyvsp[-3].sval, yyvsp[-2].sval,1, yyvsp[-1].uval,1, 1);
#endif
        free(yyvsp[-3].sval); free(yyvsp[-2].sval);
        }
break;
case 198:
#line 907 "parser.y"
{
        bx_dbg_examine_command(yyvsp[-2].sval, yyvsp[-1].sval,1, 0,0, 0);
#if BX_NUM_SIMULATORS >= 2
        bx_dbg_examine_command(yyvsp[-2].sval, yyvsp[-1].sval,1, 0,0, 1);
#endif
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 199:
#line 915 "parser.y"
{
        /*FIXME HanishKVC This method of hunting thro all the*/
        /*      simulators may be better than using 2 calls if*/
        /*      BX_NUM_SIMULATORS greater than or equal to 2 as*/
        /*      done for other cases of BX_TOKEN_EXAMINE*/
        int iCurSim;
        for(iCurSim = 0; iCurSim < BX_NUM_SIMULATORS; iCurSim++)
        {
          bx_dbg_examine_command(yyvsp[-2].sval, NULL,0, yyvsp[-1].uval,1, iCurSim);
        }
        free(yyvsp[-2].sval);
        }
break;
case 200:
#line 928 "parser.y"
{
        /*FIXME HanishKVC This method of hunting thro all the*/
        /*      simulators may be better than using 2 calls if*/
        /*      BX_NUM_SIMULATORS greater than or equal to 2 as*/
        /*      done for other cases of BX_TOKEN_EXAMINE*/
        int iCurSim;
        for(iCurSim = 0; iCurSim < BX_NUM_SIMULATORS; iCurSim++)
        {
          bx_dbg_examine_command(yyvsp[-1].sval, NULL,0, 0,0, iCurSim);
        }
        free(yyvsp[-1].sval);
        }
break;
case 201:
#line 944 "parser.y"
{
	bx_dbg_label_command(yyvsp[-1].sval, -1, -1);
	free(yyvsp[-1].sval);
	}
break;
case 202:
#line 949 "parser.y"
{
	bx_dbg_label_command(yyvsp[-2].sval, yyvsp[-1].uval, -1);
	free(yyvsp[-2].sval);
	}
break;
case 203:
#line 954 "parser.y"
{
	bx_dbg_label_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
	free(yyvsp[-3].sval);
	}
break;
case 204:
#line 962 "parser.y"
{
	bx_dbg_springs_command(yyvsp[-1].sval);
	free(yyvsp[-1].sval);
	}
break;
case 205:
#line 970 "parser.y"
{
	bx_dbg_predicates_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
	free(yyvsp[-3].sval);
	}
break;
case 206:
#line 978 "parser.y"
{
	bx_dbg_allpredicates_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
	free(yyvsp[-3].sval);
	}
break;
case 207:
#line 986 "parser.y"
{
	bx_dbg_summarize_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
	free(yyvsp[-3].sval);
	}
break;
case 208:
#line 994 "parser.y"
{
	bx_dbg_clearsymbstor_command(yyvsp[-1].sval);
	free(yyvsp[-1].sval);
	}
break;
case 209:
#line 1002 "parser.y"
{
	bx_dbg_invertpred_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
	free(yyvsp[-3].sval);
	}
break;
case 210:
#line 1010 "parser.y"
{
	bx_dbg_rminvertpred_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
	free(yyvsp[-3].sval);
	}
break;
case 211:
#line 1018 "parser.y"
{
	bx_dbg_lsinvertpred_command(yyvsp[-1].sval);
	free(yyvsp[-1].sval);
	}
break;
case 212:
#line 1027 "parser.y"
{
	bx_dbg_setpredfilt_command(yyvsp[-1].sval);
	free(yyvsp[-1].sval);
	}
break;
case 213:
#line 1035 "parser.y"
{
	bx_dbg_clearpredfilt_command(yyvsp[-1].sval);
	free(yyvsp[-1].sval);
	}
break;
case 214:
#line 1043 "parser.y"
{
	bx_dbg_addpredfilt_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
	free(yyvsp[-3].sval);
	}
break;
case 215:
#line 1051 "parser.y"
{
	bx_dbg_predfilt_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
	free(yyvsp[-3].sval);
	}
break;
case 216:
#line 1059 "parser.y"
{
	bx_dbg_predcr3_command(yyvsp[-2].sval, yyvsp[-1].uval);
	free(yyvsp[-2].sval);
	}
break;
case 217:
#line 1067 "parser.y"
{
	bx_dbg_tbreak_command(yyvsp[-2].sval, yyvsp[-1].uval);
	free(yyvsp[-2].sval);
	}
break;
case 218:
#line 1076 "parser.y"
{
	bx_dbg_doupdatecount_command(yyvsp[-2].sval, yyvsp[-1].uval);
	free(yyvsp[-2].sval);
	}
break;
case 219:
#line 1084 "parser.y"
{
	bx_dbg_setucerror_command(yyvsp[-2].sval, yyvsp[-1].uval);
	free(yyvsp[-2].sval);
	}
break;
case 220:
#line 1092 "parser.y"
{
	bx_dbg_timedelta_command(yyvsp[-2].sval, yyvsp[-1].uval);
	free(yyvsp[-2].sval);
	}
break;
case 221:
#line 1101 "parser.y"
{
	bx_dbg_printuc_command(yyvsp[-2].sval, yyvsp[-1].uval);
	free(yyvsp[-2].sval);
	}
break;
case 222:
#line 1109 "parser.y"
{
	bx_dbg_speed_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
	free(yyvsp[-3].sval);
	}
break;
case 223:
#line 1118 "parser.y"
{
	bx_dbg_garbage_command(yyvsp[-2].sval, yyvsp[-1].uval);
	free(yyvsp[-2].sval);
	}
break;
case 224:
#line 1126 "parser.y"
{
	bx_dbg_timingaddr_command(yyvsp[-2].sval, yyvsp[-1].uval);
	free(yyvsp[-2].sval);
	}
break;
case 225:
#line 1134 "parser.y"
{
	bx_dbg_takeaganderat_command(yyvsp[-2].sval, yyvsp[-1].uval);
	free(yyvsp[-2].sval);
	}
break;
case 226:
#line 1143 "parser.y"
{
	bx_dbg_vtimingaddr_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
	free(yyvsp[-3].sval);
	}
break;
case 227:
#line 1151 "parser.y"
{
	bx_dbg_countexpr_command(yyvsp[-2].sval, yyvsp[-1].uval);
	free(yyvsp[-2].sval);
	}
break;
case 228:
#line 1161 "parser.y"
{
	bx_dbg_dataforlabels_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
	free(yyvsp[-3].sval);
	}
break;
case 229:
#line 1169 "parser.y"
{
	bx_dbg_removeskippy_command(yyvsp[-2].sval, yyvsp[-1].uval);
	free(yyvsp[-2].sval);
	}
break;
case 230:
#line 1177 "parser.y"
{
	bx_dbg_seteip_command(yyvsp[-2].sval, yyvsp[-1].uval);
	free(yyvsp[-2].sval);
	}
break;
case 231:
#line 1185 "parser.y"
{
	bx_dbg_putlabel_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
	free(yyvsp[-3].sval);
	}
break;
case 232:
#line 1193 "parser.y"
{
	bx_dbg_addrsinterest_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
	free(yyvsp[-3].sval);
	}
break;
case 233:
#line 1201 "parser.y"
{
	bx_dbg_printcr3_command(yyvsp[-1].sval);
	free(yyvsp[-1].sval);
	}
break;
case 234:
#line 1210 "parser.y"
{
	bx_dbg_sigfromgamma_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
	free(yyvsp[-3].sval);
	}
break;
case 235:
#line 1219 "parser.y"
{
        bx_dbg_setpmem_command(yyvsp[-3].uval, yyvsp[-2].uval, yyvsp[-1].uval);
        free(yyvsp[-4].sval);
        }
break;
case 236:
#line 1227 "parser.y"
{
        bx_dbg_query_command(yyvsp[-1].sval);
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 237:
#line 1235 "parser.y"
{
        bx_dbg_take_command(yyvsp[-1].sval, 1);
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 238:
#line 1240 "parser.y"
{
        bx_dbg_take_command(yyvsp[-2].sval, yyvsp[-1].uval);
        free(yyvsp[-3].sval); free(yyvsp[-2].sval);
        }
break;
case 239:
#line 1245 "parser.y"
{
        bx_dbg_take_command(yyvsp[-1].sval, 1);
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 240:
#line 1253 "parser.y"
{
        bx_dbg_set_cpu_command();
        free(yyvsp[-1].sval);
        }
break;
case 241:
#line 1261 "parser.y"
{
        bx_dbg_disassemble_command(yyvsp[-1].uval_range);
        free(yyvsp[-2].sval);
        }
break;
case 242:
#line 1269 "parser.y"
{
        bx_dbg_instrument_command(yyvsp[-1].sval);
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 243:
#line 1274 "parser.y"
{
        bx_dbg_instrument_command(yyvsp[-1].sval);
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 244:
#line 1279 "parser.y"
{
        bx_dbg_instrument_command(yyvsp[-1].sval);
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 245:
#line 1284 "parser.y"
{
        bx_dbg_instrument_command(yyvsp[-1].sval);
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 246:
#line 1292 "parser.y"
{
        bx_dbg_loader_command(yyvsp[-1].sval);
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 247:
#line 1300 "parser.y"
{
        bx_dbg_doit_command(yyvsp[-1].uval);
        free(yyvsp[-2].sval);
        }
break;
case 248:
#line 1308 "parser.y"
{
        bx_dbg_crc_command(yyvsp[-2].uval, yyvsp[-1].uval);
        free(yyvsp[-3].sval);
        }
break;
case 249:
#line 1316 "parser.y"
{
        bx_dbg_maths_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
        free(yyvsp[-4].sval); free(yyvsp[-3].sval);
        }
break;
case 250:
#line 1321 "parser.y"
{
        bx_dbg_maths_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
        free(yyvsp[-4].sval); free(yyvsp[-3].sval);
        }
break;
case 251:
#line 1326 "parser.y"
{
        bx_dbg_maths_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
        free(yyvsp[-4].sval); free(yyvsp[-3].sval);
        }
break;
case 252:
#line 1331 "parser.y"
{
        bx_dbg_maths_command(yyvsp[-3].sval, yyvsp[-2].uval, yyvsp[-1].uval);
        free(yyvsp[-4].sval); free(yyvsp[-3].sval);
        }
break;
case 253:
#line 1336 "parser.y"
{
        bx_dbg_maths_expression_command(yyvsp[-1].sval);
        free(yyvsp[-2].sval); free(yyvsp[-1].sval);
        }
break;
case 254:
#line 1343 "parser.y"
{
        bx_dbg_v2l_command(yyvsp[-3].uval, yyvsp[-1].uval);
        free(yyvsp[-4].sval);
        }
break;
case 255:
#line 1351 "parser.y"
{
	bx_dbg_trace_reg_on_command();
	free(yyvsp[-1].sval);
	}
break;
case 256:
#line 1359 "parser.y"
{
	bx_dbg_trace_reg_off_command();
	free(yyvsp[-1].sval);
	}
break;
case 257:
#line 1367 "parser.y"
{
         bx_dbg_help_command(yyvsp[-1].sval);
         free(yyvsp[-2].sval);free(yyvsp[-1].sval);
         }
break;
case 258:
#line 1372 "parser.y"
{
         bx_dbg_help_command(0);
         free(yyvsp[-1].sval);
         }
break;
#line 2224 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yysslim && yygrowstack())
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
#endif  /* if BX_DEBUGGER */
/* The #endif is appended by the makefile after running yacc. */
