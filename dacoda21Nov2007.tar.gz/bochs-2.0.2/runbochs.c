#include <stdlib.h>
#include <unistd.h>

int main()
{
	setuid(0);
	system("./bochs -q");

	return 0;
}

