#include "symbolic_storage.h"
#include "garbage.h"

GarbageCollector TheGarbageCollector;

extern SymbolicStorage TheLabels;

GarbageCollector::GarbageCollector()
{
	Reachable = NULL;
}

void GarbageCollector::Insert(Expression *InsertMe)
{
	//Reachable[InsertMe] = TRUE;
	ReachableNode *pNewNode;

	pNewNode = new ReachableNode;
	pNewNode->pTheExpr = InsertMe;
	pNewNode->Marked = TRUE;
	pNewNode->pNext = Reachable;
	Reachable = pNewNode;
	InsertMe->MyNode = pNewNode;
	//return pNewNode;
}

extern void Traverse(Expression *Me, ReachableNode *pReachable);

void GarbageCollector::TakeOutTheGarbage(Expression **SaveList)
{
	//ReachableMap::iterator Loop;
	ReachableNode *pLoop, *pTrail, *pDeleteMe;
	//Expression *SaveListLoop;
	
	printf("Taking out the garbage...");
	fflush(stdout);

	if (Reachable != NULL)
	{
                 unsigned long i = 0;
		for (pLoop = Reachable; pLoop != NULL; pLoop = pLoop->pNext)
		{
			if (pLoop->pTheExpr == NULL)
			{
				pLoop->Marked = FALSE;
			}
			else
			{
				if (pLoop->pTheExpr->InTheCPUYet())
					pLoop->Marked = FALSE;
				else
					pLoop->Marked = TRUE;
			}
                  i++;
		}

		/**for (SaveListLoop = *SaveList; SaveListLoop != NULL; SaveListLoop++)
		{
			SaveListLoop->MyNode->Marked = TRUE;
			Traverse(SaveListLoop, Reachable);
		}**/

		TheLabels.MarkReachable(Reachable);
		//printf("Eeeeeeeeeeeeeeee\n");


#if 0
		pLoop = Reachable;
		Reachable = NULL;
		for (/*pLoop = Reachable*/; pLoop != NULL; /*pLoop = pLoop->pNext*/)
		{
			if (pLoop->Marked == FALSE)
			{
				//printf("%08x\n", pLoop->pTheExpr);
				delete pLoop->pTheExpr;
			}
			else
			{
				this->Insert(pLoop->pTheExpr);
			}
			pDeleteMe = pLoop;
			pLoop = pLoop->pNext;
			delete pDeleteMe;
		}
#endif

		pTrail = Reachable;
                 unsigned long j = 0;
		for (pLoop = Reachable->pNext; pLoop != NULL; /**pLoop = pLoop->pNext**/)
		{
			if (pLoop->Marked == FALSE)
			{
				delete pLoop->pTheExpr;
				pTrail->pNext = pLoop->pNext;
				pDeleteMe = pLoop;
				pLoop = pLoop->pNext;
				delete pDeleteMe;

			}
			else
			{
				pTrail = pLoop;
				pLoop = pLoop->pNext;
			}
                    j++;

		}
		if (Reachable->Marked == FALSE)
		{
			pDeleteMe = Reachable;
			Reachable = Reachable->pNext;
			if (pDeleteMe == NULL)
			{
				printf("Impossible!\n");
			}
			else
			{
				delete pDeleteMe;
			}
		}

	}
/*	for (Loop = Reachable.begin(); Loop != Reachable.end(); Loop++)
	{
		if (Loop->second == FALSE)
		{
			delete Loop->first;
		}
	}*/
	//printf("done with take out the garbage.\n");
	fflush(stdout);

}

void GarbageCollector::Remove(Expression *RemoveMe)
{
	/***ReachableNode *pLoop, *pTrail;

	if (Reachable->pTheExpr == RemoveMe)
	{
		pTrail = Reachable;
		Reachable = Reachable->Next;
		delete pTrail;
	}
	else
	{
		pTrail = Reachable;
		for (pLoop = Reachable->pNext; pLoop != NULL; pLoop = pLoop->pNext)
		{
			if (pLoop->pTheExpr == RemoveMe)
			{
			}
		}
	} ***/
/**	ReachableMap::iterator KillMe;

	KillMe = Reachable.find(RemoveMe);

	if (KillMe != Reachable.end())
	{
		Reachable.erase(KillMe);
	}**/
}

GarbageCollector::~GarbageCollector()
{
}
