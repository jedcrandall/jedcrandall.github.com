#ifndef __garbage_h
#define __garbage_h

#include "expression.h"
class Expression;


#ifndef BOOL
#define BOOL int
#endif
#ifndef FALSE
#define FALSE 0
#endif
#ifndef TRUE
#define TRUE 1
#endif

//typedef map<Expression *, BOOL> ReachableMap;
struct ReachableNode {
	Expression *pTheExpr;
	BOOL Marked;
	ReachableNode *pNext;
};

class GarbageCollector
{
private:
	//ReachableMap Reachable;
	ReachableNode *Reachable;
public:
	GarbageCollector();
	void Insert(Expression *InsertMe);
	void TakeOutTheGarbage(Expression **SaveList);
	void Remove(Expression *RemoveMe);
	~GarbageCollector();
};

#endif
