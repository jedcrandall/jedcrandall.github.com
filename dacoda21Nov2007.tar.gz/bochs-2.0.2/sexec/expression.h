#ifndef __EXPRESSION_H
#define __EXPRESSION_H

#include "config.h" // Daniela

#include <stdio.h>

#if BX_LOG_RECOVERY
#include <list>
#include <iostream> 
using namespace std;
#endif

#ifndef __CTHULHU_PARSER

// (QuadExpression *) new QuadExpression((Expression *) new Constant(BX_READ_32BIT_REG(Index)),NULL,NULL,NULL) : \


#include "symbolic_storage.h"


/**
 * CreateQuadExpressionFromConstant
 * Nao entendo a semantica.
 */
#define MakeNewQuadConstant(Id, Expr) \
	Expression *ETempOne, *ETempTwo, *ETempThree, *ETempFour; \
	ETempOne = (Expression *) new Constant(Id & 0xFF); \
	ETempTwo = (Expression *) new Constant((Id & 0xFF00) >> 8); \
	ETempThree = (Expression *) new Constant((Id & 0xFF0000) >> 16); \
	ETempFour = (Expression *) new Constant(Id >> 24); \
	Expr = (Expression *) new QuadExpression(ETempOne, ETempTwo, ETempThree, ETempFour);
/***	delete ETempOne; \
	delete ETempTwo; \
	delete ETempThree; \
	delete ETempFour;***/

/**
 * Receives the index of a symbolic register. If the Expression located at the first byte
 * of this register is NULL, return NULL. If the Expression is a QuadExpression make a copy of it and return
 * it. Otherwise reads the next 3 expressions at the next 3 bytes, creates a QuadExpression with it and return it.
 * ReadQuadExpressionFromReg(Index)
 */
#define MakeNewQuadReg(Index) ( \
(TheLabels.ReadSymbolicRegister(Index, 0) == NULL) ? \
NULL : \
( \
(TheLabels.ReadSymbolicRegister(Index, 0)->Type == T_QUAD) ? \
(QuadExpression *) MakeACopyOf(TheLabels.ReadSymbolicRegister(Index, 0)) : \
(new QuadExpression(TheLabels.ReadSymbolicRegister(Index, 0), TheLabels.ReadSymbolicRegister(Index, 1), TheLabels.ReadSymbolicRegister(Index, 2), TheLabels.ReadSymbolicRegister(Index, 3))) \
) \
)

/**
 * Receives a symbolic memory address (segment + offset) and an Expression.
 * Reads the Expression located at the first byte of the address. If it is already
 * a QuadExpression return it. Otherwise, reads the next 3 bytes, creates a QuadExpression
 * with the 4 bytes and return it.
 * ReadQuadExpressionFromMem(Seg, Off, Expr)
 */
#define MakeNewQuadMem(Seg, Off, Expr) \
	Expression *ETempOne, *ETempTwo, *ETempThree, *ETempFour; \
	read_virtual_expression(Seg, Off, &ETempOne); \
	if (ETempOne != NULL) \
	{ \
		if (ETempOne->Type == T_QUAD) \
		{ \
			Expr = MakeACopyOf(ETempOne); \
		} \
		else \
		{ \
			read_virtual_expression(Seg, Off + 1, &ETempTwo); \
			read_virtual_expression(Seg, Off + 2, &ETempThree); \
			read_virtual_expression(Seg, Off + 3, &ETempFour); \
			Expr = (Expression *) new QuadExpression(ETempOne, ETempTwo, ETempThree, ETempFour); \
		} \
	} \
	else \
	{ \
		Expr = NULL; \
	}

/**
 * Receives a symbolic memory address (segment + offset) and an Expression.
 * Writes the Expression to the first byte of the address. All other bytes
 * are set to NULL.
 * WriteSymbolicMem(Seg, Off, Expr)
 * Duvida: Porque so o primeiro byte eh setado?
 */
#define WriteSymbolicQuadMem(Seg, Off, Expr) \
	if (Expr == NULL) { \
		write_virtual_expression(Seg, Off, NULL); \
		write_virtual_expression(Seg, Off + 1, NULL); \
		write_virtual_expression(Seg, Off + 2, NULL); \
		write_virtual_expression(Seg, Off + 3, NULL); \
	} \
	else { \
		write_virtual_expression(Seg, Off, Expr /*MakeACopyOf(Expr)*/); \
		write_virtual_expression(Seg, Off + 1, NULL /*MakeACopyOf(Expr)*/); \
		write_virtual_expression(Seg, Off + 2, NULL /*MakeACopyOf(Expr)*/); \
		write_virtual_expression(Seg, Off + 3, NULL /*Expr*/); \
	}

/**
 * Receives the index of a symbolic register and an Expression.
 * Writes the Expression passed as a parameter to the first byte of the register
 * All the other bytes are set to NULL.
 * WriteSymbolicRegister(Index, Expression)
 * Duvida: Porque so o primeiro byte eh setado?
 */
#define WriteSymbolicQuadRegister(Index, Expr) \
	if (Expr == NULL) { \
		TheLabels.WriteSymbolicRegister(Index, 0, NULL); \
		TheLabels.WriteSymbolicRegister(Index, 1, NULL); \
		TheLabels.WriteSymbolicRegister(Index, 2, NULL); \
		TheLabels.WriteSymbolicRegister(Index, 3, NULL); \
	} \
	else { \
		TheLabels.WriteSymbolicRegister(Index, 0, Expr /*MakeACopyOf(Expr)*/); \
		TheLabels.WriteSymbolicRegister(Index, 1, NULL /*MakeACopyOf(Expr)*/); \
		TheLabels.WriteSymbolicRegister(Index, 2, NULL /*MakeACopyOf(Expr)*/); \
		TheLabels.WriteSymbolicRegister(Index, 3, NULL /*Expr*/); \
	}


/**
 * Receives as a parameter the index of a register and creates and returns a DoubleExpression from
 * the Expressions at the first 2 bytes of the register.
 * ReadDoubleExpressionFromRegister
 */
#define MakeNewDoubleReg(Index) (new DoubleExpression(TheLabels.ReadSymbolicRegister(Index, 0), TheLabels.ReadSymbolicRegister(Index, 1)))


/**
 * Receives as a parameter the index of a register and an expression.
 * Copy this expression to the first 2 bytes of the register.
 * WriteDoubleExpressionToRegister
 * Duvida: Pq fazer uma copia? Porque nao usar a mesma ref?
 */
#define WriteSymbolicDoubleRegister(Index, Expr) \
	TheLabels.WriteSymbolicRegister(Index, 0, MakeACopyOf(Expr)); \
	TheLabels.WriteSymbolicRegister(Index, 1, Expr);


/**
 * Receives as a parameter a memory segment and offset and an expression.
 * Reads 2 expressions of the symbolic memory starting at the offset and creates
 * a DoubleExpression with them. Copies this DoubleExpression to the Expression passed as a parameter
 * ReadDoubleExpressionFromMemory
 */
#define MakeNewDoubleMem(Seg, Off, Expr) \
	Expression *ETempOne, *ETempTwo; \
	read_virtual_expression(Seg, Off, &ETempOne); \
	read_virtual_expression(Seg, Off + 1, &ETempTwo); \
	Expr = (Expression *) new DoubleExpression(ETempOne, ETempTwo);

/**
 * Receives as a parameter a memory segment and offset and an expression.
 * Writes this expression into the symbolic memory as word (2 bytes), where
 * the Expression is copied to each one of these bytes.
 * WriteDoubleExpressionToMemory
 */
#define WriteSymbolicDoubleMem(Seg, Off, Expr) \
	write_virtual_expression(Seg, Off, MakeACopyOf(Expr)); \
	write_virtual_expression(Seg, Off + 1, Expr);

/**
 * Create 2 constants using Iw and create a double expression
 * involving these 2 constants. This DoubleExpression is attributed to the
 * expression passed as a parameter
 * CreateDoubleExpressionFromConstant
 * Nao entendo a semantica
 */
#define MakeNewDoubleConstant(Iw, Expr) \
	Expression *ETempOne, *ETempTwo; \
	ETempOne = (Expression *) new Constant(Iw & 0xFF); \
	ETempTwo = (Expression *) new Constant(Iw >> 8); \
	Expr = (Expression *) new DoubleExpression(ETempOne, ETempTwo);


/***	delete ETempOne; \
	delete ETempTwo;***/

#endif
	
	
#ifndef BOOL
#define BOOL int
#endif
#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif
#ifndef BYTE
#define BYTE unsigned char
#endif
#ifndef ULONG
#define ULONG unsigned long int
#endif

#define T_LABEL 1
#define T_CONSTANT 2
#define T_QUAD 3
#define T_DOUBLE 4
#define T_OPERATION 5
#define T_LOOKUP 6
#define T_PREDICATE 7

struct Skippy_struct
{
	int IndexBegin;
	int Size;
	Skippy_struct *pNext;
};


class Expression
{
private:
public:
	struct ReachableNode *MyNode;
	int Type;
	unsigned long int MyDepth;
	BOOL MyIdempotency;
	BOOL MyNullness;
	Expression();
        
	virtual ~Expression();
	virtual BOOL IsALabel() {return FALSE;}
	virtual BOOL IsAConstant() {return FALSE;}
	//virtual BOOL IsAMemory() {return FALSE;}
	virtual BOOL IsAQuadExpression() {return FALSE;}
	virtual BOOL IsADoubleExpression() {return FALSE;}
	virtual BOOL IsALookup() {return FALSE;}
	virtual BOOL IsAnOperation() {return FALSE;}
	virtual BOOL IsAPredicate() {return FALSE;}
	virtual BOOL InTheCPUYet() {return TRUE;}
	virtual void Print(int Level, FILE *f) {fprintf(f, "Tried to print a generic Expression\n");};
	int Depth() {return MyDepth;};//(int Level)printf("Tried to get depth of a generic Expression\n"); return 0;};
	int Idempotency() {return MyIdempotency;};
	int Nullness() {return MyNullness;};
#if BX_LOG_RECOVERY
        void getLabels(list<Expression*> *labels); 
#endif
};

class Label : Expression
{
private:
	unsigned long int Number;
	BOOL InCPU;
#if BX_LOG_RECOVERY
        int netTransportId; // Id of the logical end to end transport that this label is associated to.
#endif

public:
	Label();
	Label(unsigned long int);
	unsigned long int GetNumber();
	BOOL IsALabel() {return TRUE;}
	void Print(int Level, FILE *f);
	//int Depth(int Level) {return Level + 1;}
	BOOL InTheCPUYet() {return InCPU;}
	void SetInCPU(BOOL ToWhat) {InCPU = ToWhat;}
#if BX_LOG_RECOVERY
        void setNetTransportId(int value);
        int getNetTransportId();
#endif
	~Label();
};

class Constant : Expression
{
private:
	int TheConstant;
public:
	Constant(int);
	int GetConstant() {return TheConstant;};
	BOOL IsAConstant() {return TRUE;}
	void Print(int Level, FILE *f);
	//int Depth(int Level) {return Level + 1;}
	~Constant();
};


/**class Constant : Expression
{
private:
	BYTE Value;
public:
	Constant(BYTE ValueAssigned);
	BYTE GetValue();
	BOOL IsAConstant() {return TRUE;}
	void Print(int Level);
	~Constant();
};

class Memory : Expression
{
private:
	ULONG VirtualAddress;
	BYTE Value;
public:
	Memory(ULONG, BYTE);
	ULONG GetVirtualAddress();
	BYTE GetValue();
	BOOL IsAMemory() {return TRUE;}
	~Memory();
};

class Operator : Expression
{
private:
	Expression *Left;
	Expression *Right;
public:
	Operator();
	~Operator();
};

class Boolean : Expression
{
private:
public:
	Boolean();
	~Boolean();
};**/

class QuadExpression : Expression
{
	private:
		Expression *FourBytes[4];
	public:
		QuadExpression(Expression *B0, Expression *B1, Expression *B2, Expression *B3);
		BOOL IsAQuadExpression() {return TRUE;}
		Expression *GetByte(int Index);
		void Print(int Level, FILE *f);
		//int Depth(int Level)
		//{
		//	if (FourBytes[0] != NULL)
		//		return (FourBytes[0]->Depth(Level + 1));
		//	else if (FourBytes[1] != NULL)
		//		return (FourBytes[1]->Depth(Level + 1));
		//	else if (FourBytes[2] != NULL)
		//		return (FourBytes[2]->Depth(Level + 1));
		//	else if (FourBytes[3] != NULL)
		//		return (FourBytes[3]->Depth(Level + 1));
		//	else
		//		return Level + 1;
		//}
		~QuadExpression();
};

class DoubleExpression : Expression
{
	private:
		Expression *TwoBytes[2];
	public:
		DoubleExpression(Expression *B0, Expression *B1);
		BOOL IsADoubleExpression() {return TRUE;}
		Expression *GetByte(int Index);
		void Print(int Level, FILE *f);
		//int Depth(int Level)
		//{
		//	if (TwoBytes[0] != NULL)
		//		return (TwoBytes[0]->Depth(Level + 1));
		//	else if (TwoBytes[1] != NULL)
		//		return (TwoBytes[1]->Depth(Level + 1));
		//	else
		//		return Level + 1;
		//}
		~DoubleExpression();
};


class Lookup : Expression
{
private:
	Expression *TheAddr;
	Expression *TheValue;
public:
	Lookup(Expression *Addr, Expression *Value);
	Expression *GetAddr();
	Expression *GetValue();
	BOOL IsALookup() {return TRUE;}
	void Print(int Level, FILE *f);
	//int Depth(int Level)
	//{
	//	if (TheAddr != NULL)
	//		return (TheAddr->Depth(Level + 1));
	//	else if (TheValue != NULL)
	//		return (TheValue->Depth(Level + 1));
	//	else
	//		return Level + 1;
	//}
	~Lookup();
};

class Operation : Expression
{
private:
	Expression *Op1;
	Expression *Op2;
	char *Operator;
public:
	Operation(Expression *InOp1, Expression *InOp2, char *InOperator);
	Expression *GetOp1();
	Expression *GetOp2();
	char *GetOperator();
	BOOL IsAnOperation() {return TRUE;}
	void Print(int Level, FILE *f);
	//int Depth(int Level)
	//{
	//	if (Op1 != NULL)
	//		return (Op1->Depth(Level + 1));
	//	else if (Op2 != NULL)
	//		return (Op2->Depth(Level + 1));
	//	else
	//		return Level + 1;
	//}
	~Operation();
};

class Predicate : Expression
{
	private:
		Expression *Left;
		Expression *Right;
		char *Relation;
		unsigned int WhereAt;
		unsigned int PageTableBase;
		BOOL Interesting;
		unsigned int CPL;
	public:
		Predicate(Expression *InLeft, Expression *InRight, char *InRelation, unsigned int InWhereAt, unsigned int InPageTableBase, BOOL InInteresting, unsigned int inCPL);
		BOOL IsAPredicate() {return TRUE;}
		Expression *GetLeft() {return Left;}
		Expression *GetRight() {return Right;}
		void Print(int Level, FILE *f);
		//int Depth(int Level)
		//{
		//	if (Left != NULL)
		//		return (Left->Depth(Level + 1));
		//	else if (Right != NULL)
		//		return (Right->Depth(Level + 1));
		//	else
		//		return Level + 1;
		//}
		BOOL IsInteresting() {return Interesting;}
		unsigned int GetEIP() {return WhereAt;}
		unsigned int GetPTID() {return PageTableBase;}
		unsigned int GetCPL() {return CPL;};
		unsigned int leftval;
		unsigned int rightval;
		void SetVals(unsigned int i, unsigned int j) {leftval = i; rightval = j;}
		~Predicate();
};


//Expression *MakeACopyOf(Expression *);
#define MakeACopyOf(BlaExpr) BlaExpr

Expression *SplitOperation(Expression *, int);

BOOL HasAConstant(Expression *Me);

#endif
