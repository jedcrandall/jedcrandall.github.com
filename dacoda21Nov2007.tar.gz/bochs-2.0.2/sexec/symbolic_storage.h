#ifndef __SYMBOLIC_STORAGE_H
#define __SYMBOLIC_STORAGE_H

#include "config.h" // Daniela
#include "garbage.h"
typedef void linear2phyfunction(unsigned int, unsigned int *, unsigned int *);

#include "expression.h"
class Expression;

#ifdef SEXEC
#include <map>
using namespace std;
#endif

#if BX_LOG_RECOVERY
//#include <list>
//using namespace std;
#endif

#ifndef ULONG
#define ULONG unsigned long int
#endif

#define NUM_SAVED_PREDICATES 50000
#define NUM_SAVED_LABELBYTES 1000000

struct t_updatecount
{
	unsigned int *pArray;
	unsigned int LAddr;
	unsigned int CR3;
};

class SymbolicStorage
{
private:
#ifdef SEXEC
	typedef map<ULONG, struct t_updatecount *> UpdateCountMap;
	UpdateCountMap *UpdateCount;
	typedef map<ULONG, Expression *> SymbolicStorageMap;
	SymbolicStorageMap SymbolicMemory;
#else
	typedef int UpdateCountMap;
	UpdateCountMap *UpdateCount;
	typedef int SymbolicStorageMap;
	SymbolicStorageMap SymbolicMemory;
	
#endif
	//SymbolicStorageMap SymbolicRegisters;
	Expression *SymbolicRegisters[10][4];
	Expression *ThePredicates[NUM_SAVED_PREDICATES];
	int PredHead;
	unsigned char StoredLabelBytes[NUM_SAVED_LABELBYTES];
	unsigned long int StoredLabelBytesTotal;
	Expression *IdempotentExpr;
#ifdef SEXEC
	typedef map<ULONG, ULONG> EIPToCountMap;
	typedef map<ULONG, EIPToCountMap *> CR3ToEIPMap;
#else
	typedef int EIPToCountMap;
	typedef int CR3ToEIPMap;
#endif
	CR3ToEIPMap CR3ToEIP;
	CR3ToEIPMap Inversions;
public:
	SymbolicStorage();
	void WriteSymbolicMemory(ULONG PhysicalAddress, Expression *pExpression);
	Expression *ReadSymbolicMemory(ULONG PhysicalAddress);
	int NumLabelsInMemory();
	void WriteSymbolicRegister(ULONG Index, ULONG Byte, Expression *pExpression);
	Expression *ReadSymbolicRegister(ULONG Index, ULONG Byte);
#if BX_LOG_RECOVERY
list<Expression*> *ReadSymbolicMemory32(unsigned segment, bx_address offset);
list<Expression*> *ReadSymbolicRegister32(ULONG index);
#endif
	void LabelDump(void *f, unsigned int From, unsigned int To);
	void PhysicalLabelDump();
	void MarkReachable(ReachableNode *pReachable);
	void AddPredicate(Expression *pExpression);
	void PrintPredicates(ULONG StartLabel, ULONG EndLabel, ULONG CommType);
	void PrintAllPredicates(ULONG StartLabel, ULONG EndLabel);
	void SummarizePredicates(ULONG StartLabel, ULONG EndLabel);
	void AddLabelByte(unsigned char AddMe);
	int GetLabelByte(ULONG LabelNumber);
	void SigFromGamma(ULONG GammaStart, ULONG GammaEnd);
	void CreateUpdateCountMap();
	void PrintUpdateCount(ULONG physical);
	void SummarizeUpdateCountMapTopX();
	void SummarizeUpdateCountMap();
	void SummarizeUpdateCountMapForDifferentErrorRates();
	void SummarizeUpdateCountMapForDifferentErrorRatesRealTime();
	void DeleteUpdateCountMap();
	void AssociateVirtualAddress(ULONG physical, ULONG laddr, ULONG cr3);
	void ClearSymbolicStorage();
	void SetPredicateFilter();
	void ClearPredicateFilter();
	void AddPredicateFilter(unsigned int CR3, unsigned int eip);
	void PrintPredicatesFiltered(ULONG From, ULONG To);
	void PrintPredicatesCR3(ULONG CR3);
	void AddInversion(unsigned int CR3, unsigned int eip);
	int RmInversion(unsigned int CR3, unsigned int eip);
	int IsInversion(unsigned int CR3, unsigned int eip);
	void LsInversions();
	void CheckInUpdateCount(ULONG PhysicalAddress);
	~SymbolicStorage();
};

#endif
