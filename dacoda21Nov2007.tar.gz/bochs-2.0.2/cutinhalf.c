#include <stdio.h>

int main()
{
	int Loop;
	char Buffer[100];
	FILE *f = fopen("longrunningstresstest.txt", "r"); 
	for (Loop = 0; Loop < 36618; Loop++)
	{
		fgets(Buffer, 100, f);
		if (!(Loop % 8))
			printf(Buffer);
	}
	return 0;
}
